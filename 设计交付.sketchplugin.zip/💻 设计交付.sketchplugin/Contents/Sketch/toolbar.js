// Keep this entry self-contained so even a missing runtime produces a visible error.
function commandDeveloperToolbar(context) {
  var stage = '读取插件文件';
  try {
    var system = NSDictionary.dictionaryWithContentsOfFile('/System/Library/CoreServices/SystemVersion.plist');
    var major = parseInt(String(system.objectForKey('ProductVersion')).split('.')[0], 10);
    if (major < 11) throw new Error('此版本需要 macOS 11 或更新版本。');
    var url = context.plugin.urlForResourceNamed('canvas-runtime.js');
    if (!url) throw new Error('缺少运行文件，请重新安装完整插件。');
    var source = NSString.stringWithContentsOfFile_encoding_error(url.path(), NSUTF8StringEncoding, null);
    if (!source || String(source).length < 1000) throw new Error('运行文件缺失或不完整，请重新安装完整插件。');
    stage = '加载工具栏功能';
    eval(String(source));
    DELIVERY_PLUGIN_CONTEXT=context;
    if (typeof nativeDeveloperToggle !== 'function') throw new Error('运行文件不完整，找不到工具栏入口。');
    stage = '启动原生工具栏';
    nativeDeveloperToggle(context);
  } catch (error) {
    var details = stage + '：' + String(error.message || error);
    try {
      var appInfo = NSBundle.mainBundle().infoDictionary();
      details += '\nSketch ' + String(appInfo.objectForKey('CFBundleShortVersionString'));
      details += ' · ' + String(NSProcessInfo.processInfo().operatingSystemVersionString());
      details += '\n插件 ' + String(context.plugin.version());
    } catch (ignored) {}
    console.error('设计交付启动失败：' + details + '\n' + String(error.stack || ''));
    var choice = showDeliveryStartupError(context, '交付工具栏暂时无法打开', '请重新打开设计稿后重试。如果仍无法启动，请点击“复制错误信息”，将信息反馈给插件作者。\n\n'+details, ['关闭','复制错误信息']);
    if (choice === 1) {
      var pasteboard = NSPasteboard.generalPasteboard();
      pasteboard.clearContents();
      pasteboard.setString_forType(details, NSPasteboardTypeString);
    }
  }
}

function showDeliveryStartupError(context, title, message, buttons) {
  try {
    var url=context.plugin.urlForResourceNamed('dialog-bootstrap.js');
    if(url){var source=NSString.stringWithContentsOfFile_encoding_error(url.path(),NSUTF8StringEncoding,null);if(source){eval(String(source));return deliveryAlert(title,message,buttons,0,context);}}
  }catch(error){console.error(String(error));}
  return deliverySystemAlert(title,message,buttons,0);
}

// NSAlert lays out its first button on the right. Preserve logical result
// indices while placing cancellation on the left, including OS fallback UI.
function deliveryDialogPresentation(message,buttons) {
  var confirmation=(buttons||[]).some(function(label){return /^(删除|放弃|delete|discard)/i.test(String(label));});
  return {title:confirmation?'操作确认':'提示',message:String(message||'').replace(/[。．.]+(?=[ \t]*(?:\r?\n|$))/g,'')};
}
function deliverySystemAlert(title,message,buttons,primary) {
  buttons=buttons&&buttons.length?buttons:['知道了'];primary=Math.max(0,Math.min(buttons.length-1,Number(primary)||0));
  var presentation=deliveryDialogPresentation(message,buttons);title=presentation.title;message=presentation.message;
  var cancel=-1,order=[];
  buttons.some(function(label,index){if(/^(取消.*|关闭|继续编辑|cancel|close)$/i.test(String(label))){cancel=index;return true;}return false;});
  if(primary===cancel&&buttons.length>1){for(var i=buttons.length-1;i>=0;i--)if(i!==cancel){primary=i;break;}}
  if(cancel>=0)order.push(cancel);
  buttons.forEach(function(label,index){if(index!==cancel&&index!==primary)order.push(index);});
  if(primary!==cancel)order.push(primary);
  order.reverse();
  var fallback=NSAlert.alloc().init();fallback.setMessageText(String(title));fallback.setInformativeText(String(message||''));
  order.forEach(function(index){var button=fallback.addButtonWithTitle(String(buttons[index]));if(index===primary){button.setKeyEquivalent('\r');button.setKeyEquivalentModifierMask(0);fallback.window().setDefaultButtonCell(button.cell());}else button.setKeyEquivalent('');if(index===cancel){if(index!==primary)button.setKeyEquivalent('\u001b');button.setKeyEquivalentModifierMask(0);}});
  var result=Number(fallback.runModal())-1000;
  return result>=0&&result<order.length?order[result]:(cancel>=0?cancel:primary);
}
