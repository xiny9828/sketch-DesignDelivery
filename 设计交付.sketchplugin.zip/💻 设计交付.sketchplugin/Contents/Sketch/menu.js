// Restore direct menu access without opening or toggling the canvas toolbar.
function invokeDeliveryMenu(context, action) {
  try {
    var url = context.plugin.urlForResourceNamed('canvas-runtime.js');
    if (!url) throw new Error('缺少运行文件，请重新安装完整插件。');
    var source = NSString.stringWithContentsOfFile_encoding_error(url.path(), NSUTF8StringEncoding, null);
    if (!source || String(source).length < 1000) throw new Error('运行文件缺失或不完整，请重新安装完整插件。');
    eval(String(source));
    DELIVERY_PLUGIN_CONTEXT=context;
    if (action === 'page') commandExport(context);
    else if (action === 'all') commandExportAllPages(context);
    else if (action === 'selected-board') commandExportSelectedBoard(context);
    else if (action === 'settings') commandSettings(context);
    else if (action === 'delete-notes-all') commandDeleteNotes(context, 'all');
    else if (action === 'delete-notes-page') commandDeleteNotes(context, 'page');
    else throw new Error('未知的交付菜单操作。');
  } catch (error) {
    console.error('设计交付菜单执行失败：' + String(error.stack || error));
    showDeliveryStartupError(context, error.deliveryTitle||'暂时无法完成操作', String(error.message || error)+'\n\n请重新打开交付工具后重试。如果仍无法使用，请重新安装完整插件。', ['知道了']);
  }
}
function onExportCurrentPage(context) { invokeDeliveryMenu(context, 'page'); }
function onExportSelectedBoard(context) { invokeDeliveryMenu(context, 'selected-board'); }
function onDeliverySettings(context) { invokeDeliveryMenu(context, 'settings'); }

function showDeliveryStartupError(context, title, message, buttons) {
  try {
    var url=context.plugin.urlForResourceNamed('dialog-bootstrap.js');
    if(url){var source=NSString.stringWithContentsOfFile_encoding_error(url.path(),NSUTF8StringEncoding,null);if(source){eval(String(source));return deliveryAlert(title,message,buttons,0,context);}}
  }catch(error){console.error(String(error));}
  return deliverySystemAlert(title,message,buttons,0);
}

function onExportAllPages(context) { invokeDeliveryMenu(context, 'all'); }

function onDeleteAllNotes(context) { invokeDeliveryMenu(context, 'delete-notes-all'); }
function onDeletePageNotes(context) { invokeDeliveryMenu(context, 'delete-notes-page'); }

// NSAlert lays out its first button on the right. Preserve logical result
// indices while placing cancellation on the left, including OS fallback UI.
function deliveryDialogPresentation(message,buttons) {
  var confirmation=(buttons||[]).some(function(label){return /^(删除|放弃|delete|discard)/i.test(String(label));});
  return {title:confirmation?'操作确认':'提示',message:String(message||'').replace(/[。．.]+(?=[ \t]*(?:\r?\n|$))/g,'')};
}
function deliverySystemAlert(title,message,buttons,primary) {
  buttons=buttons&&buttons.length?buttons:['知道了'];primary=Math.max(0,Math.min(buttons.length-1,Number(primary)||0));
  var presentation=deliveryDialogPresentation(message,buttons);title=presentation.title;message=presentation.message;
  var cancel=-1,order=[];
  buttons.some(function(label,index){if(/^(取消.*|关闭|继续编辑|cancel|close)$/i.test(String(label))){cancel=index;return true;}return false;});
  if(primary===cancel&&buttons.length>1){for(var i=buttons.length-1;i>=0;i--)if(i!==cancel){primary=i;break;}}
  if(cancel>=0)order.push(cancel);
  buttons.forEach(function(label,index){if(index!==cancel&&index!==primary)order.push(index);});
  if(primary!==cancel)order.push(primary);
  order.reverse();
  var fallback=NSAlert.alloc().init();fallback.setMessageText(String(title));fallback.setInformativeText(String(message||''));
  order.forEach(function(index){var button=fallback.addButtonWithTitle(String(buttons[index]));if(index===primary){button.setKeyEquivalent('\r');button.setKeyEquivalentModifierMask(0);fallback.window().setDefaultButtonCell(button.cell());}else button.setKeyEquivalent('');if(index===cancel){if(index!==primary)button.setKeyEquivalent('\u001b');button.setKeyEquivalentModifierMask(0);}});
  var result=Number(fallback.runModal())-1000;
  return result>=0&&result<order.length?order[result]:(cancel>=0?cancel:primary);
}
