ObjC.import('Foundation');
function run(argv) {
  var plan = JSON.parse($.NSString.stringWithContentsOfFileEncodingError(argv[0], $.NSUTF8StringEncoding, null).js);
  plan.forEach(function (file) {
    var text = $.NSString.stringWithContentsOfFileEncodingError(file, $.NSUTF8StringEncoding, null);
    var doc = $.NSXMLDocument.alloc.initWithXMLStringOptionsError(text, 0, null);
    if (!doc || !doc.rootElement) throw Error('Invalid SVG: ' + file);
    var root = doc.rootElement, defs = $.NSXMLElement.elementWithName('defs');
    root.insertChildAtIndex(defs, 0);
    var groups = doc.nodesForXPathError('//*[local-name()="g"]', null), count = 0;
    for (var i = 0; i < groups.count; i++) {
      var group = groups.objectAtIndex(i), href = group.attributeForLocalNameURI('href', 'http://www.w3.org/1999/xlink');
      if (!href || !href.stringValue) href = group.attributeForName('href');
      if (!href || !href.stringValue) continue;
      var ref = href.stringValue.js;
      if (ref[0] !== '#') continue;
      var id = 'lab-frame-clip-' + (++count), clip = $.NSXMLElement.elementWithName('clipPath');
      clip.addAttribute($.NSXMLNode.attributeWithNameStringValue('id', id));
      clip.addAttribute($.NSXMLNode.attributeWithNameStringValue('clipPathUnits', 'userSpaceOnUse'));
      var use = $.NSXMLElement.elementWithName('use');
      use.addAttribute($.NSXMLNode.attributeWithNameStringValue('href', ref));
      clip.addChild(use); defs.addChild(clip); href.detach;
      group.addAttribute($.NSXMLNode.attributeWithNameStringValue('clip-path', 'url(#' + id + ')'));
    }
    if (!doc.XMLString.writeToFileAtomicallyEncodingError(file, true, $.NSUTF8StringEncoding, null)) throw Error('Cannot normalize SVG: ' + file);
  });
  return 'Normalized ' + plan.length + ' SVG files';
}
