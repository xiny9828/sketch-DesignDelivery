// Runs inside the viewer closure to share selection, inspector, and camera state.
var labItems=[],labFormat='png',labScale=1,labPlatform='web',labBackground='#ffffff',labAllowText=false,labPreviewURL=null,labRevision=0;
var labStyle=document.createElement('style');
labStyle.textContent='.lab-warning{font-size:12px;color:#9c3d16;line-height:18px;margin:8px 0;white-space:normal}.lab-fields{display:grid;grid-template-columns:1fr 1fr;gap:12px}.lab-fields label{font-size:12px;display:grid;gap:6px}.lab-fields select{height:36px;min-width:0;border:0;background:#f7f8fb;border-radius:var(--control-radius);padding:0 8px}.lab-status{font-size:12px;line-height:18px;color:rgba(0,0,0,.6);margin:8px 0}.lab-allow{display:flex;align-items:center;gap:6px;font-size:12px;margin:12px 0}.lab-remove{border:0;background:transparent;color:#9c3d16;font-size:12px;margin-top:8px}.lab-board-note{padding:0 16px 12px}.lab-preview{width:100%;height:100%;object-fit:contain}.lab-assets-empty{padding:16px;font-size:14px;color:rgba(0,0,0,.6)}';
document.head.appendChild(labStyle);
labStyle.textContent+=' .lab-slice-actions{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-top:12px}.lab-slice-actions.single{grid-template-columns:minmax(0,1fr)}.lab-slice-actions .lab-remove{height:40px;width:100%;margin:0;border:0;border-radius:var(--control-radius);background:#F53F3F;color:#fff;font-size:14px;cursor:pointer}.lab-slice-actions .lab-remove:hover{background:#d92d2d}.lab-status[hidden]{display:none}';
labStyle.textContent+=' .asset-item{grid-template-columns:20px minmax(0,1fr);border-radius:var(--control-radius)}.asset-item.active{background:#eef4ff}.lab-asset-open{display:grid;grid-template-columns:56px minmax(0,1fr);align-items:center;gap:8px;width:100%;min-width:0;padding:8px 0;border:0;background:transparent;text-align:left;cursor:pointer;font:inherit}.lab-asset-open .asset-thumb{width:56px;height:56px}.lab-asset-open:focus-visible{outline:2px solid #2878ff;border-radius:var(--control-radius)}.asset-thumb img{width:100%;height:100%;object-fit:contain}.asset-footer{padding:12px;display:grid;gap:12px}.asset-footer .asset-select-all{margin:0;padding:8px 0}.asset-item-copy small{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}@media(max-width:760px){html,body{height:auto;overflow:auto}.workspace,body.left-collapsed .workspace{position:relative;inset:auto;height:auto;display:flex;flex-direction:column;width:100%}.sidebar{height:320px;width:100%;flex:none}.canvas{height:440px;flex:none;width:100%}.inspector{width:100%;height:640px;flex:none}.drawer-handle{display:none}body.left-collapsed .sidebar{visibility:visible}.toast{max-width:calc(100% - 32px)}}';
labStyle.textContent+='@media(max-width:760px){.sidebar{height:560px}}';
function labKey(l,b){return b.objectID+':'+l.objectID}
function labOptions(){return {scale:labScale,designScale:designScale()}}
function labItemForLayer(l,b){
  if(!l||!b)return null;
  var exact=labItems.find(function(i){return i.key===labKey(l,b)});if(exact)return exact;
  if(l.nativeType==='Slice'){
    return labItems.find(function(i){return i.board===b&&i.builtIn&&i.layer.objectID===l.parentObjectID})||null;
  }
  // Only follow a same-size, single-content wrapper. Never promote a nested
  // icon's export to a larger component or a group with unrelated siblings.
  var visited=new Set();
  while(l.hasChildren&&!visited.has(l.objectID)){
    visited.add(l.objectID);
    var children=b.layers.filter(function(c){return c.parentObjectID===l.objectID&&!c.hidden&&c.nativeType!=='Slice'});
    if(children.length!==1)return null;
    var child=children[0],a=l.logicalRect||l.rect,r=child.logicalRect||child.rect;
    if(!a||!r||['x','y','width','height'].some(function(k){return Math.abs(a[k]-r[k])>.01}))return null;
    var item=labItems.find(function(i){return i.board===b&&i.builtIn&&i.layer.objectID===child.objectID});
    if(item)return item;l=child;
  }
  return null;
}
function labCurrentItem(){return labItemForLayer(layer(),board())}
function labItemName(item){
  var l=item.layer,parent=item.board.layers.find(function(p){return p.objectID===l.parentObjectID});
  if(parent&&labItemForLayer(parent,item.board)===item)return parent.name;
  return l.name;
}
function labAsset(item,options){if(item.layer.labSliceError)throw Error(item.layer.labSliceError);options=Object.assign({},options);if(!item.layer.labAssetSource)options.frame=item.layer.visualRect||item.layer.rect;return SVGLab.asset(item.layer.labAssetSource||item.board.svgSource,item.layer.labAssetSource?null:item.layer.svgNodeID,options)}
project.artboards.forEach(function(b){b.layers.forEach(function(l){if(l.labBuiltIn&&!l.hidden&&!l.labSliceError)labItems.push({key:labKey(l,b),layer:l,board:b,checked:true,builtIn:true})})});
function labCanMap(l,b){
  if(l.labSliceError)return false;
  if(l.labAssetSource)return true;
  if(l.hidden||!b.svgSource||!l.svgNodeID)return false;
  try{SVGLab.prepare(b.svgSource,l.svgNodeID);return true;}catch(_){return false;}
}
labStyle.textContent+=
  '.lab-background-field{display:grid;gap:6px;min-width:0;font-size:12px}' +
  '.lab-background-control{display:flex;align-items:center;gap:4px;width:100%;height:36px;min-width:0;padding:4px;border:0;border-radius:var(--control-radius);background:#f7f8fb;color:rgba(0,0,0,.9);cursor:pointer}' +
  '.lab-background-swatch{width:28px;height:28px;flex:0 0 28px;border-radius:var(--control-radius);box-shadow:inset 0 0 0 1px rgba(0,0,0,.08)}' +
  '.lab-background-control .dropdown-icon{width:16px;height:16px;flex:0 0 16px;background-size:16px 16px}' +
  '.lab-background-control[aria-expanded="true"] .dropdown-icon{transform:scaleY(-1)}' +
  '.lab-background-hex{min-width:0;font:14px ui-monospace,SFMono-Regular,Menlo,monospace;white-space:nowrap}' +
  '.lab-background-control:hover{background:var(--menu-item-hover)}' +
  '.lab-background-control:focus-visible{outline:2px solid var(--blue);outline-offset:2px}' +
  '.lab-color-picker{position:fixed;z-index:25000;width:260px;max-width:calc(100vw - 24px);max-height:calc(100dvh - 24px);overflow:auto;padding:12px;border:1px solid var(--line);border-radius:var(--control-radius);background:#fff;box-shadow:0 8px 32px rgba(0,0,0,.16);color:rgba(0,0,0,.9);font-size:12px}' +
  '.lab-color-picker[hidden]{display:none}.lab-color-picker .IroBox{border-radius:var(--control-radius)!important;touch-action:none}' +
  '.lab-color-picker .IroSlider{touch-action:none}.lab-color-picker .IroBox:focus-visible,.lab-color-picker .IroSlider:focus-visible{outline:2px solid var(--blue);outline-offset:2px}' +
  '.lab-color-rgb{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin-top:16px}' +
  '.lab-color-input{display:flex;align-items:center;gap:4px;height:32px;min-width:0;padding:0 8px;border:1px solid transparent;border-radius:var(--control-radius);background:#f7f8fb}' +
  '.lab-color-input>span{color:rgba(0,0,0,.6);flex:none}.lab-color-input:focus-within{border-color:var(--blue)}' +
  '.lab-color-input:has([aria-invalid="true"]){border-color:#F53F3F}' +
  '.lab-color-input input{border:0;outline:0;min-width:0;width:100%;padding:0;background:transparent;color:rgba(0,0,0,.9);font:12px ui-monospace,SFMono-Regular,Menlo,monospace;user-select:text}' +
  '.lab-color-input input[type="number"]{appearance:textfield;text-align:right}.lab-color-input input::-webkit-inner-spin-button,.lab-color-input input::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}' +
  '.lab-color-hex-input{margin-top:8px}.lab-color-hex-input input{font-size:14px}';
var labBackgroundPicker=null,labBackgroundOwner=null,labBackgroundTimer=0;
function labBackgroundControl(prefix){
  return '<div class="lab-background-field"><span>JPG 底色</span><button type="button" id="'+prefix+'Background" class="lab-background-control" data-lab-background aria-label="JPG 底色 '+labBackground.toUpperCase()+'" aria-haspopup="dialog" aria-expanded="false" aria-controls="labBackgroundPopover"><span class="lab-background-swatch" style="background:'+labBackground+'"></span><span class="dropdown-icon" aria-hidden="true"></span><span class="lab-background-hex">'+labBackground.toUpperCase()+'</span></button></div>';
}
function labPositionBackgroundPicker(){
  var popup=$('labBackgroundPopover'),owner=$(labBackgroundOwner);
  if(!popup||popup.hidden)return;
  if(!owner){labCloseBackgroundPicker(false);return}
  var r=owner.getBoundingClientRect(),width=popup.offsetWidth,height=popup.offsetHeight;
  if(r.bottom<0||r.top>window.innerHeight){labCloseBackgroundPicker(false);return}
  popup.style.left=Math.max(12,Math.min(window.innerWidth-width-12,r.right-width))+'px';
  popup.style.top=Math.max(12,Math.min(window.innerHeight-height-12,r.bottom+height+8<=window.innerHeight-12?r.bottom+8:r.top-height-8))+'px';
}
function labCloseBackgroundPicker(restoreFocus){
  var popup=$('labBackgroundPopover'),owner=$(labBackgroundOwner);
  if(popup)popup.hidden=true;
  if(owner){owner.setAttribute('aria-expanded','false');if(restoreFocus)owner.focus({preventScroll:true})}
  labBackgroundOwner=null;
}
function labSyncBackgroundInputs(){
  var color=labBackgroundPicker.color,rgb=color.rgb,popup=$('labBackgroundPopover');
  ['r','g','b'].forEach(function(channel){
    var input=$('labBackground'+channel.toUpperCase());
    if(document.activeElement!==input){input.value=rgb[channel];input.removeAttribute('aria-invalid')}
  });
  var hex=$('labBackgroundHex');
  if(document.activeElement!==hex){hex.value=color.hexString.slice(1).toUpperCase();hex.removeAttribute('aria-invalid')}
  var box=popup.querySelector('.IroBox'),hue=popup.querySelector('.IroSlider');
  if(box)box.setAttribute('aria-label','饱和度 '+Math.round(color.saturation)+'%，明度 '+Math.round(color.value)+'%');
  if(hue)hue.setAttribute('aria-valuenow',Math.round(color.hue));
}
function labSetBackground(color){
  var value=color.hexString.toLowerCase();
  labSyncBackgroundInputs();
  if(value===labBackground)return;
  labBackground=value;
  document.querySelectorAll('[data-lab-background]').forEach(function(button){
    button.querySelector('.lab-background-swatch').style.background=value;
    button.querySelector('.lab-background-hex').textContent=value.toUpperCase();
    button.setAttribute('aria-label','JPG 底色 '+value.toUpperCase());
  });
  // Invalidate in-flight previews immediately, then coalesce continuous drags.
  var revision=++labRevision;
  if($('labDownload'))$('labDownload').disabled=true;
  clearTimeout(labBackgroundTimer);
  labBackgroundTimer=setTimeout(function(){
    if(revision!==labRevision)return;
    var item=labCurrentItem();
    if(item&&$('labPreview'))labRefreshPreview(item,revision);
    if($('assetList').querySelector('.asset-items'))labRenderThumbs(labItems.filter(function(i){return i.board===assetBoard()}));
  },80);
}
function labCreateBackgroundPicker(){
  if(labBackgroundPicker)return;
  var popup=document.createElement('div');
  popup.id='labBackgroundPopover';popup.className='lab-color-picker';popup.hidden=true;
  popup.setAttribute('role','dialog');popup.setAttribute('aria-label','JPG 底色');
  popup.innerHTML='<div id="labBackgroundSpectrum"></div><div class="lab-color-rgb">'+['R','G','B'].map(function(channel){
    return '<label class="lab-color-input"><span>'+channel+'</span><input id="labBackground'+channel+'" type="number" min="0" max="255" step="1" inputmode="numeric" aria-label="'+channel+' 通道"></label>';
  }).join('')+'</div><label class="lab-color-input lab-color-hex-input"><span>#</span><input id="labBackgroundHex" type="text" maxlength="7" spellcheck="false" autocomplete="off" aria-label="HEX 色值"></label>';
  document.body.appendChild(popup);
  labBackgroundPicker=new window.iro.ColorPicker('#labBackgroundSpectrum',{
    width:234,color:labBackground,borderWidth:0,padding:4,handleRadius:6,sliderMargin:12,
    layout:[{component:window.iro.ui.Box,options:{boxHeight:148}},{component:window.iro.ui.Slider,options:{sliderType:'hue',sliderSize:12}}]
  });
  labBackgroundPicker.on('color:change',labSetBackground);
  ['R','G','B'].forEach(function(channel){
    var input=$('labBackground'+channel);
    input.oninput=function(){
      var valid=/^\d{1,3}$/.test(input.value)&&Number(input.value)<=255;
      input.setAttribute('aria-invalid',String(!valid));
      if(valid){var rgb=labBackgroundPicker.color.rgb;rgb[channel.toLowerCase()]=Number(input.value);labBackgroundPicker.color.rgb=rgb}
    };
    input.onblur=function(){input.value=labBackgroundPicker.color.rgb[channel.toLowerCase()];input.removeAttribute('aria-invalid')};
  });
  var hex=$('labBackgroundHex');
  hex.oninput=function(){
    var value=this.value.trim().replace(/^#/,'');
    var valid=/^(?:[\da-f]{3}|[\da-f]{6})$/i.test(value);
    this.setAttribute('aria-invalid',String(!valid));
    if(valid)labBackgroundPicker.color.hexString='#'+value;
  };
  hex.onblur=function(){this.value=labBackgroundPicker.color.hexString.slice(1).toUpperCase();this.removeAttribute('aria-invalid')};
  popup.addEventListener('keydown',function(e){
    e.stopPropagation();
    if(e.key==='Enter'&&e.target.tagName==='INPUT'){e.preventDefault();e.target.blur()}
  });
  // The spectrum is mouse/touch driven; expose matching keyboard controls too.
  labBackgroundPicker.on('mount',function(){
    var box=popup.querySelector('.IroBox'),hue=popup.querySelector('.IroSlider');
    [box,hue].forEach(function(el){el.tabIndex=0;el.onpointerdown=function(){el.focus({preventScroll:true})}});
    box.setAttribute('role','group');hue.setAttribute('role','slider');hue.setAttribute('aria-label','色相');
    hue.setAttribute('aria-valuemin','0');hue.setAttribute('aria-valuemax','360');
    box.onkeydown=function(e){
      if(!/^Arrow/.test(e.key))return;e.preventDefault();e.stopPropagation();
      var hsv=labBackgroundPicker.color.hsv,step=e.shiftKey?10:1;
      if(e.key==='ArrowLeft')hsv.s-=step;if(e.key==='ArrowRight')hsv.s+=step;
      if(e.key==='ArrowDown')hsv.v-=step;if(e.key==='ArrowUp')hsv.v+=step;
      hsv.s=Math.max(0,Math.min(100,hsv.s));hsv.v=Math.max(0,Math.min(100,hsv.v));labBackgroundPicker.color.hsv=hsv;
    };
    hue.onkeydown=function(e){
      if(!/^Arrow/.test(e.key)&&e.key!=='Home'&&e.key!=='End')return;e.preventDefault();e.stopPropagation();
      var step=e.shiftKey?10:1,h=labBackgroundPicker.color.hue;
      labBackgroundPicker.color.hue=e.key==='Home'?0:e.key==='End'?360:(h+(/Left|Down/.test(e.key)?-step:step)+360)%360;
    };
    labSyncBackgroundInputs();
  });
}
function labToggleBackgroundPicker(button){
  var id=button.id,popup=$('labBackgroundPopover');
  if(labBackgroundOwner===id&&popup&&!popup.hidden){labCloseBackgroundPicker(true);return}
  labCloseBackgroundPicker(false);labCreateBackgroundPicker();popup=$('labBackgroundPopover');
  labBackgroundOwner=id;labBackgroundPicker.color.hexString=labBackground;
  popup.hidden=false;button.setAttribute('aria-expanded','true');
  labSyncBackgroundInputs();labPositionBackgroundPicker();
  $('labBackgroundHex').focus({preventScroll:true});
}
document.addEventListener('pointerdown',function(e){
  var popup=$('labBackgroundPopover');
  if(popup&&!popup.hidden&&!popup.contains(e.target)&&!e.target.closest('[data-lab-background]'))labCloseBackgroundPicker(false);
},true);
document.addEventListener('keydown',function(e){
  var popup=$('labBackgroundPopover');
  if(e.key==='Escape'&&popup&&!popup.hidden){e.preventDefault();e.stopImmediatePropagation();labCloseBackgroundPicker(true)}
},true);
document.addEventListener('focusin',function(e){
  var popup=$('labBackgroundPopover');
  if(popup&&!popup.hidden&&!popup.contains(e.target)&&!e.target.closest('[data-lab-background]'))labCloseBackgroundPicker(false);
});
window.addEventListener('resize',labPositionBackgroundPicker);
document.addEventListener('scroll',function(e){
  var popup=$('labBackgroundPopover');
  if(popup&&!popup.hidden&&!popup.contains(e.target))labPositionBackgroundPicker();
},true);
function labFields(prefix){
  return '<div class="lab-fields"><label>格式<select id="'+prefix+'Format">'+selectOptions([['png','PNG'],['jpg','JPG'],['svg','SVG']],labFormat)+'</select></label><label>使用平台<select id="'+prefix+'Platform">'+selectOptions([['web','Web'],['ios','iOS'],['android','Android']],labPlatform)+'</select></label><label>倍率<select id="'+prefix+'Scale">'+selectOptions([['1','1x'],['2','2x'],['3','3x'],['4','4x']],String(labScale))+'</select></label>'+(labFormat==='jpg'?labBackgroundControl(prefix):'')+'</div>';
}
slicePanel=function(l){
  var item=labCurrentItem();
  if((item&&item.layer.labSliceError)||(!item&&!labCanMap(l,board())))return '<section class="lanhu-section"><h3 class="lanhu-section-title">切图</h3><p class="lab-warning">'+esc((item?item.layer.labSliceError:l.labSliceError)||'此图层无法独立切图，请选择包含它的编组。')+'</p></section>';
  return '<section class="lanhu-section"><h3 class="lanhu-section-title">切图</h3>'+(item?'<div class="slice-preview"><img id="labPreview" class="lab-preview" alt="切图预览"></div>'+labFields('lab')+'<div class="lab-status" id="labDimensions" role="status" hidden></div><div class="lab-slice-actions'+(item.builtIn?' single':'')+'"><button class="slice-primary" id="labDownload" disabled>下载切图</button>'+(item.builtIn?'':'<button class="lab-remove" id="labRemove">移除切图</button>')+'</div>':'<button class="slice-primary" id="labCreate">添加切图</button>')+'</section>';
};
function labBindFields(prefix,changed){
  [['Format',function(v){labFormat=v}],['Platform',function(v){labPlatform=v}],['Scale',function(v){labScale=Number(v)}]].forEach(function(pair){
    var el=$(prefix+pair[0]);if(el)el.onchange=function(){pair[1](this.value);changed()};
  });
  var background=$(prefix+'Background');if(background)background.onclick=function(){labToggleBackgroundPicker(this)};
  var allow=$(prefix+'Allow');if(allow)allow.onchange=function(){labAllowText=this.checked};
}
async function labRefreshPreview(item,revision){
  try{
    var asset=await labAsset(item,labOptions());
    var previewAsset=asset;
    // Preview resolution follows its display surface, not the download density.
    if(labFormat!=='svg'&&Math.max(asset.width,asset.height)<640){
      previewAsset=await labAsset(item,{scale:640*designScale()/Math.max(asset.box.width,asset.box.height),designScale:designScale()});
    }
    var preview=await SVGLab.blob(previewAsset,labFormat,labBackground,true);
    if(revision!==labRevision)return;
    if(labPreviewURL)URL.revokeObjectURL(labPreviewURL);
    labPreviewURL=URL.createObjectURL(preview);$('labPreview').src=labPreviewURL;
    var suffix=labPlatform==='ios'?'pt':labPlatform==='android'?'dp':'px';
    $('labDownload').title=n(asset.box.width/designScale())+' × '+n(asset.box.height/designScale())+' '+suffix+' · '+asset.width+' × '+asset.height+' px';
    $('labDimensions').textContent='';$('labDimensions').hidden=true;
    $('labDownload').disabled=false;
  }catch(e){if(revision!==labRevision)return;$('labDimensions').hidden=false;$('labDimensions').textContent=e.message;$('labDownload').disabled=true;}
}
bindSlicePanel=function(l){
  var revision=++labRevision,create=$('labCreate');
  if(create)create.onclick=function(){labItems.push({key:labKey(l,board()),layer:l,board:board(),checked:true});renderInspector();renderAssets()};
  var item=labCurrentItem();if(!item||!$('labPreview'))return;
  labBindFields('lab',function(){renderInspector();renderAssets()});
  if($('labRemove'))$('labRemove').onclick=function(){labItems=labItems.filter(function(i){return i!==item});renderInspector();renderAssets()};
  $('labDownload').onclick=function(){labDownload([item],this)};
  labRefreshPreview(item,revision);
};
async function labDownload(items,button){
  if(!items.length){toast('请先选择切图');return;}
  var original=button.textContent,format=labFormat,options=labOptions(),background=labBackground,allow=labAllowText;
  button.disabled=true;button.textContent='正在生成…';
  try{
    var files=[];
    for(var i=0;i<items.length;i++){
      var asset=await labAsset(items[i],options);
      var blob=await SVGLab.blob(asset,format,background,allow);
      files.push({blob:blob,name:safeFileName(decode(items[i].layer.name))+'-'+(i+1)+'@'+options.scale+'x.'+format});
    }
    var result=files.length===1?files[0]:{blob:await zipSlices(files),name:'网页切图-'+files.length+'张.zip'};
    clickDownload(URL.createObjectURL(result.blob),result.name,true);toast('下载已启动');
  }catch(e){toast(e.message||'生成失败');}
  finally{button.disabled=false;button.textContent=original;}
}
var labThumbCache=new Map(),labThumbObserver=null,labThumbVariant='',labThumbRevision=0;
function labRenderThumbs(items){
  var revision=++labThumbRevision;
  if(labThumbObserver)labThumbObserver.disconnect();
  var variant=labFormat+':'+labBackground;
  if(variant!==labThumbVariant){labThumbCache.forEach(function(p){p.then(function(url){URL.revokeObjectURL(url)},function(){})});labThumbCache.clear();labThumbVariant=variant;}
  var format=labFormat,background=labBackground;
  labThumbObserver=new IntersectionObserver(function(entries,observer){entries.forEach(function(entry){
    if(!entry.isIntersecting)return;var img=entry.target;observer.unobserve(img);
    var item=items.find(function(i){return i.key===img.dataset.labThumb});if(!item)return;
    if(!labThumbCache.has(item.key))labThumbCache.set(item.key,labAsset(item,{scale:3,designScale:designScale()}).then(function(asset){return SVGLab.blob(asset,format,background,true)}).then(function(blob){return URL.createObjectURL(blob)}));
    labThumbCache.get(item.key).then(function(url){if(img.isConnected&&revision===labThumbRevision)img.src=url},function(error){if(img.isConnected&&revision===labThumbRevision){img.alt='预览失败';img.title=error.message}});
  })},{root:$('assetList').querySelector('.asset-items'),rootMargin:'120px'});
  document.querySelectorAll('[data-lab-thumb]').forEach(function(img){labThumbObserver.observe(img)});
}
renderAssets=function(){
  var selectedBoard=assetBoard();
  if(!selectedBoard){if(labThumbObserver)labThumbObserver.disconnect();$('assetList').innerHTML='<div class="lab-assets-empty">请先选择画板</div>';return}
  var previous=$('assetList').querySelector('.asset-items'),scrollTop=previous?previous.scrollTop:0;
  var current=labCurrentItem(),q=$('sideSearch').value.trim().toLowerCase(),items=labItems.filter(function(i){return i.board===selectedBoard&&(decode(labItemName(i))+' '+decode(i.layer.name)+' '+decode(i.board.name)).toLowerCase().indexOf(q)>=0});
  $('assetList').innerHTML='<div class="asset-items">'+(items.length?items.map(function(item){
    return '<div class="asset-item'+(current===item?' active':'')+'"><input type="checkbox" aria-label="选择 '+display(labItemName(item))+'" data-lab-item="'+esc(item.key)+'" '+(item.checked?'checked':'')+(item.layer.labSliceError?' disabled':'')+'><button type="button" class="lab-asset-open" data-lab-open="'+esc(item.key)+'"><span class="asset-thumb">'+(item.layer.labSliceError?'':'<img data-lab-thumb="'+esc(item.key)+'" alt="">')+'</span><span class="asset-item-copy"><strong>'+display(labItemName(item))+'</strong><small>'+display(item.layer.labSliceError?'无可见内容':item.board.name)+'</small></span></button></div>';
  }).join(''):'<div class="lab-assets-empty">暂无手动切图</div>')+'</div><div class="asset-footer"><label class="asset-select-all"><input type="checkbox" id="labAll" '+(items.length&&items.every(function(i){return i.checked})?'checked':'')+'>全选</label>'+labFields('labBatch')+'<button class="asset-download-primary" id="labBatchDownload">打包下载</button></div>';
  function syncAll(){var all=$('labAll'),available=items.filter(function(i){return !i.layer.labSliceError});all.checked=!!available.length&&available.every(function(i){return i.checked});all.indeterminate=!all.checked&&available.some(function(i){return i.checked});}
  document.querySelectorAll('[data-lab-item]').forEach(function(el){el.onchange=function(){var item=labItems.find(function(i){return i.key===el.dataset.labItem});item.checked=el.checked;syncAll();}});
  document.querySelectorAll('[data-lab-open]').forEach(function(el){el.onclick=function(){
    var item=items.find(function(i){return i.key===el.dataset.labOpen});if(!item)return;
    var index=project.artboards.indexOf(item.board);
    if(state.boardIndex!==index){state.boardIndex=index;renderStage();}
    selectLayer(item.board.layers.indexOf(item.layer));renderAssets();
  }});
  $('labAll').onchange=function(){items.forEach(function(i){i.checked=!i.layer.labSliceError&&$('labAll').checked});renderAssets()};
  labBindFields('labBatch',function(){renderAssets();renderInspector()});
  $('labBatchDownload').onclick=function(){labDownload(items.filter(function(i){return i.checked}),this)};
  $('assetList').querySelector('.asset-items').scrollTop=scrollTop;syncAll();labRenderThumbs(items);
};
var labCodePanel=codePanel;
codePanel=function(l){return (l.labCodeWarning?'<section class="lanhu-section"><p class="lab-warning">'+esc(l.labCodeWarning)+'</p></section>':'')+labCodePanel(l)};

// One camera for the whole document. Only the active board owns hit targets;
// inspector and measurement coordinates remain local to that board.
var labScene=null,labRenderingBoard=false,labSingleBoardRenderer=renderStage;
labStyle.textContent+='#canvasScroll{overflow:hidden}#stageWrap{width:100%;height:100%;min-width:0;min-height:0}.lab-world{position:absolute;left:0;top:0;transform-origin:0 0;will-change:transform}.lab-artboard{position:absolute;background:#fff;box-shadow:0 2px 12px rgba(0,0,0,.1)}.lab-artboard>.board-image[hidden]{display:none}.lab-artboard>#stage{left:0;top:0;transform:none!important;box-shadow:none}.lab-artboard-title{position:absolute;z-index:2147483100;bottom:100%;left:0;transform:scale(var(--scene-inverse,1));transform-origin:0 100%;height:28px;width:max-content;max-width:240px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding:0 0 8px;border:0;border-radius:0;background:transparent;color:rgba(0,0,0,.6);font-size:12px;text-align:left;cursor:pointer}.lab-artboard.active>.lab-artboard-title{color:#2878ff}';
function labBoardPositions(boards){
  var pages=[],byPage=Object.create(null),positions=[],width=0,height=0;
  boards.forEach(function(b,i){
    var key=String(b.pageObjectID||b.pageName||''),page=byPage[key];
    if(!page){page={items:[],left:Infinity,top:Infinity,right:-Infinity,bottom:-Infinity,fallbackX:0};byPage[key]=page;pages.push(page)}
    var p=b.canvasPosition,valid=p&&Number.isFinite(p.x)&&Number.isFinite(p.y);
    var x=valid?p.x:page.fallbackX,y=valid?p.y:0;
    page.items.push({index:i,x:x,y:y});page.fallbackX=x+b.width+120;
    page.left=Math.min(page.left,x);page.top=Math.min(page.top,y);page.right=Math.max(page.right,x+b.width);page.bottom=Math.max(page.bottom,y+b.height);
  });
  // Sketch pages have separate coordinate systems. Translate each page as one
  // rigid region; never change any pairwise board positions within that page.
  pages.forEach(function(page){
    page.items.forEach(function(item){positions[item.index]={x:item.x-page.left+width,y:item.y-page.top}});
    width+=page.right-page.left+480;height=Math.max(height,page.bottom-page.top);
  });
  return{positions:positions,width:Math.max(1,width-480),height:Math.max(1,height)};
}
function labCreateScene(){
  if(labScene)return;
  var world=document.createElement('div');world.className='lab-world';world.id='labWorld';
  var layout=labBoardPositions(project.artboards);
  labScene={world:world,boards:[],width:layout.width,height:layout.height};
  project.artboards.forEach(function(b,i){
    var shell=document.createElement('div'),x=layout.positions[i].x,y=layout.positions[i].y;
    shell.className='lab-artboard';shell.setAttribute('data-scene-board',i);
    shell.style.cssText='left:'+x+'px;top:'+y+'px;width:'+b.width+'px;height:'+b.height+'px';
    shell.innerHTML='<button class="lab-artboard-title" type="button" title="'+display(b.name)+'">'+display(b.name)+'</button><img class="board-image" src="'+esc(b.imagePath)+'" alt="'+display(b.name)+'" decoding="async">';
    world.appendChild(shell);labScene.boards.push({shell:shell,title:shell.querySelector('.lab-artboard-title'),x:x,y:y,width:b.width,height:b.height});
  });
  $('stageWrap').insertBefore(world,$('measureOverlay'));
}
function labStopZoom(){if(zoomFrame)cancelFrame(zoomFrame);zoomFrame=0;zoomAnchor=null;state.zoom=state.renderedZoom}
zoomAnchorAt=function(clientX,clientY){
  var rect=$('canvasScroll').getBoundingClientRect(),z=state.renderedZoom;
  return{clientX:clientX,clientY:clientY,worldX:(clientX-rect.left-state.panX)/z,worldY:(clientY-rect.top-state.panY)/z};
};
resizeZoomSurface=function(){/* The viewport never scrolls; the shared camera pans. */};
paintZoom=function(value,anchor){
  if(!labScene)return;
  if(anchor){var rect=$('canvasScroll').getBoundingClientRect();state.panX=anchor.clientX-rect.left-anchor.worldX*value;state.panY=anchor.clientY-rect.top-anchor.worldY*value}
  labScene.world.style.transform='translate('+state.panX+'px,'+state.panY+'px) scale('+value+')';
  labScene.world.style.setProperty('--scene-inverse',1/value);
  if(labScene.hitZoom!==value||labScene.hitStage!==$('stage').firstChild){
    labScene.hitZoom=value;labScene.hitStage=$('stage').firstChild;updateHitTargets(value);
  }
  layoutSpacingLabels();layoutInternalLabels();
};
applyZoom=function(immediate,clientX,clientY){
  state.zoom=Math.max(.001,Math.min(4,state.zoom));$('zoomValueTop').textContent=Math.round(state.zoom*100)+'%';
  if(immediate){if(zoomFrame)cancelFrame(zoomFrame);zoomFrame=0;zoomAnchor=null;state.renderedZoom=state.zoom;paintZoom(state.renderedZoom,null);return}
  var rect=$('canvasScroll').getBoundingClientRect();
  if(clientX==null||clientY==null){clientX=rect.left+rect.width/2;clientY=rect.top+rect.height/2}
  zoomAnchor=zoomAnchorAt(clientX,clientY);
  if(zoomFrame)return;
  function step(){var difference=state.zoom-state.renderedZoom;if(Math.abs(difference)<.00001){state.renderedZoom=state.zoom;zoomFrame=0;paintZoom(state.renderedZoom,zoomAnchor);return}state.renderedZoom+=difference*.22;paintZoom(state.renderedZoom,zoomAnchor);zoomFrame=requestFrame(step)}
  zoomFrame=requestFrame(step);
};
function labFocusBounds(bounds){
  labStopZoom();var canvas=$('canvasScroll');
  state.zoom=Math.max(.001,Math.min(1,Math.max(1,canvas.clientWidth-96)/bounds.width,Math.max(1,canvas.clientHeight-112)/bounds.height));
  state.panX=canvas.clientWidth/2-(bounds.x+bounds.width/2)*state.zoom;
  state.panY=canvas.clientHeight/2-(bounds.y+bounds.height/2)*state.zoom;
  applyZoom(true);
}
fitBoard=function(){if(!labRenderingBoard&&labScene)labFocusBounds(labScene.boards[state.boardIndex])};
renderStage=function(keepCamera){
  var first=!labScene;labCreateScene();labStopZoom();
  var x=state.panX,y=state.panY,stage=$('stage');
  labScene.boards.forEach(function(entry,i){entry.shell.classList.toggle('active',i===state.selectedBoardIndex);entry.shell.querySelector(':scope > .board-image').hidden=i===state.boardIndex});
  labScene.boards[state.boardIndex].shell.appendChild(stage);
  labRenderingBoard=true;
  try{labSingleBoardRenderer()}finally{labRenderingBoard=false}
  state.panX=x;state.panY=y;
  if(first)labFocusBounds({x:0,y:0,width:labScene.width,height:labScene.height});
  else if(keepCamera)paintZoom(state.renderedZoom,null);
  else fitBoard();
};
$('canvasScroll').addEventListener('pointerdown',function(){labStopZoom()},{capture:true});
$('canvasScroll').addEventListener('click',function(e){
  var shell=e.target.closest('[data-scene-board]');
  if(!shell||pan.moved||pan.suppressClick||pan.spaceHeld)return;
  var index=Number(shell.getAttribute('data-scene-board'));
  if(e.target.closest('.lab-artboard-title')){e.preventDefault();e.stopPropagation();state.boardIndex=index;renderStage();setSelectedBoard(index);return}
  if(index===state.boardIndex)return;
  e.stopPropagation();state.boardIndex=index;renderStage(true);setSelectedBoard(index);
  if(e.metaKey||e.ctrlKey)selectDeepestLayerAtPoint(e);else selectDefaultLayerAtPoint(e);
},{capture:true});
