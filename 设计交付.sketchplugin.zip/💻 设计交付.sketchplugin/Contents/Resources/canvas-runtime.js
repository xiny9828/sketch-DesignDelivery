// The standalone bootstrap also handles errors before the main runtime loads.
var DELIVERY_PLUGIN_CONTEXT = null;
// Carry a useful title with expected validation errors; retain Error.message
// for logs and callers without coupling the UI to string matching.
function deliveryError(title, message) {
  var error=new Error(message);error.deliveryTitle=title;return error;
}
function deliveryShowError(error, title, pluginContext) {
  var message=String(error.message||error);
  if(!error.deliveryTitle){
    if(title==='暂时无法完成导出')message+='\n\n请检查设计稿和保存位置后重试。如果仍然失败，请保留导出文件夹中的“导出未完成.txt”，方便排查。';
    else if(!/请|可以|重试/.test(message))message+='\n\n请重试此操作。如果仍然出现此提示，请将提示内容反馈给插件作者。';
  }
  return deliveryAlert(error.deliveryTitle||title||'暂时无法完成操作',message,['知道了'],0,pluginContext);
}
function deliveryAlert(title, message, buttons, primary, pluginContext) {
  buttons=buttons&&buttons.length?buttons:['知道了'];primary=primary||0;
  var presentation=deliveryDialogPresentation(message,buttons);title=presentation.title;message=presentation.message;
  try {
    var cls=NSClassFromString('SMDeliveryAlertControllerV62'),ctx=pluginContext||DELIVERY_PLUGIN_CONTEXT;
    if(!cls&&ctx){
      var url=ctx.plugin.urlForResourceNamed('NativeDeveloperV62.bundle');
      if(url){var bundle=NSBundle.bundleWithPath(String(url.path()));if(bundle)bundle.load();}
      cls=NSClassFromString('SMDeliveryAlertControllerV62');
    }
    if(cls){var parent=NSApp.modalWindow()||NSApp.keyWindow();return Number(cls.showJSON_forWindow(JSON.stringify({title:String(title),message:String(message||''),buttons:buttons,primary:primary}),parent))-1000;}
  } catch(error){console.error('提示组件加载失败：'+String(error));}
  // Keep an OS fallback when the native component itself is missing or corrupt.
  return deliverySystemAlert(title,message,buttons,primary);
}

// NSAlert lays out its first button on the right. Preserve logical result
// indices while placing cancellation on the left, including OS fallback UI.
function deliveryDialogPresentation(message,buttons) {
  var confirmation=(buttons||[]).some(function(label){return /^(删除|放弃|delete|discard)/i.test(String(label));});
  return {title:confirmation?'操作确认':'提示',message:String(message||'').replace(/[。．.]+(?=[ \t]*(?:\r?\n|$))/g,'')};
}
function deliverySystemAlert(title,message,buttons,primary) {
  buttons=buttons&&buttons.length?buttons:['知道了'];primary=Math.max(0,Math.min(buttons.length-1,Number(primary)||0));
  var presentation=deliveryDialogPresentation(message,buttons);title=presentation.title;message=presentation.message;
  var cancel=-1,order=[];
  buttons.some(function(label,index){if(/^(取消.*|关闭|继续编辑|cancel|close)$/i.test(String(label))){cancel=index;return true;}return false;});
  if(primary===cancel&&buttons.length>1){for(var i=buttons.length-1;i>=0;i--)if(i!==cancel){primary=i;break;}}
  if(cancel>=0)order.push(cancel);
  buttons.forEach(function(label,index){if(index!==cancel&&index!==primary)order.push(index);});
  if(primary!==cancel)order.push(primary);
  order.reverse();
  var fallback=NSAlert.alloc().init();fallback.setMessageText(String(title));fallback.setInformativeText(String(message||''));
  order.forEach(function(index){var button=fallback.addButtonWithTitle(String(buttons[index]));if(index===primary){button.setKeyEquivalent('\r');button.setKeyEquivalentModifierMask(0);fallback.window().setDefaultButtonCell(button.cell());}else button.setKeyEquivalent('');if(index===cancel){if(index!==primary)button.setKeyEquivalent('\u001b');button.setKeyEquivalentModifierMask(0);}});
  var result=Number(fallback.runModal())-1000;
  return result>=0&&result<order.length?order[result]:(cancel>=0?cancel:primary);
}

var sketch = require('sketch');
var dom = require('sketch/dom');
var Settings = require('sketch/settings');
var UI = require('sketch/ui');
function number(value, fallback) {
  var n = Number(value);
  return value != null && isFinite(n) ? n : (fallback || 0);
}
function round(value) { return Math.round(number(value) * 100) / 100; }
function any(list, predicate) {
  for (var i = 0; i < list.length; i++) if (predicate(list[i], i)) return true;
  return false;
}
function html(value) {
  return String(value == null ? '' : value).split('&').join('&amp;').split('<').join('&lt;')
    .split('>').join('&gt;').split('"').join('&quot;').split("'").join('&#39;');
}
function scriptJSON(value) {
  return JSON.stringify(value).split('<').join('\\u003c').split('\u2028').join('\\u2028').split('\u2029').join('\\u2029');
}
function safeName(value) {
  var result = String(value || '切图').split('/').join('_').split('\\').join('_').split(':').join('_').split('*').join('_').split('?').join('_').split('"').join('_').split('<').join('_').split('>').join('_').split('|').join('_');
  while (result.charAt(0) === '.') result = '_' + result.slice(1);
  return result.slice(0, 80);
}
function safeFolder(value) {
  var raw = String(value || '切图'), cleaned = safeName(raw);
  if (raw.length <= 64) return cleaned;
  var hash = 5381;
  for (var i = 0; i < raw.length; i++) hash = ((hash * 33) ^ raw.charCodeAt(i)) >>> 0;
  return cleaned.slice(0, 56) + '-' + hash.toString(36);
}
function color(value) {
  var hex = String(value || '#00000000').replace(/^#/, '');
  if (hex.length === 3 || hex.length === 4) hex = hex.split('').map(function (s) { return s + s; }).join('');
  if (!/^[0-9a-f]{6}([0-9a-f]{2})?$/i.test(hex)) throw new Error('无法解析颜色：' + value);
  if (hex.length === 6) hex += 'ff';
  var r = parseInt(hex.slice(0, 2), 16), g = parseInt(hex.slice(2, 4), 16), b = parseInt(hex.slice(4, 6), 16);
  var a = Math.round(parseInt(hex.slice(6, 8), 16) / 255 * 1000) / 1000;
  return { r: r, g: g, b: b, a: a, 'color-hex': '#' + hex.slice(0, 6).toUpperCase() + (a < 1 ? ' ' + Math.round(a * 100) + '%' : ''),
    'argb-hex': '#' + (hex.slice(6, 8) + hex.slice(0, 6)).toUpperCase(),
    'css-rgba': 'rgba(' + r + ', ' + g + ', ' + b + ', ' + a + ')',
    'css-rgb': 'rgb(' + r + ', ' + g + ', ' + b + ')' };
}
function documentColorVariables(d) {
  var result = [], swatches = [];
  try { swatches = d.swatches || []; } catch (error) { swatches = []; }
  swatches.forEach(function (swatch) {
    try {
      if (!swatch || !swatch.color) return;
      result.push({ id: String(swatch.id || ''), name: html(swatch.name || '未命名颜色'), color: color(swatch.color) });
    } catch (error) {}
  });
  return result;
}
function swatchReference(value) {
  var swatch = null;
  try { swatch = value && value.swatch; } catch (error) { swatch = null; }
  if (!swatch) return null;
  return { id: String(swatch.id || ''), name: html(swatch.name || '未命名颜色') };
}
function isMark(layer) {
  var name = String(layer.name || '');
  if (name.indexOf('__SM_ZH_MARK__') === 0) return true;
  var legacyPrefixes = ['OVERLAY#', 'WIDTH#', 'HEIGHT#', 'TOP#', 'RIGHT#', 'BOTTOM#', 'LEFT#',
    'VERTICAL#', 'HORIZONTAL#', 'NOTE#', 'PROPERTY#', 'LITE#'];
  for (var i = 0; i < legacyPrefixes.length; i++) {
    if (name.indexOf(legacyPrefixes[i]) === 0) return true;
  }
  return false;
}
function isLayerHidden(layer) {
  if (!layer) return true;
  try { if (layer.hidden === true) return true; } catch (error) {}
  try { if (layer.visible === false) return true; } catch (error) {}
  try {
    var nativeLayer = layer.sketchObject;
    if (nativeLayer && nativeLayer.isVisible && !Boolean(nativeLayer.isVisible())) return true;
    if (nativeLayer && nativeLayer.isHidden && Boolean(nativeLayer.isHidden())) return true;
  } catch (error) {}
  return false;
}
function isBoard(layer) {
  return layer.type === 'Artboard' || (layer.type === 'Group' && layer.isFrame && !layer.isGraphicFrame);
}
function gradient(g) {
  return { type: String(g.gradientType || 'Linear').toLowerCase(), from: g.from, to: g.to,
    colorStops: g.stops.map(function (stop) { return { position: stop.position, color: color(stop.color),
      variable: swatchReference(stop) }; }) };
}
function fill(f) {
  var type = String(f.fillType).toLowerCase();
  if (type !== 'color' && type !== 'gradient') return null;
  var result = { fillType: type, color: color(f.color), blendingMode: String(f.blendingMode || 'Normal'),
    variable: swatchReference(f) };
  if (type === 'gradient') result.gradient = gradient(f.gradient);
  return result;
}
function rect(layer, board) {
  // Layout space must not mix a transformed origin with untransformed dimensions.
  // Rectangle.changeBasis transforms only the origin in Sketch. Project all four
  // corners separately for canvas hit testing after layout has been resolved.
  var r = localRect(layer), parent = layer.parent;
  while (parent && parent !== board && parent.id !== board.id) {
    r.x += number(parent.frame.x); r.y += number(parent.frame.y);
    parent = parent.parent;
  }
  return { x: round(r.x), y: round(r.y), width: r.width, height: r.height };
}
function hasCanvasTransform(layer, board) {
  while (layer && layer !== board && layer.id !== board.id) {
    var t = layer.transform || {};
    if (number(t.rotation) || t.flippedHorizontally || t.flippedVertically) return true;
    layer = layer.parent;
  }
  return false;
}
function intersect(a, b) {
  var x = Math.max(a.x, b.x), y = Math.max(a.y, b.y);
  return { x: x, y: y, width: Math.max(0, Math.min(a.x + a.width, b.x + b.width) - x),
    height: Math.max(0, Math.min(a.y + a.height, b.y + b.height) - y) };
}
function unionRect(a, b) {
  if (!a) return b ? { x: b.x, y: b.y, width: b.width, height: b.height } : null;
  if (!b) return { x: a.x, y: a.y, width: a.width, height: a.height };
  var x = Math.min(a.x, b.x), y = Math.min(a.y, b.y);
  return { x: round(x), y: round(y), width: round(Math.max(a.x + a.width, b.x + b.width) - x),
    height: round(Math.max(a.y + a.height, b.y + b.height) - y) };
}
function radius(layer, style) {
  style = style || layer.style;
  var corners = style && style.corners;
  if (corners && corners.hasRadii) return [0, 1, 2, 3].map(function (i) { return round(corners.radiusAt(i)); });
  var points = layer.points;
  if (points && points.length) return points.slice(0, 4).map(function (p) { return round(p.cornerRadius); });
  return [0, 0, 0, 0];
}
function gradientCSS(g, r) {
  var stops = g.colorStops.map(function (s) { return s.color['css-rgba'] + ' ' + round(s.position * 100) + '%'; }).join(', ');
  if (g.type === 'radial') return 'radial-gradient(ellipse at ' + round(g.from.x * 100) + '% ' + round(g.from.y * 100) + '%, ' + stops + ')';
  var dx = (g.to.x - g.from.x) * r.width, dy = (g.to.y - g.from.y) * r.height;
  var angle = round(Math.atan2(dx, -dy) * 180 / Math.PI);
  if (g.type === 'angular') return 'conic-gradient(from ' + angle + 'deg at ' + round(g.from.x * 100) + '% ' + round(g.from.y * 100) + '%, ' + stops + ')';
  return 'linear-gradient(' + angle + 'deg, ' + stops + ')';
}
function enumName(value, names, fallback) {
  var index = number(value, -1);
  return names[index] == null ? (fallback || String(index)) : names[index];
}
function paddingValues(value) {
  if (typeof value === 'number') return { top: value, right: value, bottom: value, left: value };
  value = value || {};
  var vertical = number(value.vertical), horizontal = number(value.horizontal);
  return { top: number(value.top, vertical), right: number(value.right, horizontal),
    bottom: number(value.bottom, vertical), left: number(value.left, horizontal) };
}
function stackLayoutData(layer) {
  var layout;
  try { layout = layer && layer.stackLayout; } catch (error) { layout = null; }
  if (!layout) return null;
  var padding = paddingValues(layout.padding);
  return { direction: enumName(layout.direction, ['row', 'column'], 'row'),
    justifyContent: enumName(layout.justifyContent, ['flex-start', 'center', 'flex-end', 'space-between', 'space-around', 'space-evenly'], 'flex-start'),
    alignItems: enumName(layout.alignItems, ['flex-start', 'center', 'flex-end', 'stretch', 'stretch', 'normal'], 'normal'),
    gap: round(layout.gap), padding: { top: round(padding.top), right: round(padding.right),
      bottom: round(padding.bottom), left: round(padding.left) }, wraps: Boolean(layout.wraps),
    alignContent: enumName(layout.alignContent, ['flex-start', 'center', 'flex-end', 'space-between', 'space-around', 'space-evenly'], 'flex-start'),
    crossAxisGap: round(layout.crossAxisGap),
    stackingOrder: number(layout.stackingOrder) === 1 ? 'last-on-top' : 'first-on-top',
    bordersAffectLayout: Boolean(layout.bordersAffectLayout) };
}
function sizeValue(value) {
  if (!value) return null;
  return { width: round(value.width), height: round(value.height) };
}
function layoutItemData(layer) {
  return { horizontalSizing: enumName(layer.horizontalSizing, ['fixed', 'fit', 'fill', 'relative'], 'fixed'),
    verticalSizing: enumName(layer.verticalSizing, ['fixed', 'fit', 'fill', 'relative'], 'fixed'),
    horizontalPins: enumName(layer.horizontalPins, ['none', 'min', 'none', 'none', 'max', 'all'], 'none'),
    verticalPins: enumName(layer.verticalPins, ['none', 'min', 'none', 'none', 'max', 'all'], 'none'),
    ignoresStackLayout: Boolean(layer.ignoresStackLayout),
    preservesSpaceWhenHidden: Boolean(layer.preservesSpaceInStackLayoutWhenHidden),
    minSize: sizeValue(layer.minSize), maxSize: sizeValue(layer.maxSize),
    percentageSize: sizeValue(layer.percentageSize) };
}
function localRect(layer) {
  var frame = layer.frame;
  return { x: round(frame.x), y: round(frame.y), width: round(frame.width), height: round(frame.height) };
}
function layoutSizeCSS(lines, data, px) {
  var item = data.layoutItem || {}, parent = data.parentAutoLayout;
  // Sketch's fixed stack children overflow rather than silently shrinking.
  lines.push('flex-shrink: 0;');
  function axis(property, sizingName, size, crossAxis) {
    var sizing = item[sizingName + 'Sizing'] || 'fixed';
    if (sizing === 'fixed') lines.push(property + ': ' + px(size) + ';');
    else if (sizing === 'fit') lines.push(property + ': fit-content;');
    else if (sizing === 'relative') {
      var percentage = item.percentageSize && number(item.percentageSize[property]);
      if (!(percentage > 0) && data.parentRect && number(data.parentRect[property]) > 0) percentage = size / number(data.parentRect[property]);
      lines.push(property + ': ' + (percentage > 0 ? round(percentage > 1 ? percentage : percentage * 100) + '%' : px(size)) + ';');
    } else if (sizing === 'fill') {
      if (crossAxis) lines.push('align-self: stretch;', property + ': auto;');
      else lines.push('flex: 1 1 0;', property + ': auto;');
    }
  }
  axis('width', 'horizontal', data.logicalRect.width, parent.direction === 'column');
  axis('height', 'vertical', data.logicalRect.height, parent.direction === 'row');
  ['width', 'height'].forEach(function (axis) {
    // Sketch uses zero for an unset constraint on an individual axis.
    if (item.minSize && item.minSize[axis] > 0) lines.push('min-' + axis + ': ' + px(item.minSize[axis]) + ';');
    if (item.maxSize && item.maxSize[axis] > 0) lines.push('max-' + axis + ': ' + px(item.maxSize[axis]) + ';');
  });
}
function cssColor(c, variable) {
  var fallback = c['css-rgba'];
  if (!variable || !variable.name) return fallback;
  var token = String(variable.name).replace(/[^\w\u0080-\uFFFF-]+/g, '-');
  return 'var(--' + token + ', ' + fallback + ')';
}
function css(data, scale) {
  var r = data.logicalRect || data.rect;
  var px = function (n) { return round(n / scale) + 'px'; };
  var inStack = data.parentAutoLayout && data.layoutItem && !data.layoutItem.ignoresStackLayout;
  var local = data.localRect || r;
  var lines = ['box-sizing: border-box;'];
  if (inStack) layoutSizeCSS(lines, data, px);
  else lines.unshift('position: absolute;', 'left: ' + px(local.x) + ';', 'top: ' + px(local.y) + ';',
    'width: ' + px(local.width) + ';', 'height: ' + px(local.height) + ';');
  if (data.autoLayout) {
    var layout = data.autoLayout, padding = layout.padding;
    var layoutBorder = 0;
    if (layout.bordersAffectLayout && !(data.borders.length === 1 && data.borders[0].position === 'inside' && data.borders[0].fillType !== 'gradient')) {
      data.borders.forEach(function (b) { layoutBorder = Math.max(layoutBorder, b.thickness * (b.position === 'outside' ? 0 : b.position === 'center' ? 0.5 : 1)); });
    }
    lines.push('display: flex;', 'flex-direction: ' + layout.direction + ';',
      'justify-content: ' + layout.justifyContent + ';', 'align-items: ' + layout.alignItems + ';');
    if (layout.wraps) lines.push('flex-wrap: wrap;', 'align-content: ' + layout.alignContent + ';');
    if (layout.wraps && layout.crossAxisGap !== layout.gap) {
      lines.push((layout.direction === 'row' ? 'column-gap: ' : 'row-gap: ') + px(layout.gap) + ';',
        (layout.direction === 'row' ? 'row-gap: ' : 'column-gap: ') + px(layout.crossAxisGap) + ';');
    } else lines.push('gap: ' + px(layout.gap) + ';');
    if (layoutBorder) lines.push('/* 包含参与布局的描边占位 ' + px(layoutBorder) + ' */');
    lines.push('padding: ' + [padding.top, padding.right, padding.bottom, padding.left].map(function (v) { return px(number(v) + layoutBorder); }).join(' ') + ';');
  }
  if (data.opacity < 1) lines.push('opacity: ' + data.opacity + ';');
  if (data.hidden) lines.push(data.layoutItem && data.layoutItem.preservesSpaceWhenHidden ? 'visibility: hidden;' : 'display: none;');
  var transforms = [];
  if (data.flippedHorizontally || data.flippedVertically) transforms.push('scale(' +
    (data.flippedHorizontally ? -1 : 1) + ', ' + (data.flippedVertically ? -1 : 1) + ')');
  if (data.rotation) transforms.push('rotate(' + data.rotation + 'deg)');
  if (transforms.length) lines.push('transform: ' + transforms.join(' ') + ';');
  if (any(data.cornerRadii, function (v) { return v > 0; })) lines.push('border-radius: ' + data.cornerRadii.map(px).join(' ') + ';');
  if (data.fills.length && data.type !== 'text') {
    var fills = data.fills.slice().reverse().map(function (f) {
      return f.fillType === 'gradient' ? gradientCSS(f.gradient, r) : 'linear-gradient(' + cssColor(f.color, f.variable) + ', ' + cssColor(f.color, f.variable) + ')';
    });
    lines.push(data.fills.length === 1 && data.fills[0].fillType === 'color' ?
      'background-color: ' + cssColor(data.fills[0].color, data.fills[0].variable) + ';' : 'background: ' + fills.join(', ') + ';');
  }
  var borderShadows = [];
  data.borders.slice().reverse().forEach(function (border) {
    if (border.fillType === 'gradient') {
      lines.push('/* 渐变描边需单独绘制：' + border.position + ', ' + px(border.thickness) + ', ' + gradientCSS(border.gradient, r) + ' */');
      return;
    }
    if (data.autoLayout && data.autoLayout.bordersAffectLayout && data.borders.length === 1 && border.position === 'inside') {
      lines.push('border: ' + px(border.thickness) + ' solid ' + cssColor(border.color, border.variable) + ';');
      return;
    }
    var width = border.position === 'center' ? border.thickness / 2 : border.thickness;
    var paint = '0 0 0 ' + px(width) + ' ' + cssColor(border.color, border.variable);
    if (border.position !== 'outside') borderShadows.push('inset ' + paint);
    if (border.position !== 'inside') borderShadows.push(paint);
  });
  var shadows = borderShadows.concat(data.shadows.map(function (s) {
    return (s.type === 'inner' ? 'inset ' : '') + [px(s.offsetX), px(s.offsetY), px(s.blurRadius), px(s.spread), cssColor(s.color, s.variable)].join(' ');
  }));
  if (shadows.length) lines.push('box-shadow: ' + shadows.join(', ') + ';');
  if (data.type === 'text' && data.fontSize > 0) {
    // Sketch's menu script preprocessor misreads escaped comment tokens in regex literals.
    var weightName = String(data.fontWeightName || '').split('/' + '*').join('').split('*' + '/').join('').replace(/[\r\n\u2028\u2029]/g, ' ').trim();
    lines.push('font-family: "' + String(data.fontFace).split('\\').join('\\\\').split('"').join('\\"').split('\r').join('').split('\n').join('') + '";',
      'font-size: ' + px(data.fontSize) + ';', 'font-weight: ' + (weightName ? '/* ' + weightName + ' */ ' : '') + data.fontWeight + ';',
      'color: ' + cssColor(data.color, data.textVariable) + ';', 'line-height: ' + px(data.lineHeight) + ';',
      'letter-spacing: ' + px(data.letterSpacing) + ';', 'text-align: ' + data.textAlign + ';');
    var textFill = data.fills && data.fills[0];
    if (textFill && textFill.fillType === 'gradient' && textFill.gradient) {
      lines.push('background: ' + gradientCSS(textFill.gradient, r) + ';',
        '-webkit-background-clip: text;', 'background-clip: text;',
        '-webkit-text-fill-color: transparent;');
    }
    if (data.fontStyle && data.fontStyle.toLowerCase() !== 'normal') lines.push('font-style: ' + data.fontStyle.toLowerCase() + ';');
    if (data.fontStretch && data.fontStretch.toLowerCase() !== 'normal') lines.push('font-stretch: ' + data.fontStretch.toLowerCase() + ';');
    if (data.fontVariant && data.fontVariant.toLowerCase() !== 'normal') lines.push('font-variant: ' + data.fontVariant.toLowerCase() + ';');
    if (data.textTransform && data.textTransform.toLowerCase() !== 'none') lines.push('text-transform: ' + data.textTransform.toLowerCase() + ';');
    var decorations = [];
    if (data.textUnderline && data.textUnderline.toLowerCase() !== 'none') decorations.push('underline');
    if (data.textStrikethrough && data.textStrikethrough.toLowerCase() !== 'none') decorations.push('line-through');
    if (decorations.length) lines.push('text-decoration: ' + decorations.join(' ') + ';');
  }
  return lines;
}
function fontWeight(value) {
  var n = number(value, 5);
  if (n >= 100) return round(n);
  return [100, 200, 300, 400, 400, 400, 500, 600, 700, 800, 900, 900][Math.round(n)] || 400;
}
function fontWeightName(layer) {
  // Read the selected font face, including named instances of variable fonts.
  // CSS's normal/italic style and a numeric weight cannot supply this name.
  try {
    var font = layer.sketchObject.font();
    var face = font && font.fontDescriptor().objectForKey(NSFontFaceAttribute);
    if (face != null) return String(face).trim();
  } catch (error) {}
  return '';
}
function layerData(layer, board, config, effectiveOpacity) {
  var style = layer.style, transform = layer.transform;
  var data = { objectID: layer.id, name: html(layer.name), type: layer.type === 'Text' ? 'text' :
    layer.type === 'Slice' || layer.type === 'Image' ? 'slice' : layer.type === 'SymbolInstance' ? 'symbol' :
      layer.type === 'Group' ? 'group' : 'shape',
    nativeType: String(layer.type || ''), shapeType: String(layer.shapeType || ''),
    rect: rect(layer, board), localRect: localRect(layer), rotation: round(transform.rotation),
    flippedHorizontally: Boolean(transform.flippedHorizontally),
    flippedVertically: Boolean(transform.flippedVertically),
    opacity: style ? number(style.opacity, 1) : 1, effectiveOpacity: effectiveOpacity,
    blendMode: style ? String(style.blendingMode || 'Normal') : 'Normal', radius: 0,
    cornerRadii: radius(layer, style), cornerStyle: '', cornerSmoothing: 0, fills: [], borders: [], shadows: [], css: [],
    autoLayout: stackLayoutData(layer), layoutItem: layoutItemData(layer), parentAutoLayout: null };
  data.radius = Math.max.apply(Math, data.cornerRadii);
  if (style) {
    var corners = style.corners;
    if (corners) {
      var cornerStyle = corners.style;
      data.cornerStyle = String(cornerStyle == null ? '' : cornerStyle);
      data.cornerSmoothing = round(corners.smoothing);
    }
    data.fills = style.fills.filter(function (f) { return f.enabled; }).map(fill).filter(Boolean);
    data.borders = style.borders.filter(function (f) { return f.enabled; }).map(function (b) {
      var f = fill(b);
      if (!f) return null;
      f.position = String(b.position).toLowerCase(); f.thickness = b.thickness; return f;
    }).filter(Boolean);
    ['shadows', 'innerShadows'].forEach(function (key) {
      style[key].filter(function (s) { return s.enabled; }).forEach(function (s) {
        data.shadows.push({ type: key === 'shadows' ? 'outer' : 'inner', offsetX: s.x, offsetY: s.y,
          blurRadius: s.blur, spread: s.spread, color: color(s.color), variable: swatchReference(s) });
      });
    });
    var sharedStyle = layer.sharedStyle;
    if (sharedStyle) data.styleName = html(sharedStyle.name);
  }
  if (layer.type === 'Text') {
    data.content = html(layer.text); data.color = color(style.textColor);
    var textSwatch = style.textSwatch;
    data.textVariable = textSwatch ? { id: String(textSwatch.id || ''), name: html(textSwatch.name || '未命名颜色') } : null;
    data.fontSize = style.fontSize; data.fontFace = style.fontFamily || 'sans-serif';
    data.fontPostscriptName = style.fontPostscriptName || data.fontFace;
    data.fontWeight = fontWeight(style.fontWeight); data.fontStyle = String(style.fontStyle || 'Normal');
    data.fontWeightName = fontWeightName(layer);
    data.fontVariant = String(style.fontVariant || 'Normal'); data.fontStretch = String(style.fontStretch || 'Normal');
    data.textTransform = String(style.textTransform || 'None'); data.textUnderline = String(style.textUnderline || 'None');
    data.textStrikethrough = String(style.textStrikethrough || 'None'); data.fontAxes = style.fontAxes || null;
    data.textAlign = style.alignment || 'left'; data.verticalAlign = style.verticalAlignment || 'top';
    data.letterSpacing = number(style.kerning);
    var defaultLineHeight = data.fontSize * 1.4;
    try { defaultLineHeight = number(style.getDefaultLineHeight(), defaultLineHeight); } catch (error) {}
    data.lineHeight = number(style.lineHeight) > 0 ? number(style.lineHeight) : defaultLineHeight;
    data.paragraphSpacing = number(style.paragraphSpacing);
  }
  data.css = css(data, config.scale).map(html);
  return data;
}
function document() {
  var d = dom.getSelectedDocument();
  if (!d) throw deliveryError('请先打开设计稿','打开或新建一个 Sketch 文档后，就可以使用交付工具。');
  return d;
}
function config() {
  var value = Settings.settingForKey('measure.zh-modern.settings');
  if (!value) { var legacy = NSUserDefaults.alloc().initWithSuiteName('plugin.sketch.com.utom.measure.zh-modern').objectForKey('measure.zh-modern.settings'); if (legacy) value = JSON.parse(String(legacy)); }
  value = value || {};
  var configuredScale = number(value.scale, 1);
  return { scale: configuredScale > 0 ? configuredScale : 1,
    unit: ['px', 'pt', 'dp/sp'].indexOf(value.unit) >= 0 ? value.unit : 'px',
    colorFormat: ['color-hex', 'css-rgba', 'argb-hex'].indexOf(value.colorFormat) >= 0 ? value.colorFormat : 'color-hex',
    webSlices: value.webSlices !== false, zip: value.zip !== false };
}
function run(action, failureTitle) {
  try { return action(); }
  catch (error) { console.error(error.stack || error); deliveryShowError(error, failureTitle); }
}
function alert(title, message, buttons, accessory) { return deliveryAlert(title, message, buttons || ['确定'], 0); }

function field(value, x, y, width) {
  var input = NSTextField.alloc().initWithFrame(NSMakeRect(x, y, width, 24));
  input.setStringValue(String(value)); return input;
}
function label(value, x, y, width) {
  var text = field(value, x, y, width); text.setEditable(false); text.setSelectable(false);
  text.setBezeled(false); text.setDrawsBackground(false); return text;
}
function popup(values, selected, x, y, width) {
  var p = NSPopUpButton.alloc().initWithFrame_pullsDown(NSMakeRect(x, y, width, 28), false);
  values.forEach(function (v) { p.addItemWithTitle(v); }); p.selectItemAtIndex(selected); return p;
}
function checkbox(title, checked, y) {
  var b = NSButton.alloc().initWithFrame(NSMakeRect(0, y, 340, 24));
  b.setButtonType(3); b.setTitle(title); b.setState(checked ? 1 : 0); return b;
}
function commandSettings(context) { return run(function () {
  nativeDeveloperLoadBundle(context);
  var c=config(),profile=devProfile();
  var dialog=NSClassFromString('SMDeliverySettingsControllerV62');
  if(!dialog)throw new Error('设置组件不完整，请重新安装完整插件。');
  var payload={name:profile.name,avatar:profile.avatar,scale:c.scale,unit:c.unit,colorFormat:c.colorFormat,webSlices:c.webSlices,zip:c.zip};
  var saved=dialog.showSettingsJSON_forWindow(JSON.stringify(payload),document().sketchObject.documentWindow());
  if(!saved||!String(saved).length)return;
  var result=JSON.parse(String(saved)),author=String(result.name||'').trim(),avatar=devSafeAvatar(result.avatar),scale=Number(result.scale);
  if(!author||author.length>80||!avatar||!isFinite(scale)||scale<=0||scale>100)throw deliveryError('设置尚未保存','请检查标注名字、头像和设计倍率，再点击保存。名字最多 80 个字，倍率需大于 0 且不超过 100。');
  Settings.setSettingForKey('measure.zh-modern.settings',{scale:scale,unit:result.unit,colorFormat:result.colorFormat,webSlices:!!result.webSlices,zip:!!result.zip});
  Settings.setSettingForKey(DEV_PROFILE_KEY,{name:author,avatar:avatar});
  UI.message('交付设置与标注身份已保存。');
}); }
function getBoards(d, scope) {
  var boards = [];
  function collect(layer) {
    if (isMark(layer)) return;
    if (layer.type === 'SymbolMaster' || layer.type === 'ForeignSymbol') return;
    if (isBoard(layer)) { boards.push(layer); return; }
    (layer.layers || []).forEach(collect);
  }
  if (scope === 'selected-board') {
    var selected = d.selectedLayers.layers;
    selected.forEach(function (layer) { if (isBoard(layer)) boards.push(layer); });
  }
  else if (scope === 'all') d.pages.forEach(function (p) { p.layers.forEach(collect); });
  else if (scope === 'page') d.selectedPage.layers.forEach(collect);
  else {
    d.selectedLayers.layers.forEach(function (l) {
      var found = l;
      while (found && found.type !== 'Page' && !isBoard(found)) found = found.parent;
      if (found && isBoard(found)) {
        while (found.parent && isBoard(found.parent)) found = found.parent;
        boards.push(found);
      } else if (l.layers) collect(l);
    });
    if (!boards.length) d.selectedPage.layers.forEach(collect);
  }
  var seen = {};
  return boards.filter(function (b) { if (seen[b.id]) return false; seen[b.id] = true; return b.frame.width > 0 && b.frame.height > 0; });
}
function resource(context, name) { return String(context.plugin.urlForResourceNamed(name).path()); }
function mkdir(path) {
  var manager = NSFileManager.defaultManager();
  var error = null;
  if (!manager.createDirectoryAtPath_withIntermediateDirectories_attributes_error(path, true, null, error)) {
    throw deliveryError('无法创建保存文件夹','请选择有写入权限的文件夹，并确认磁盘空间充足后重试。\n保存位置：' + path);
  }
}
function fileExists(path) { return NSFileManager.defaultManager().fileExistsAtPath(path); }
function readText(path) {
  return String(NSString.stringWithContentsOfFile_encoding_error(path, NSUTF8StringEncoding, null));
}
function writeText(path, value) {
  if (!NSString.stringWithString(String(value)).writeToFile_atomically_encoding_error(path, true, NSUTF8StringEncoding, null)) {
    throw deliveryError('无法保存交付文件','请确认保存位置可以写入、磁盘空间充足，再重新导出。\n文件位置：' + path);
  }
}
function writeDownloadPayload(path, relativePath) {
  var bytes = NSData.dataWithContentsOfFile(path);
  if (!bytes) throw new Error('无法读取导出的切图：' + path);
  var base64 = String(bytes.base64EncodedStringWithOptions(0));
  writeText(path + '.download.js', 'window.__SM_SLICE_PAYLOADS__=window.__SM_SLICE_PAYLOADS__||{};window.__SM_SLICE_PAYLOADS__[' +
    scriptJSON(relativePath) + ']=' + scriptJSON(base64) + ';');
}
function removePath(path) {
  NSFileManager.defaultManager().removeItemAtPath_error(path, null);
}
function decodedDocumentPath(d) {
  var path = '';
  try { path = String(d && d.path || ''); } catch (error) { path = ''; }
  if (!path) return '';
  try { path = String(NSString.stringWithString(path).stringByRemovingPercentEncoding()); } catch (error) {}
  return path;
}
function documentHasUnsavedChanges(d) {
  try {
    var nativeDocument = d && d.sketchObject;
    if (nativeDocument && nativeDocument.isKindOfClass(MSDocumentData)) nativeDocument = nativeDocument.delegate();
    return Boolean(nativeDocument && nativeDocument.isDocumentEdited && nativeDocument.isDocumentEdited());
  } catch (error) { return false; }
}
function openDocumentWithoutWindow(path) {
  var pointer = MOPointer.alloc().init();
  var nativeDocument = NSDocumentController.sharedDocumentController()
    .openDocumentWithContentsOfURL_display_error(NSURL.fileURLWithPath(path), false, pointer);
  if (pointer.value() && !pointer.value().isEqual(NSNull.null())) {
    throw new Error(String(pointer.value().localizedDescription()));
  }
  var opened = nativeDocument && dom.Document.fromNative(nativeDocument);
  if (!opened) throw new Error('无法后台打开 Sketch 文档。');
  return opened;
}
function readOwnedExportCopy(path) {
  // This path is a private copy created by openExportCopy, never a user document.
  // Reading it directly avoids NSDocumentController's open/recovery UI and the
  // canvas plugins it may notify even when display is false.
  var pointer = MOPointer.alloc().init(), nativeDocument = MSDocument.alloc().init();
  var loaded = nativeDocument.readFromURL_ofType_error(NSURL.fileURLWithPath(path),
    'com.bohemiancoding.sketch.drawing', pointer);
  if (!loaded) {
    try { nativeDocument.close(); } catch (closeError) {}
    var error = pointer.value();
    throw new Error(error && !error.isEqual(NSNull.null()) ?
      String(error.localizedDescription()) : '无法读取 Sketch 导出副本。');
  }
  return dom.Document.fromNative(nativeDocument);
}
// Sketch 97 does not expose Document.processPendingChanges in its JS API.
function flushDocumentChanges(d) {
  if (typeof d.processPendingChanges === 'function') { d.processPendingChanges(); return; }
  var nativeDocument = d.sketchObject;
  if (nativeDocument && nativeDocument.respondsToSelector(NSSelectorFromString('processPendingChanges'))) nativeDocument.processPendingChanges();
}
function openExportCopy(sourceDocument) {
  var manager = NSFileManager.defaultManager();
  var sourcePath = decodedDocumentPath(sourceDocument);
  var needsSnapshot = !sourcePath || !manager.fileExistsAtPath(sourcePath) || documentHasUnsavedChanges(sourceDocument);
  var identifier = String(NSUUID.UUID().UUIDString());
  var directory = String(NSTemporaryDirectory()) + '设计交付-' + identifier;
  var copyPath = directory + '/导出副本.sketch';
  mkdir(directory);
  try {
    if (needsSnapshot) {
      // SaveTo writes the live document to our private URL without changing its
      // file URL, dirty state or saved file. Never use Save or SaveAs here.
      flushDocumentChanges(sourceDocument);
      var nativeDocument = sourceDocument.sketchObject;
      if (nativeDocument.isKindOfClass(MSDocumentData)) nativeDocument = nativeDocument.delegate();
      var pointer = MOPointer.alloc().init();
      var written = nativeDocument.writeToURL_ofType_forSaveOperation_originalContentsURL_error(
        NSURL.fileURLWithPath(copyPath), 'com.bohemiancoding.sketch.drawing', NSSaveToOperation, null, pointer);
      if (!written) {
        var snapshotError = pointer.value();
        throw new Error('无法创建当前编辑状态的导出副本：' +
          (snapshotError && !snapshotError.isEqual(NSNull.null()) ? String(snapshotError.localizedDescription()) : 'Sketch 未能写入临时副本。'));
      }
    } else if (!manager.copyItemAtPath_toPath_error(sourcePath, copyPath, null)) {
      throw new Error('无法创建 Sketch 导出副本。');
    }
    // A hidden document prevents canvas-toolbar plugins from reacting to the temporary copy.
    var copyDocument = readOwnedExportCopy(copyPath);
    if (!copyDocument) throw new Error('无法打开 Sketch 导出副本。');
    return { document: copyDocument, directory: directory, path: copyPath };
  } catch (error) {
    removePath(directory);
    throw error;
  }
}
function closeExportCopy(copy) {
  if (!copy) return;
  var closeError = null;
  try { if (copy.document) copy.document.close(); } catch (error) { closeError = error; }
  removePath(copy.directory);
  if (fileExists(copy.directory)) {
    throw deliveryError('导出完成，临时文件未清理','交付文件已生成，可以正常使用。以下临时文件未能自动删除，确认不再需要后可手动清理：\n' + copy.directory);
  }
  if (closeError) throw deliveryError('导出完成，副本未能关闭','交付文件已生成，可以正常使用。请关闭导出时创建的临时副本窗口。\n详情：' + closeError);
}
function isolatedSliceLayer(layer, page, offset) {
  if (layer.type !== 'Slice' || !layer.parent || layer.parent.type === 'Page') return null;
  var parent = layer.parent, index = -1;
  (parent.layers || []).forEach(function (child, i) { if (child.id === layer.id) index = i; });
  if (index < 0) return null;
  // A Slice exported inside a detached component can retain a stale ancestor
  // clipping/render context. Keep its siblings and local crop, but isolate that
  // content on the temporary export document's page.
  var copy = dom.fromNative(parent.sketchObject.copy());
  try {
    copy.parent = page;
    copy.frame.x = offset || 0;
    copy.frame.y = 0;
    copy.hidden = false;
    var target = copy.layers[index];
    target.hidden = false;
    return { root: copy, layer: target };
  } catch (error) { copy.remove(); throw error; }
}
function isolatedWebLayer(layer, page, offset) {
  if (layer.type === 'Slice') return isolatedSliceLayer(layer, page, offset);
  var copy = dom.fromNative(layer.sketchObject.copy());
  try {
    copy.parent = page; copy.frame.x = offset || 0; copy.frame.y = 0; copy.hidden = false;
    return { root: copy, layer: copy };
  } catch (error) { copy.remove(); throw error; }
}
function image(layer, path, format) {
  var manager = NSFileManager.defaultManager();
  var slash = path.lastIndexOf('/');
  var outputDirectory = path.slice(0, slash);
  var tempDirectory = outputDirectory + '/.measure-export-' + String(new Date().getTime()) + '-' + String(Math.floor(Math.random() * 100000));
  var isolated = isolatedSliceLayer(layer, layer.getParentPage(), 0);
  if (isolated) layer = isolated.layer;
  var originalName = layer.name;
  mkdir(tempDirectory);
  try {
    layer.name = 'SketchMeasure资源';
    var requestedScale = String(format.size || '1x');
    var exportScale = requestedScale.slice(-1) === 'x' ? requestedScale.slice(0, -1) : requestedScale;
    sketch.export(layer, { output: tempDirectory, formats: String(format.fileFormat || 'png'),
      scales: exportScale, overwriting: true, trimmed: false, 'group-contents-only': true, 'save-for-web': true });
    var files = manager.contentsOfDirectoryAtPath_error(tempDirectory, null);
    if (!files || Number(files.count()) < 1) throw new Error('无法导出图层：' + originalName);
    var source = tempDirectory + '/' + String(files.objectAtIndex(0));
    if (!manager.moveItemAtPath_toPath_error(source, path, null)) throw new Error('无法保存导出图片：' + path);
  } finally {
    layer.name = originalName;
    if (isolated) isolated.root.remove();
    manager.removeItemAtPath_error(tempDirectory, null);
  }
}
function boardPreview(layer, output, id) {
  var path = 'preview/' + safeName(id) + '-4x.png';
  // Render once at the requested density; propagate errors instead of lowering it.
  image(layer, output + '/' + path, { fileFormat: 'png', size: '4x' });
  return { path: path, format: 'png', scale: 4 };
}
function isManualExportLayer(layer) {
  var formats = layer.exportFormats || [];
  return formats.length > 0 || layer.type === 'Slice';
}
function isSliceLayer(layer) {
  return layer && (layer.type === 'Slice' || layer.type === 'slice');
}
function exportAssets(layer, data, output, project, c, preview) {
  var formats = layer.exportFormats || [];
  data.manualExport = isManualExportLayer(layer);
  if (!formats.length && layer.type === 'Slice') formats = [{ fileFormat: 'png', size: '1x' }];
  if (!formats.length) return;
  var folder = safeFolder(data.objectID), name = safeName(layer.name);
  var list = [];
  mkdir(output + '/assets/' + folder);
  formats.forEach(function (format, i) {
    var ext = String(format.fileFormat).toLowerCase();
    if (['png', 'jpg', 'webp', 'svg', 'pdf', 'eps', 'tiff'].indexOf(ext) < 0) throw new Error('不支持的切图格式：' + ext);
    var size = String(format.size || '1x');
    var filename = safeName((format.prefix || '') + name + (format.suffix || '') + '-' + size + '-' + (i + 1)) + '.' + ext;
    image(layer, output + '/assets/' + folder + '/' + filename, { fileFormat: ext, size: size });
    list.push({ name: html(name), format: ext, path: folder + '/' + filename });
  });
  // Always use a browser-readable preview, even when the requested asset is PDF/EPS/TIFF.
  image(layer, output + '/assets/' + folder + '/预览.png', { fileFormat: 'png', size: '3x' });
  data.exportable = list;
  project.slices.push({ objectID: data.objectID, name: data.name, rect: data.rect, exportable: list,
    previewPath: folder + '/预览.png' });
}
var webSliceBatchSerial = 0;
function isLikelyIconLayer(layer) {
  if (layer.type !== 'Group' && layer.type !== 'SymbolInstance') return false;
  // Match the instance/group's own name only. Size, vector content and a master's
  // name must never turn an ordinary group into an automatically exported asset.
  return /icon|图标/i.test(String(layer.name || ''));
}
function indexManualExportSubtrees(layer, index, visiting, memo) {
  visiting = visiting || {};
  memo = memo || { values: {}, cycle: 0 };
  var key = String(layer.id || '');
  if (key && visiting[key]) { memo.cycle++; return false; }
  if (key && Object.prototype.hasOwnProperty.call(memo.values, key)) return memo.values[key];
  var cycle = memo.cycle;
  if (key) visiting[key] = true;
  var found = isManualExportLayer(layer);
  var children = layer.layers || [];
  for (var i = 0; i < children.length; i++) {
    if (isMark(children[i])) continue;
    if (indexManualExportSubtrees(children[i], index, visiting, memo)) found = true;
  }
  // Instances do not expose their master's children until detachment. Preserve
  // this information first, including nested/library component definitions.
  if (layer.type === 'SymbolInstance' && layer.master &&
      indexManualExportSubtrees(layer.master, index, visiting, memo)) found = true;
  if (key) index[key] = Boolean(index[key] || found);
  // Cache only within this traversal. A false result through a recursion cycle
  // is incomplete and must not suppress a later instance's authored slice.
  if (key && (found || cycle === memo.cycle)) memo.values[key] = found;
  if (key) delete visiting[key];
  return found;
}
function hasIconChild(layer) {
  return (layer.layers || []).some(function (child) {
    return !child.hidden && (isLikelyIconLayer(child) || hasIconChild(child));
  });
}
function hasTextChild(layer) {
  return (layer.layers || []).some(function (child) {
    return !child.hidden && (child.type === 'Text' || hasTextChild(child));
  });
}
function isAutoIconCandidate(layer) {
  return isLikelyIconLayer(layer) && !hasIconChild(layer) && !hasTextChild(layer);
}
function exportableWebSlice(layer, data, c) {
  return data.manualExport || Boolean(c.webSlices && data.autoIcon);
}
function arrayFromNSArray(value) {
  var result = [];
  if (!value) return result;
  for (var i = 0; i < Number(value.count()); i++) result.push(String(value.objectAtIndex(i)));
  return result;
}
function exportedScale(filename, token, extension) {
  var prefix = token, suffix = '.' + extension;
  if (filename.indexOf(prefix) !== 0 || filename.slice(-suffix.length) !== suffix) return null;
  var middle = filename.slice(prefix.length, -suffix.length), match = /^@([0-9.]+)x$/.exec(middle);
  if (!middle) return 1;
  return match ? Number(match[1]) : null;
}
function prepareWebSliceEntry(entry, output) {
  var folder = safeFolder(entry.data.objectID), name = safeName(entry.layer.name), base = output + '/web-slices/' + folder;
  mkdir(base);
  entry.webFolder = folder;
  entry.webName = name;
  entry.webBase = base;
  entry.data.webSlices = [1, 2, 3].map(function (scale) {
    var stem = safeName(name + (scale === 1 ? '' : '@' + scale + 'x'));
    return { scale: scale, format: 'png', path: folder + '/' + stem + '.png', paths: {
      png: folder + '/' + stem + '.png', jpg: folder + '/' + stem + '.jpg', svg: folder + '/' + stem + '.svg' } };
  });
}
function clearWebSliceEntries(entries, output) {
  entries.forEach(function (entry) {
    (entry.data.webSlices || []).forEach(function (file) {
      ['png', 'jpg', 'svg'].forEach(function (format) {
        var path = output + '/web-slices/' + file.paths[format];
        removePath(path);
        removePath(path + '.download.js');
      });
    });
  });
}
function scaledWebSVG(source, scale) {
  // Sketch writes scale suffixes for SVG but keeps a 1x viewport. Preserve its
  // vector coordinate system and set the requested intrinsic display size.
  return source.replace(/<svg\b[^>]*>/i, function (root) {
    if (!/\bviewBox\s*=/.test(root)) return root;
    return root.replace(/\b(width|height)="([0-9.]+)(?:px)?"/g, function (_, name, value) {
      return name + '="' + Math.max(1, Math.round(Number(value) * scale)) + 'px"';
    });
  });
}
function exportWebSliceChunk(entries, output, c) {
  var manager = NSFileManager.defaultManager(), serial = ++webSliceBatchSerial;
  var temp = output + '/.measure-web-export-' + String(new Date().getTime()) + '-' + serial;
  var scales = [1, 2, 3].map(function (scale) { return scale / (Number(c.scale) || 1); });
  var originals = [], isolated = [], exportLayers = [];
  mkdir(temp);
  try {
    entries.forEach(function (entry, index) {
      var copy = isolatedWebLayer(entry.layer, entry.layer.getParentPage(), index * 10000);
      if (copy) isolated.push(copy.root);
      var exportLayer = copy ? copy.layer : entry.layer;
      exportLayers.push(exportLayer);
      originals.push(exportLayer.name);
      entry.batchToken = '__SMW_' + serial + '_' + index;
      exportLayer.name = entry.batchToken;
    });
    var batches = [];
    try {
      // Integer densities have unambiguous filenames and can share one render
      // request. Fractional densities remain separate: Sketch can name 1.5x @1x.
      var combined = scales.every(function (scale) { return scale > 0 && Math.floor(scale) === scale; });
      var renderScales = combined ? [scales] : scales.map(function (scale) { return [scale]; });
      renderScales.forEach(function (values, index) {
        var directory = temp + '/' + (index + 1);
        mkdir(directory);
        sketch.export(exportLayers, {
          output: directory, formats: 'png,jpg,svg', scales: values.join(','), overwriting: true,
          trimmed: false, 'group-contents-only': true, 'save-for-web': true
        });
        var files = arrayFromNSArray(manager.contentsOfDirectoryAtPath_error(directory, null));
        values.forEach(function (actual) {
          batches.push({ directory: directory, actual: actual, matchScale: combined, files: files });
        });
      });
    } finally {
      exportLayers.forEach(function (layer, index) { layer.name = originals[index]; });
    }
    entries.forEach(function (entry) {
      batches.forEach(function (batch, index) {
        ['png', 'jpg', 'svg'].forEach(function (format) {
          var matches = batch.files.filter(function (filename) {
            var density = exportedScale(filename, entry.batchToken, format);
            return density != null && (!batch.matchScale || density === batch.actual);
          });
          if (matches.length !== 1) throw new Error('无法确定 ' + (index + 1) + 'x ' + format + ' 切图：' + entry.layer.name);
          var file = entry.data.webSlices[index], relative = file.paths[format];
          var destination = output + '/web-slices/' + relative;
          if (!manager.moveItemAtPath_toPath_error(batch.directory + '/' + matches[0], destination, null)) {
            throw new Error('无法保存网页切图：' + relative);
          }
          if (format === 'svg') writeText(destination, scaledWebSVG(readText(destination), batch.actual));
          writeDownloadPayload(destination, relative);
        });
      });
      entry.data.webSlices.forEach(function (file) {
        ['png', 'jpg', 'svg'].forEach(function (format) {
          if (!fileExists(output + '/web-slices/' + file.paths[format])) {
            throw new Error('批量导出缺少 ' + format.toUpperCase() + ' 切图：' + entry.layer.name);
          }
        });
        var png = NSBitmapImageRep.imageRepWithContentsOfFile(output + '/web-slices/' + file.paths.png);
        if (png) { file.pixelWidth = Number(png.pixelsWide()); file.pixelHeight = Number(png.pixelsHigh()); }
      });
    });
  } finally {
    exportLayers.forEach(function (layer, index) {
      if (originals[index] != null) layer.name = originals[index];
    });
    isolated.forEach(function (root) { root.remove(); });
    removePath(temp);
  }
}
function exportWebSlicesBatch(entries, output, c) {
  if (!entries.length) return;
  entries.forEach(function (entry) { prepareWebSliceEntry(entry, output); });
  function exportResilient(chunk) {
    try { exportWebSliceChunk(chunk, output, c); }
    catch (error) {
      clearWebSliceEntries(chunk, output);
      if (chunk.length <= 1) throw error;
      var middle = Math.ceil(chunk.length / 2);
      exportResilient(chunk.slice(0, middle));
      exportResilient(chunk.slice(middle));
    }
  }
  for (var i = 0; i < entries.length; i += 48) exportResilient(entries.slice(i, i + 48));
}
function stripMarks(layer) {
  (layer.layers || []).slice().forEach(function (child) {
    if (isMark(child)) child.remove(); else stripMarks(child);
  });
}
function containsMatchingLayer(layer, predicate) {
  var children = layer.layers || [];
  for (var i = 0; i < children.length; i++) {
    if (isLayerHidden(children[i])) continue;
    if (predicate(children[i]) || containsMatchingLayer(children[i], predicate)) return true;
  }
  return false;
}
function pair(original, clone, ids) {
  ids[clone.id] = original.id;
  var a = original.layers || [], b = clone.layers || [];
  a.forEach(function (l, i) { if (b[i]) pair(l, b[i], ids); });
}
function snapshotGeometry(layer, board, geometry) {
  (layer.layers || []).forEach(function (child) {
    geometry[child.id] = { rect: rect(child, board), localRect: localRect(child), autoLayout: stackLayoutData(child), layoutItem: layoutItemData(child) };
    snapshotGeometry(child, board, geometry);
  });
}
function symbolBlueprint(instance, seen, childrenCache) {
  var master = null;
  try { master = instance && instance.master; } catch (error) { master = null; }
  if (!master) return null;
  var canCache = !seen && childrenCache;
  seen = seen || {};
  var masterKey = String(master.id || master.symbolId || '');
  if (masterKey && seen[masterKey]) return null;
  var nextSeen = {};
  Object.keys(seen).forEach(function (key) { nextSeen[key] = seen[key]; });
  if (masterKey) nextSeen[masterKey] = true;
  function node(layer) {
    var children = [];
    if (layer.type === 'SymbolInstance') {
      var nested = symbolBlueprint(layer, nextSeen);
      if (nested) children = nested.children;
    } else {
      children = (layer.layers || []).map(node);
    }
    return { name: String(layer.name || ''), nativeType: String(layer.type || ''), frame: localRect(layer), item: layoutItemData(layer),
      manualExportFormats: inheritedExportFormats(layer),
      contentSize: layer.type === 'SymbolInstance' && layer.master ?
        { width: round(layer.master.frame.width), height: round(layer.master.frame.height) } :
        { width: round(layer.frame.width), height: round(layer.frame.height) },
      autoLayout: layer.type === 'SymbolInstance' && layer.master ? stackLayoutData(layer.master) : stackLayoutData(layer),
      children: children };
  }
  // Master children are immutable during detachment. Keep instance sizing and
  // export options separate, and clone cached data to avoid shared mutations.
  var children;
  if (canCache && masterKey && childrenCache[masterKey]) children = JSON.parse(childrenCache[masterKey]);
  else {
    children = (master.layers || []).map(node);
    if (canCache && masterKey) childrenCache[masterKey] = JSON.stringify(children);
  }
  return { name: String(instance.name || master.name || ''), nativeType: String(instance.type || 'SymbolInstance'), frame: { x: 0, y: 0,
      width: round(master.frame.width), height: round(master.frame.height) },
    manualExportFormats: inheritedExportFormats(instance),
    item: layoutItemData(instance), contentSize: { width: round(master.frame.width), height: round(master.frame.height) },
    autoLayout: stackLayoutData(master), children: children };
}
function inheritedExportFormats(layer) {
  var formats = layer.exportFormats || [];
  if (!formats.length && layer.type === 'SymbolInstance' && layer.master) formats = layer.master.exportFormats || [];
  return formats.map(function (f) { return { fileFormat: String(f.fileFormat), size: String(f.size || '1x'),
    prefix: String(f.prefix || ''), suffix: String(f.suffix || '') }; });
}
function restoreDetachedExports(layer, blueprint) {
  if (!blueprint) return;
  if (!(layer.exportFormats || []).length && (blueprint.manualExportFormats || []).length) {
    layer.exportFormats = blueprint.manualExportFormats;
  }
  (layer.layers || []).forEach(function (child, index) {
    restoreDetachedExports(child, (blueprint.children || [])[index]);
  });
}
function detachSymbols(layer, board, ids, geometry, originalGeometry, childrenCache) {
  childrenCache = childrenCache || {};
  (layer.layers || []).slice().forEach(function (child) {
    if (child.type === 'SymbolInstance') {
      var id = ids[child.id] || child.id;
      var captured = originalGeometry[id] || originalGeometry[child.id];
      var before = captured ? captured.rect : rect(child, board);
      var instanceBounds = { x: before.x, y: before.y, width: before.width, height: before.height };
      var blueprint = symbolBlueprint(child, null, childrenCache);
      var expanded = child.detach({ recursively: true });
      if (expanded) {
        restoreDetachedExports(expanded, blueprint);
        ids[expanded.id] = id;
        var mapping = { before: before, after: rect(expanded, board), instanceBounds: instanceBounds,
          expanded: expanded, blueprint: blueprint };
        geometry[expanded.id] = mapping;
        geometry[id] = mapping;
      }
    } else detachSymbols(child, board, ids, geometry, originalGeometry, childrenCache);
  });
}
function transformedRect(value, sourceRect, targetRect) {
  if (!value) return value;
  var scaleX = sourceRect.width ? targetRect.width / sourceRect.width : 1;
  var scaleY = sourceRect.height ? targetRect.height / sourceRect.height : 1;
  return { x: round(targetRect.x + (value.x - sourceRect.x) * scaleX),
    y: round(targetRect.y + (value.y - sourceRect.y) * scaleY),
    width: round(value.width * scaleX), height: round(value.height * scaleY) };
}
function transformLayerBranch(root, sourceRect, targetRect, childMap) {
  var queue = [root], current, descendants, i;
  root.rect = targetRect;
  root.logicalRect = targetRect;
  root.hitRect = transformedRect(root.hitRect, sourceRect, targetRect);
  while (queue.length) {
    current = queue.shift();
    var currentKey = String(current.objectID);
    descendants = childMap[currentKey] || [];
    for (i = 0; i < descendants.length; i++) {
      descendants[i].rect = transformedRect(descendants[i].rect, sourceRect, targetRect);
      descendants[i].logicalRect = transformedRect(descendants[i].logicalRect, sourceRect, targetRect);
      descendants[i].hitRect = transformedRect(descendants[i].hitRect, sourceRect, targetRect);
      queue.push(descendants[i]);
    }
  }
}
function pinnedLayoutAxis(start, size, parentSize, sourceParentSize, pins) {
  var delta = parentSize - sourceParentSize;
  if (pins === 'all') return { start: start, size: Math.max(0, size + delta) };
  if (pins === 'max') return { start: start + delta, size: size };
  if (pins === 'none' && sourceParentSize > 0) {
    return { start: start * parentSize / sourceParentSize, size: size * parentSize / sourceParentSize };
  }
  return { start: start, size: size };
}
function rebuildHitRectBranch(parentKey, clip, childMap) {
  var direct = childMap[parentKey] || [], activeMask = null, i, child, hitClip, nextClip, childKey;
  for (i = 0; i < direct.length; i++) {
    child = direct[i];
    if (child.breaksMaskChain) activeMask = null;
    hitClip = activeMask ? intersect(clip, activeMask) : clip;
    child.hitRect = intersect(child.rect, hitClip);
    nextClip = child.clipsContents ? intersect(clip, child.logicalRect) : clip;
    if (activeMask) nextClip = intersect(nextClip, activeMask);
    childKey = String(child.objectID);
    rebuildHitRectBranch(childKey, nextClip, childMap);
    if (child.masksSiblings) activeMask = child.logicalRect;
  }
}
function repairDetachedLayouts(layers, boardRect, c) {
  var byId = {}, childMap = {}, i, j, layer, parentKey;
  for (i = 0; i < layers.length; i++) {
    layer = layers[i];
    var layerKey = String(layer.objectID);
    byId[layerKey] = layer;
    parentKey = String(layer.parentObjectID || '');
    if (!childMap[parentKey]) childMap[parentKey] = [];
    childMap[parentKey].push(layer);
  }
  var ordered = layers.slice();
  ordered.sort(function (a, b) { return number(a.depth) - number(b.depth); });
  // Detaching a resized Symbol can leave an ordinary group's stored frame at its
  // master position while its children already have their resolved positions.
  // Such groups have no independent coordinate surface: normalize their layout
  // bounds before reflow, without translating the already-positioned children.
  // Frames, symbols, clipped/painted containers keep their independent bounds.
  for (i = ordered.length - 1; i >= 0; i--) {
    var group = ordered[i], groupParentKey = String(group.parentObjectID || '');
    var groupParent = byId[groupParentKey];
    if (!group.detachedLayoutScope || !group.hasChildren || group.isFrame || group.autoLayout ||
        group.clipsContents || group.detachedSymbolRoot || !groupParent || !groupParent.autoLayout ||
        (group.fills || []).length || (group.borders || []).length || (group.shadows || []).length) continue;
    var groupKey = String(group.objectID), contents = null;
    var groupChildren = childMap[groupKey] || [];
    for (j = 0; j < groupChildren.length; j++) {
      var member = groupChildren[j];
      if (!member.hidden && member.type !== 'slice') contents = unionRect(contents, member.rect);
    }
    var stored = group.rect;
    if (contents && (contents.x < stored.x - 0.02 || contents.y < stored.y - 0.02 ||
        contents.x + contents.width > stored.x + stored.width + 0.02 ||
        contents.y + contents.height > stored.y + stored.height + 0.02)) {
      group.rect = contents;
      group.logicalRect = contents;
    }
  }
  for (i = 0; i < ordered.length; i++) {
    var parent = ordered[i], layout = parent.autoLayout, layoutKey = String(parent.objectID);
    var direct = childMap[layoutKey] || [];
    if (!layout || !parent.detachedLayoutScope || !direct.length) continue;
    var padding = layout.padding || {}, sourceSize = parent.detachedBlueprintSize ||
      { width: parent.rect.width, height: parent.rect.height };
    for (j = 0; j < direct.length; j++) {
      var absoluteChild = direct[j];
      if (!absoluteChild.layoutItem || !absoluteChild.layoutItem.ignoresStackLayout || !absoluteChild.detachedBlueprintRect) continue;
      var source = absoluteChild.detachedBlueprintRect;
      var pinnedX = pinnedLayoutAxis(source.x, source.width, parent.rect.width, sourceSize.width,
        absoluteChild.layoutItem.horizontalPins);
      var pinnedY = pinnedLayoutAxis(source.y, source.height, parent.rect.height, sourceSize.height,
        absoluteChild.layoutItem.verticalPins);
      var oldAbsolute = absoluteChild.rect;
      var nextAbsolute = { x: round(parent.rect.x + pinnedX.start), y: round(parent.rect.y + pinnedY.start),
        width: round(pinnedX.size), height: round(pinnedY.size) };
      transformLayerBranch(absoluteChild, oldAbsolute, nextAbsolute, childMap);
    }
    var flow = [];
    for (j = direct.length - 1; j >= 0; j--) {
      if ((!direct[j].hidden || direct[j].layoutItem && direct[j].layoutItem.preservesSpaceWhenHidden) && (!direct[j].layoutItem || !direct[j].layoutItem.ignoresStackLayout)) flow.push(direct[j]);
    }
    if (!flow.length || layout.wraps) continue;
    var row = layout.direction === 'row';
    var inner = (row ? parent.rect.width : parent.rect.height) -
      (row ? number(padding.left) + number(padding.right) : number(padding.top) + number(padding.bottom));
    var total = 0;
    for (j = 0; j < flow.length; j++) total += row ? flow[j].rect.width : flow[j].rect.height;
    var gap = number(layout.gap), spacing = gap;
    var free = inner - total - gap * Math.max(0, flow.length - 1), offset = 0;
    if (layout.justifyContent === 'center') offset = free / 2;
    else if (layout.justifyContent === 'flex-end') offset = free;
    else if (layout.justifyContent === 'space-between' && flow.length > 1) spacing = gap + free / (flow.length - 1);
    else if (layout.justifyContent === 'space-around') { spacing = gap + free / flow.length; offset = free / flow.length / 2; }
    else if (layout.justifyContent === 'space-evenly') { spacing = gap + free / (flow.length + 1); offset = free / (flow.length + 1); }
    var cursor = (row ? number(padding.left) : number(padding.top)) + offset;
    for (j = 0; j < flow.length; j++) {
      var flowChild = flow[j], oldFlow = flowChild.rect;
      var mainSize = row ? oldFlow.width : oldFlow.height, crossSize = row ? oldFlow.height : oldFlow.width;
      var crossAvailable = (row ? parent.rect.height : parent.rect.width) -
        (row ? number(padding.top) + number(padding.bottom) : number(padding.left) + number(padding.right));
      var cross = row ? number(padding.top) : number(padding.left);
      if (layout.alignItems === 'center') cross += (crossAvailable - crossSize) / 2;
      else if (layout.alignItems === 'flex-end') cross += crossAvailable - crossSize;
      var nextFlow = row ? { x: round(parent.rect.x + cursor), y: round(parent.rect.y + cross),
          width: oldFlow.width, height: oldFlow.height } :
        { x: round(parent.rect.x + cross), y: round(parent.rect.y + cursor),
          width: oldFlow.width, height: oldFlow.height };
      transformLayerBranch(flowChild, oldFlow, nextFlow, childMap);
      cursor += mainSize + spacing;
    }
  }
  rebuildHitRectBranch('', boardRect, childMap);
  for (i = 0; i < layers.length; i++) {
    layer = layers[i];
    var lookupKey = String(layer.parentObjectID || '');
    var parentLayer = layer.parentObjectID ? byId[lookupKey] : null;
    var containingRect = parentLayer ? parentLayer.logicalRect : boardRect;
    layer.parentRect = containingRect;
    layer.localRect = { x: round(layer.rect.x - containingRect.x), y: round(layer.rect.y - containingRect.y),
      width: layer.rect.width, height: layer.rect.height };
    layer.css = css(layer, c.scale).map(html);
    delete layer.detachedBlueprintRect;
    delete layer.detachedBlueprintSize;
    delete layer.detachedLayoutScope;
  }
}
function finalizeDetachedGeometry(geometry, board) {
  var visited = [];
  Object.keys(geometry).forEach(function (key) {
    var mapping = geometry[key];
    if (!mapping || visited.indexOf(mapping) >= 0) return;
    visited.push(mapping);
    if (mapping.expanded) mapping.after = rect(mapping.expanded, board);
  });
}
function rectMapper(mapping, inherited) {
  if (!mapping) return inherited;
  var before = inherited ? inherited(mapping.before) : mapping.before;
  var after = mapping.after;
  var scaleX = after.width ? before.width / after.width : 1;
  var scaleY = after.height ? before.height / after.height : 1;
  return function (value) {
    return { x: round(before.x + (value.x - after.x) * scaleX),
      y: round(before.y + (value.y - after.y) * scaleY),
      width: round(value.width * scaleX), height: round(value.height * scaleY) };
  };
}
function viewerLayerOrder(layers) {
  var children = {}, ordered = [], visited = {};
  layers.forEach(function (layer) {
    var parent = String(layer.parentObjectID || '');
    if (!children[parent]) children[parent] = [];
    children[parent].push(layer);
  });
  function append(parent) {
    var key = parent ? String(parent) : '';
    var siblings = children[key] || [];
    for (var index = siblings.length - 1; index >= 0; index--) {
      var layer = siblings[index];
      var id = String(layer.objectID);
      if (visited[id]) continue;
      visited[id] = true;
      ordered.push(layer);
      append(id);
    }
  }
  append('');
  // Preserve otherwise valid layers even if a malformed parent reference made them unreachable.
  layers.forEach(function (layer) {
    var fallbackID = String(layer.objectID);
    if (!visited[fallbackID]) ordered.push(layer);
  });
  return ordered;
}
function selectionRects(layers) {
  var children = {};
  layers.forEach(function (layer) {
    var parent = String(layer.parentObjectID || '');
    if (!children[parent]) children[parent] = [];
    children[parent].push(layer);
    layer.selectionRect = layer.hitRect;
  });
  for (var i = layers.length - 1; i >= 0; i--) {
    var layer = layers[i];
    if (!layer.hasChildren) continue;
    function visibleColor(value) { return value && number(value.a) > 0.0001; }
    function visibleFill(fill) {
      if (!fill) return false;
      if (fill.gradient && fill.gradient.colorStops) {
        return any(fill.gradient.colorStops, function (stop) { return visibleColor(stop.color); });
      }
      return visibleColor(fill.color);
    }
    var ownsBounds = layer.autoLayout || layer.isFrame || layer.clipsContents || layer.detachedSymbolRoot ||
      layer.rotation || layer.flippedHorizontally || layer.flippedVertically ||
      any(layer.fills, visibleFill) || any(layer.borders, function (border) {
        return number(border.thickness) > 0 && visibleFill(border);
      }) || any(layer.shadows, function (shadow) { return visibleColor(shadow.color); });
    layer.selectsOwnBounds = Boolean(ownsBounds);
    if (ownsBounds) continue;
    var childBounds = null;
    var childKey = String(layer.objectID);
    var directChildren = children[childKey] || [];
    for (var childIndex = 0; childIndex < directChildren.length; childIndex++) {
      if (directChildren[childIndex].hidden) continue;
      childBounds = unionRect(childBounds, directChildren[childIndex].selectionRect);
    }
    // Plain groups have no visual surface of their own. Hidden children may still enlarge
    // Sketch's stored group frame, so derive their selectable bounds only from exported,
    // visible children. Auto-layout and painted containers deliberately keep their frame.
    if (childBounds) layer.selectionRect = childBounds;
  }
}
function finalizeLayoutParameters(layers, boardRect, c, boardLayout) {
  var byId = {};
  layers.forEach(function (l) {
    var key = String(l.objectID);
    byId[key] = l;
    if (l.hasChildren && l.type === 'group' && !l.selectsOwnBounds && l.selectionRect) {
      if (!l.sourceRect) l.sourceRect = l.rect;
      l.rect = l.selectionRect;
      l.logicalRect = l.selectionRect;
    }
  });
  layers.forEach(function (l) {
    var parentKey = String(l.parentObjectID || ''), parent = byId[parentKey];
    var r = l.logicalRect || l.rect, outer = parent ? parent.logicalRect || parent.rect : boardRect;
    l.parentRect = outer;
    l.parentAutoLayout = parent ? parent.autoLayout : boardLayout || null;
    l.localRect = { x: round(r.x - outer.x), y: round(r.y - outer.y), width: r.width, height: r.height };
    l.css = css(l, c.scale).map(html);
  });
  return byId;
}
function projectCanvasGeometry(layers, boardRect) {
  var byId = {}, children = {}, matrices = {};
  layers.forEach(function(l) {
    var layerKey = String(l.objectID);
    byId[layerKey] = l;
    var key = String(l.parentObjectID || '');
    (children[key] || (children[key] = [])).push(l);
  });
  function matrix(l) {
    var key = String(l.objectID);
    if (matrices[key]) return matrices[key];
    var r = l.localRect || l.rect, angle = number(l.rotation) * Math.PI / 180;
    var sx = l.flippedHorizontally ? -1 : 1, sy = l.flippedVertically ? -1 : 1;
    var a = Math.cos(angle) * sx, b = Math.sin(angle) * sy;
    var c = -Math.sin(angle) * sx, d = Math.cos(angle) * sy;
    var tx = r.x + r.width / 2 - a * r.width / 2 - c * r.height / 2;
    var ty = r.y + r.height / 2 - b * r.width / 2 - d * r.height / 2;
    var parentKey = String(l.parentObjectID || '');
    var parent = byId[parentKey];
    var p = parent ? matrix(parent) : [1, 0, 0, 1, 0, 0];
    var result = [];
    result.push(p[0]*a+p[2]*b, p[1]*a+p[3]*b, p[0]*c+p[2]*d);
    result.push(p[1]*c+p[3]*d, p[0]*tx+p[2]*ty+p[4], p[1]*tx+p[3]*ty+p[5]);
    matrices[key] = result;
    return result;
  }
  layers.forEach(function(l) {
    var m = matrix(l), r = l.logicalRect || l.rect;
    l.canvasCorners = [[0,0],[r.width,0],[r.width,r.height],[0,r.height]].map(function(p) {
      return { x: round(m[0]*p[0]+m[2]*p[1]+m[4]), y: round(m[1]*p[0]+m[3]*p[1]+m[5]) };
    });
    var xs = l.canvasCorners.map(function(p){return p.x;}), ys = l.canvasCorners.map(function(p){return p.y;});
    var x = Math.min.apply(Math,xs), y = Math.min.apply(Math,ys);
    l.visualRect = {x:x,y:y,width:round(Math.max.apply(Math,xs)-x),height:round(Math.max.apply(Math,ys)-y)};
  });
  function clipBranch(key, clip) {
    var mask = null;
    (children[key] || []).forEach(function(l) {
      if (l.breaksMaskChain) mask = null;
      var visibleClip = mask ? intersect(clip,mask) : clip;
      l.hitRect = intersect(l.visualRect,visibleClip);
      clipBranch(String(l.objectID),l.clipsContents ? intersect(visibleClip,l.visualRect) : visibleClip);
      if (l.masksSiblings) mask = l.visualRect;
      delete l.masksSiblings; delete l.breaksMaskChain;
    });
  }
  clipBranch('',boardRect);
  selectionRects(layers);
}
function extractBoard(original, output, project, c) {
  var page = original.getParentPage();
  var canvasPosition = { x: number(original.frame.x), y: number(original.frame.y) };
  var canvasParent = original.parent;
  while (canvasParent && canvasParent.id !== page.id) {
    canvasPosition.x += number(canvasParent.frame.x); canvasPosition.y += number(canvasParent.frame.y);
    canvasParent = canvasParent.parent;
  }
  var previewBoard = null;
  var board = null;
  var ids = {};
  try {
    var preview = boardPreview(original, output, original.id);

    var symbolGeometry = {}, originalGeometry = {}, originalManualSubtrees = {};
    indexManualExportSubtrees(original, originalManualSubtrees);
    snapshotGeometry(original, original, originalGeometry);
    var hasSymbols = containsMatchingLayer(original, function (layer) { return layer.type === 'SymbolInstance'; });
    board = original;
    stripMarks(board);
    if (hasSymbols) {
      detachSymbols(board, board, ids, symbolGeometry, originalGeometry);
      finalizeDetachedGeometry(symbolGeometry, board);
      stripMarks(board);
    }
    var manualExportSubtrees = {};
    indexManualExportSubtrees(board, manualExportSubtrees);
    var result = { objectID: original.id, name: html(original.name), pageName: html(page.name),
      pageObjectID: page.id, canvasPosition: canvasPosition, width: original.frame.width, height: original.frame.height,
      imagePath: preview.path, previewFormat: preview.format, previewScale: preview.scale,
      svgSource: preview.svgSource, svgWarnings: preview.warnings,
      autoLayout: stackLayoutData(board), layers: [] }, webEntries = [], manualSliceParents = {};
    function walk(container, clip, opacity, depth, parentObjectID, parentRect, inheritedMapper, insideAutoIcon,
      layoutBlueprint, detachedLayoutScope, inheritedHidden) {
      var activeMask = null, containerStackLayout = stackLayoutData(container);
      (container.layers || []).forEach(function (l, layerIndex) {
        if (l.breaksMaskChain) activeMask = null;
        if (isMark(l)) return;
        var effective = opacity * (l.style ? l.style.opacity : 1);
        if (effective <= 0.0001) return;
        var data = layerData(l, board, c, effective);
        var mappedObjectID = ids[l.id] || (parentObjectID ? parentObjectID + '/' + l.id : l.id);
        var symbolMapping = symbolGeometry[l.id] || symbolGeometry[mappedObjectID];
        var blueprint = symbolMapping && symbolMapping.blueprint ? symbolMapping.blueprint :
          (layoutBlueprint && layoutBlueprint.children ? layoutBlueprint.children[layerIndex] : null);
        data.sourceNativeType = blueprint && blueprint.nativeType ? blueprint.nativeType : data.nativeType;
        var capturedGeometry = !inheritedMapper && !symbolMapping ? originalGeometry[l.id] : null;
        if (capturedGeometry) {
          data.rect = capturedGeometry.rect;
          data.localRect = capturedGeometry.localRect;
          data.autoLayout = capturedGeometry.autoLayout;
          data.layoutItem = capturedGeometry.layoutItem;
        }
        if (!data.autoLayout && blueprint && blueprint.autoLayout) data.autoLayout = blueprint.autoLayout;
        var mapper = rectMapper(symbolMapping, inheritedMapper);
        if (mapper) {
          data.rect = mapper(data.rect);
          if (symbolMapping && symbolMapping.instanceBounds) data.rect = symbolMapping.instanceBounds;
          data.localRect = { x: round(data.rect.x - parentRect.x), y: round(data.rect.y - parentRect.y),
            width: data.rect.width, height: data.rect.height };
        }
        data.objectID = mappedObjectID;
        data.svgNodeID = 'lab-' + String(l.id);
        data.labNativeID = String(l.id);
        data.labExportFormats = inheritedExportFormats(l);
        data.depth = depth;
        data.parentObjectID = parentObjectID || null;
        data.parentRect = parentRect;
        data.parentAutoLayout = containerStackLayout;
        data.hidden = Boolean(inheritedHidden || isLayerHidden(l));
        if (blueprint && blueprint.item) data.layoutItem.ignoresStackLayout = Boolean(blueprint.item.ignoresStackLayout);
        data.detachedBlueprintRect = blueprint && blueprint.frame ? blueprint.frame : null;
        data.detachedBlueprintSize = blueprint && blueprint.contentSize ? blueprint.contentSize : null;
        data.detachedLayoutScope = Boolean(detachedLayoutScope || symbolMapping);
        data.hasChildren = (l.layers || []).some(function (child) { return !isMark(child); });
        data.manualExport = isManualExportLayer(l) && !isSliceLayer(l);
        if (isSliceLayer(l) && parentObjectID) {
          var sliceParentKey = String(parentObjectID);
          manualSliceParents[sliceParentKey] = l.parent;
        }
        var manualSubtreeKey = String(l.id);
        var originalManualKey = String(ids[l.id] || l.id);
        data.autoIcon = Boolean(c.webSlices) && !data.hidden && !insideAutoIcon && !originalManualSubtrees[originalManualKey] &&
          !manualExportSubtrees[manualSubtreeKey] && isAutoIconCandidate(l);
        data.locked = Boolean(l.locked);
        data.isFrame = Boolean(l.isFrame || l.isGraphicFrame);
        data.clipsContents = Boolean(l.clipsContents);
        data.masksSiblings = Boolean(l.masksSiblings);
        data.breaksMaskChain = Boolean(l.breaksMaskChain);
        data.detachedSymbolRoot = Boolean(symbolMapping);
        data.logicalRect = data.rect;
        var hitClip = activeMask ? intersect(clip, activeMask) : clip;
        data.hitRect = intersect(data.rect, hitClip);
        var insertionIndex = result.layers.length, included = false;
        function includeLayer() {
          if (!isSliceLayer(l) && exportableWebSlice(l, data, c)) webEntries.push({ layer: l, data: data });
          // The parent group is exported below when a child Slice is found.
          // Do not create a second asset from the marker layer itself.
          if (!isSliceLayer(l)) exportAssets(l, data, output, project, c);
          result.layers.splice(insertionIndex, 0, data);
          included = true;
        }
        // A layer outside the unrotated board can rotate back into view. Keep its
        // metadata until the final visual clipping pass has resolved transforms.
        if (c.includeAllLayers || ((data.hitRect.width > 0 || data.hitRect.height > 0) && data.hitRect.width >= 0 && data.hitRect.height >= 0) || hasCanvasTransform(l, board)) {
          includeLayer();
        }
        var nextClip = l.clipsContents ? intersect(clip, data.logicalRect) : clip;
        walk(l, activeMask ? intersect(nextClip, activeMask) : nextClip, effective, depth + 1,
          data.objectID, data.logicalRect, mapper, insideAutoIcon || data.manualExport || data.autoIcon, blueprint,
          data.detachedLayoutScope, data.hidden);
        // A group's stored frame can miss the board while its overflowing children
        // remain visible. Keep their real parent; never orphan or reparent them.
        if (!included && result.layers.length > insertionIndex) includeLayer();
        if (l.masksSiblings) activeMask = data.logicalRect;
      });
    }
    var boardRect = { x: 0, y: 0, width: result.width, height: result.height };
    walk(board, boardRect, 1, 0, null, boardRect, null, false, null, false, false);
    Object.keys(manualSliceParents).forEach(function (parentID) {
      var parentData = null;
      for (var p = 0; p < result.layers.length; p++) {
        if (String(result.layers[p].objectID) === String(parentID)) { parentData = result.layers[p]; break; }
      }
      var parentLayer = manualSliceParents[parentID];
      if (!parentData || !parentLayer || !(parentLayer.type === 'Group' || parentLayer.type === 'SymbolInstance')) return;
      parentData.manualExport = true;
      var already = webEntries.some(function (entry) { return String(entry.data.objectID) === String(parentData.objectID); });
      if (!already) webEntries.push({ layer: parentLayer, data: parentData });
    });
    repairDetachedLayouts(result.layers, boardRect, c);
    exportWebSlicesBatch(webEntries, output, c);
    selectionRects(result.layers);
    var finalized = finalizeLayoutParameters(result.layers, boardRect, c, result.autoLayout);
    projectCanvasGeometry(result.layers, boardRect);
    project.slices.forEach(function (slice) {
      var key = String(slice.objectID), layer = finalized[key];
      if (layer) slice.rect = layer.logicalRect || layer.rect;
    });
    result.layers = viewerLayerOrder(result.layers);
    return result;
  } finally {
    if (previewBoard) previewBoard.remove();
  }
}
function inspectExportResource(path, format, payloadKey) {
  var bytes = NSData.dataWithContentsOfFile(path);
  if (!bytes || !Number(bytes.length())) throw new Error('文件缺失或为空：' + path);
  var result = { bytes: Number(bytes.length()) };
  if (format === 'png' || format === 'jpg') {
    var signature = String(bytes.subdataWithRange(NSMakeRange(0, Math.min(12, Number(bytes.length())))).base64EncodedStringWithOptions(0));
    if (format === 'png' ? signature.indexOf('iVBORw0KGgo') !== 0 : signature.indexOf('/9j/') !== 0) throw new Error('图像格式标识无效：' + path);
    var bitmap = NSBitmapImageRep.imageRepWithContentsOfFile(path);
    if (!bitmap) throw new Error('图像无法解码：' + path);
    result.width = Number(bitmap.pixelsWide()); result.height = Number(bitmap.pixelsHigh());
  } else if (format === 'svg') {
    // NSXMLDocument's failing initializer can crash Sketch's Objective-C bridge.
    // NSXMLParser reports malformed XML via a boolean instead of a nil initializer.
    var source = readText(path), parser = NSXMLParser.alloc().initWithData(bytes);
    parser.setShouldResolveExternalEntities(false);
    var root = /<svg\b[^>]*>/i.exec(source);
    if (!root || !parser.parse()) throw new Error('SVG 结构无效：' + path);
    var width = /\bwidth="([0-9.]+)(?:px)?"/.exec(root[0]), height = /\bheight="([0-9.]+)(?:px)?"/.exec(root[0]);
    result.width = width ? Number(width[1]) : 0;
    result.height = height ? Number(height[1]) : 0;
    result.hasDrawing = /<(path|rect|circle|ellipse|polygon|polyline|line|text|image|use)\b/i.test(source.replace(/<defs\b[\s\S]*?<\/defs>/gi, ''));
  }
  if (payloadKey != null) {
    var expected = 'window.__SM_SLICE_PAYLOADS__=window.__SM_SLICE_PAYLOADS__||{};window.__SM_SLICE_PAYLOADS__[' +
      scriptJSON(payloadKey) + ']=' + scriptJSON(String(bytes.base64EncodedStringWithOptions(0))) + ';';
    if (!fileExists(path + '.download.js') || readText(path + '.download.js') !== expected) {
      throw new Error('离线下载内容缺失或与切图不一致：' + path);
    }
  }
  return result;
}
function validateExport(project, output, inspect) {
  inspect = inspect || inspectExportResource;
  var report = { version: 1, boards: 0, layers: 0, resources: 0, sliceScales: 0, warnings: [] }, resourceCache = {};
  function fail(label, message) { throw new Error('交付校验未通过：' + label + '：' + message); }
  function finite(value) { return typeof value === 'number' && isFinite(value); }
  function numericFields(value, label) {
    if (typeof value === 'number' && !finite(value)) fail(label, '参数不是有限数值');
    if (value && typeof value === 'object') Object.keys(value).forEach(function (key) { numericFields(value[key], label + '/' + key); });
  }
  function rect(value, label) {
    if (!value) fail(label, '缺少坐标');
    ['x', 'y', 'width', 'height'].forEach(function (key) {
      if (!finite(value[key]) || ((key === 'width' || key === 'height') && value[key] < 0)) fail(label, '无效的 ' + key);
    });
  }
  function layout(value, label) {
    if (!value) return;
    if (['row', 'column'].indexOf(value.direction) < 0) fail(label, '布局方向无效');
    if (['flex-start', 'center', 'flex-end', 'space-between', 'space-around', 'space-evenly'].indexOf(value.justifyContent) < 0) fail(label, '主轴对齐无效');
    if (['flex-start', 'center', 'flex-end', 'stretch', 'normal'].indexOf(value.alignItems) < 0) fail(label, '交叉轴对齐无效');
    ['gap', 'crossAxisGap'].forEach(function (key) { if (!finite(value[key])) fail(label, '布局间距无效：' + key); });
    ['top', 'right', 'bottom', 'left'].forEach(function (side) {
      if (!value.padding || !finite(value.padding[side])) fail(label, '内边距无效：' + side);
    });
    if (value.gap < 0 || value.crossAxisGap < 0) report.warnings.push(label + '：负间距需要重叠布局，不能直接使用 CSS gap。');
  }
  function resource(relative, format, key, label) {
    if (!relative || relative.charAt(0) === '/' || /(^|\/)\.\.(\/|$)/.test(relative)) fail(label, '资源路径无效');
    var cacheKey = JSON.stringify([relative,format,key]), info = resourceCache[cacheKey];
    if (!info) {
      try { info = inspect(output + '/' + relative, format, key); } catch (error) { fail(label, String(error.message || error)); }
      resourceCache[cacheKey] = info;
    }
    if (!info || !(info.bytes > 0)) fail(label, '资源缺失或为空：' + relative);
    report.resources++;
    return info;
  }
  numericFields(project, '文档');
  if (!finite(project.scale) || project.scale <= 0) fail('文档', '设计倍率必须为正数');
  if (!project.artboards || !project.artboards.length) fail('文档', '缺少画板');
  project.artboards.forEach(function (board) {
    var label = board.name || board.objectID, byId = {};
    report.boards++;
    if (!finite(board.width) || !finite(board.height) || board.width <= 0 || board.height <= 0) fail(label, '画板尺寸无效');
    layout(board.autoLayout, label);
    var preview = resource(board.imagePath, board.previewFormat || 'png', null, label);
    if (preview.width && (Math.abs(preview.width - board.width * board.previewScale) > 2 || Math.abs(preview.height - board.height * board.previewScale) > 2)) fail(label, '预览尺寸与画板倍率不一致');
    board.layers.forEach(function (layer) {
      var key = String(layer.objectID);
      if (!layer.objectID || byId[key]) fail(label, '图层标识重复或缺失');
      byId[key] = layer;
    });
    board.layers.forEach(function (layer) {
      var name = label + ' / ' + layer.name, r = layer.logicalRect || layer.rect;
      report.layers++;
      ['rect', 'logicalRect', 'localRect', 'selectionRect'].forEach(function (key) { rect(layer[key], name + ' / ' + key); });
      var parentKey = String(layer.parentObjectID || ''), parent = byId[parentKey];
      var outer = parent ? parent.logicalRect || parent.rect : { x: 0, y: 0 };
      if (layer.parentObjectID && !parent) fail(name, '父编组缺失');
      if (Math.abs(r.x - outer.x - layer.localRect.x) > 0.025 || Math.abs(r.y - outer.y - layer.localRect.y) > 0.025) fail(name, '父级坐标与局部坐标不一致');
      layout(layer.autoLayout, name);
      ['opacity', 'fontSize', 'lineHeight', 'letterSpacing', 'rotation'].forEach(function (key) {
        if (layer[key] != null && !finite(layer[key])) fail(name, '无效参数：' + key);
      });
      var invalidCode = new RegExp('(^|[\\s:(,])(?:NaN|Infinity|undefined)(?=[\\s;,)\\n]|px|$)');
      if (invalidCode.test((layer.css || []).join('\n'))) fail(name, '代码包含无效参数：' + (layer.css || []).join(' '));
      if (project.sliceMode === 'browser-svg' && layer.labBuiltIn && !layer.hidden && !layer.labSliceError && !layer.labAssetSource) fail(name, '已有切图缺少下载内容');
      if (layer.labAssetPath) {
        if (!layer.labBuiltIn || !layer.labAssetSource) fail(name, '切图资源归属或内容无效');
        var nativeAsset = resource(layer.labAssetPath,'svg',null,name);
        if (nativeAsset.hasDrawing === false) fail(name, '切图资源没有绘制内容');
      }
      if (project.sliceMode !== 'browser-svg' && (layer.manualExport || layer.autoIcon) && !(layer.webSlices && layer.webSlices.length === 3)) fail(name, '缺少 1、2、3 倍网页切图');
      (layer.exportable || []).forEach(function (file) { resource('assets/' + file.path, file.format, null, name); });
      var scales = {};
      (layer.webSlices || []).forEach(function (file) {
        if ([1, 2, 3].indexOf(file.scale) < 0 || scales[file.scale]) fail(name, '切图倍率无效或重复');
        scales[file.scale] = true; report.sliceScales++;
        var png = null;
        ['png', 'jpg', 'svg'].forEach(function (format) {
          if (!file.paths || !file.paths[format]) fail(name, '缺少 ' + format + ' 切图路径');
          var info = resource('web-slices/' + file.paths[format], format, file.paths[format], name);
          if (!(info.width > 0 && info.height > 0)) fail(name, format + ' 切图尺寸无效');
          if (format === 'png') {
            png = info;
            if (file.pixelWidth !== info.width || file.pixelHeight !== info.height) fail(name, '下载尺寸与 PNG 实际尺寸不一致');
            var base = layer.webSlices.filter(function (candidate) { return candidate.scale === 1; })[0];
            if (base && (Math.abs(info.width - base.pixelWidth * file.scale) > file.scale || Math.abs(info.height - base.pixelHeight * file.scale) > file.scale)) fail(name, '切图像素尺寸与倍率不一致');
          } else if (Math.abs(info.width - png.width) > (format === 'svg' ? 1 : 0) || Math.abs(info.height - png.height) > (format === 'svg' ? 1 : 0)) fail(name, format + ' 与 PNG 尺寸不一致');
          if (format === 'svg' && info.hasDrawing === false && !layer.hidden) report.warnings.push(name + '：SVG 没有绘制内容，请确认是否为有意留空的切图。');
        });
      });
    });
  });
  (project.slices || []).forEach(function (slice) { resource('assets/' + slice.previewPath, 'png', null, slice.name); });
  report.status = report.warnings.length ? '有待核对项' : '已通过结构、参数一致性与资源完整性校验';
  return report;
}
function beginExportActivity() {
  // NSActivityUserInitiatedAllowingIdleSystemSleep prevents App Nap while the
  // synchronous export runs, without permanently changing energy settings.
  return NSProcessInfo.processInfo().beginActivityWithOptions_reason(0x00EFFFFF, '设计交付：导出画板与切图');
}
function endExportActivity(activity) {
  if (activity) NSProcessInfo.processInfo().endActivity(activity);
}
function performExport(context, options) {
  devInitializeAvatar(context);
  var d = options.document || document(), c = config();
  var boards = options.scope !== 'selected-board' && options.boardIDs && options.boardIDs.length ? options.boardIDs.map(function (id) {
    return d.getLayerWithID(id);
  }).filter(function (layer) { return layer && isBoard(layer); }) : getBoards(d, options.scope || 'selection');
  if (options.scope === 'selected-board' && !boards.length) {
    throw deliveryError('请先选择要导出的画板','在 Sketch 中选中一个或多个画板或 Frame，再点击“导出选中画板到 HTML”。按住 Shift 可以多选。');
  }
  if (!boards.length) throw deliveryError('没有找到可导出的画板','当前导出范围内没有画板或 Frame。请切换到包含画板的页面，或先创建画板后再导出。');
  var boardReferences = boards.map(function (board) { return { id: board.id, name: board.name }; });
  var output = options.output;
  if (!output) {
    var panel = NSOpenPanel.openPanel();
    panel.setCanChooseFiles(false); panel.setCanChooseDirectories(true); panel.setCanCreateDirectories(true);
    panel.setAllowsMultipleSelection(false); panel.setTitle('选择交付规范保存位置'); panel.setPrompt('导出到此处');
    if (Number(panel.runModal()) !== 1) return;
    var base = String(panel.URL().path());
    var stamp = new Date().toISOString().replace(/[:.]/g, '-');
    output = base + '/Sketch交付-' + stamp;
  }
  if (fileExists(output)) throw deliveryError('这个保存位置已被使用','为保留已有的交付文件，本次没有覆盖该文件夹。请选择新的保存位置，或使用不同的文件夹名称。');
  var workingCopy = null, result = null, exportError = null, exportActivity = null;
  try {
    exportActivity = beginExportActivity();
    UI.message('正在创建安全的 Sketch 导出副本…');
    workingCopy = openExportCopy(d);
    labPrepareSnapshot(workingCopy);
    var exportDocument = workingCopy.document;
    var exportBoards = boardReferences.map(function (reference) {
      var board = exportDocument.getLayerWithID(reference.id);
      if (!board || !isBoard(board)) {
        throw new Error('导出副本中找不到画板“' + reference.name + '”。请重试导出。');
      }
      return board;
    });
    if (!exportBoards.length) throw new Error('文档中没有可检查的图层。');
    mkdir(output); mkdir(output + '/preview'); mkdir(output + '/assets');
    mkdir(output + '/web-slices');
    var project = { sliceMode: 'browser-svg', scale: c.scale, unit: c.unit, colorFormat: c.colorFormat, artboards: [], slices: [],
      colors: documentColorVariables(exportDocument) };
    exportBoards.forEach(function (b, i) {
      UI.message('正在导出画板 ' + (i + 1) + ' / ' + exportBoards.length + '：' + b.name);
      project.artboards.push(extractBoard(b, output, project, c));
    });
    labFinalizeProject(workingCopy, exportBoards, project, output, context);
    devAttachAnnotations(d, project);
    project.generatedAt = new Date().toISOString();
    UI.message('正在校验交付参数与切图完整性…');
    var validation = validateExport(project, output);
    writeText(output + '/交付校验.json', JSON.stringify(validation, null, 2));
    // Warnings are diagnostic only. Structural/resource failures still throw
    // from validateExport, but a recoverable SVG warning must not discard an
    // otherwise usable delivery page.
    if (validation.warnings.length) UI.message('交付已生成，存在 ' + validation.warnings.length + ' 条可选核对提示。');
    var template = readText(resource(context, 'template.html'));
    var payload = labProjectPayload(project, output, workingCopy, context);
    template = template.replace('/* __SVG_LAB_DATA_RUNTIME__ */', function () { return payload.runtime; });
    template = template.replace('/* __SVG_LAB_VIEWER__ */', function () { return readText(resource(context, 'vendor/iro.min.js')) + '\n' + readText(resource(context, 'svg-core.js')) + '\n' + readText(resource(context, 'svg-lab.js')); });
    template = template.replace('/* __DEVELOPER_VIEWER__ */', function () {
      return readText(resource(context,'developer-viewer.js'));
    });
    var renderedHTML = template.replace('window.__SM_PROJECT_DATA__', function () { return payload.expression; });
    if (renderedHTML === template) throw new Error('交付页模板缺少数据注入位置。');
    renderedHTML=renderedHTML.replace('</head>','<meta name="author" content="执手听风丶">\n</head>');
    writeText(output + '/index.html', renderedHTML);
    writeText(output + '/使用说明.txt', '💻 设计交付 v1.0\n标注：点击头像标记查看详情；工具栏“标注”打开列表。导出的网页仅查看注释，新增、编辑、删除请在 Sketch 原生工具栏的设计模式中操作，保存文档后重新导出。\n打开 index.html，请保留 preview 和 assets 文件夹。\n保留 Sketch 手动切图；选中图层或编组后可以添加切图，选择 PNG、JPG、SVG 及倍率，单张直接下载，多张打包下载。\n网页新增切图仅在当前会话保留，不写回 Sketch。\n尺寸、间距和代码使用 Sketch 参数，按设计倍率换算。Web、iOS、Android 分别使用 px、pt、dp，下载像素尺寸为原始尺寸除以设计倍率再乘下载倍率。\n画板网页预览使用 Sketch 原生 4 倍 PNG 以保持视觉效果，SVG 保留在后台用于切图和代码参考；文字转轮廓只影响 SVG 后台资源，不改动文字参数。复杂效果可能使用原生位图。所有画板按照 Sketch 原有位置在同一画布展示，左侧点击画板即可定位；\n不支持或无法找到的资源会记录在交付校验.json，不生成空白切图。JPG 无透明通道，使用所选底色。\n');
    if (c.zip && options.zip !== false) {
      var task = NSTask.alloc().init();
      task.setLaunchPath('/usr/bin/ditto');
      task.setArguments(['-c', '-k', '--norsrc', '--noextattr', '--keepParent', output, output + '.zip']);
      task.launch(); task.waitUntilExit();
      if (Number(task.terminationStatus()) !== 0) throw deliveryError('网页已导出，压缩包未生成','交付网页和资源已保存在所选文件夹，可以直接使用。请检查磁盘空间后手动压缩该文件夹，或重新导出。\n保存位置：' + output);
    }
    var authored = project.artboards.reduce(function (total, b) { return total + b.layers.filter(function (l) { return l.labBuiltIn && !l.hidden && !l.labSliceError; }).length; }, 0);
    UI.message('导出完成：' + exportBoards.length + ' 个画板，' + authored + ' 组切图。');
    if (options.reveal !== false) NSWorkspace.sharedWorkspace().activateFileViewerSelectingURLs([NSURL.fileURLWithPath(output + '/index.html')]);
    result = { output: output, project: project };
  } catch (error) {
    exportError = error;
    if (fileExists(output)) {
      try { writeText(output + '/导出未完成.txt', String(error.message || error) + '\n\n' + String(error.stack || error)); } catch (writeError) {}
    }
  } finally {
    try { closeExportCopy(workingCopy); } catch (cleanupError) { if (!exportError) exportError = cleanupError; }
    try { endExportActivity(exportActivity); } catch (activityError) { if (!exportError) exportError = activityError; }
    if (options.closeDocument) {
      try { d.close(); } catch (closeDocumentError) { if (!exportError) exportError = closeDocumentError; }
    }
  }
  if (exportError) throw exportError;
  return result;
}
function commandOptions(context, scope) {
  var output = context && context.measureOutput ? String(context.measureOutput) : null;
  var targetPath = context && context.measureDocumentPath ? String(context.measureDocumentPath) : null;
  var targetScope = context && context.measureScope ? String(context.measureScope) : scope;
  if (['selection', 'selected-board', 'page', 'all'].indexOf(targetScope) < 0) targetScope = scope;
  var boardIDs = context && context.measureBoardIDs ? String(context.measureBoardIDs).split(',').filter(Boolean) : null;
  var targetDocument = null;
  var closeTargetDocument = false;
  if (targetPath) {
    var documents = sketch.getDocuments ? sketch.getDocuments() : [];
    for (var i = 0; i < documents.length; i++) {
      if (decodedDocumentPath(documents[i]) === targetPath) { targetDocument = documents[i]; break; }
    }
    if (!targetDocument) { targetDocument = openDocumentWithoutWindow(targetPath); closeTargetDocument = true; }
    if (!targetDocument) throw new Error('自动验收找不到已打开的测试文档：' + targetPath);
  }
  return { scope: targetScope, boardIDs: boardIDs, document: targetDocument || undefined,
    closeDocument: closeTargetDocument, output: output,
    zip: output ? false : undefined, reveal: output ? false : undefined };
}
// Sketch 2026 recursively unboxes command return values. Returning the full project can overflow Mocha's stack.
function commandExport(context) { run(function () { performExport(context, commandOptions(context, 'page')); }, '暂时无法完成导出'); }
function commandExportAllPages(context) { run(function () { performExport(context, commandOptions(context, 'all')); }, '暂时无法完成导出'); }
function commandExportSelectedBoard(context) { run(function () { performExport(context, commandOptions(context, 'selected-board')); }, '暂时无法完成导出'); }

function selection(min, max) {
  var d = document(), layers = d.selectedLayers.layers.filter(function (l) { return !isMark(l); });
  if (layers.length < min) throw deliveryError(min===2?'请选择两个图层':'请先选择图层',min===2?'请选中两个需要比较的图层，再添加间距标注。\n按住 Shift 可以同时选择多个图层。':'请先选中要标注的图层或编组，再点击标注工具。');
  if (max && layers.length > max) throw deliveryError(max===2?'间距标注需要两个图层':'选中的图层较多',max===2?'当前选中了 '+layers.length+' 个图层。请只保留两个需要比较的图层，再添加间距标注。':'当前选中了 '+layers.length+' 个图层，一次最多可标注 '+max+' 个。请分批选择后重试。');
  return layers;
}
function markContainer(layer) {
  var parent = layer.parent;
  while (parent && parent.type !== 'Page') {
    if (isBoard(parent)) return parent;
    parent = parent.parent;
  }
  return layer.getParentPage();
}
function markGroup(layer) {
  var parent = markContainer(layer);
  var group = new dom.Group({ parent: parent, name: '__SM_ZH_MARK__' + '标注', frame: { x: 0, y: 0, width: 1, height: 1 } });
  if (typeof group.ignoresStackLayout === 'boolean') group.ignoresStackLayout = true;
  return group;
}
function markRect(layer, parent) {
  // Group.frame may retain an old size after its contents change. Sketch's
  // alignment rect is the current selection outline and resolves nested transforms.
  var nativeLayer = layer.sketchObject;
  if (!nativeLayer.respondsToSelector(NSSelectorFromString('alignmentRectInCoordinateSpace:'))) {
    throw new Error('当前 Sketch 缺少图层边界接口，无法准确生成标注。');
  }
  var r = nativeLayer.alignmentRectInCoordinateSpace(parent.sketchObject);
  return { x: Number(r.origin.x), y: Number(r.origin.y), width: Number(r.size.width), height: Number(r.size.height) };
}
function shape(parent, x, y, width, height, color, opacity) {
  return new dom.ShapePath({ parent: parent, name: '标注线', shapeType: dom.ShapePath.ShapeType.Rectangle,
    frame: { x: x, y: y, width: width, height: height },
    style: { fills: [{ color: color }], opacity: opacity == null ? 1 : opacity, borders: [] } });
}
function text(parent, value, x, y) {
  var layer = new dom.Text({ parent: parent, name: '标注文字', text: value,
    frame: { x: x, y: y, width: 100, height: 22 }, style: { fontSize: 14, textColor: '#E33E50', fontFamily: 'PingFang SC' } });
  // Sketch resets weight to Regular when fontFamily is assigned, so set weight last.
  layer.style.fontWeight = 6;
  return layer;
}
function length(value, isText) {
  var c = config();
  var unit = c.unit;
  if (isText && c.unit.indexOf('/') >= 0) unit = c.unit.split('/')[1];
  else if (c.unit.indexOf('/') >= 0) unit = c.unit.split('/')[0];
  return round(value / c.scale) + unit;
}
function finish(group) {
  group.adjustToFit(); group.locked = false; UI.message('标注已添加。');
}
function measurement(g, x1, y1, x2, y2, value, axis) {
  var thickness=2,capLength=8,color='#E33E50';
  if (y1 === y2 && axis !== 'vertical') {
    var left=Math.min(x1,x2),right=Math.max(x1,x2),width=right-left;
    if(width>0){
      shape(g,left,y1-thickness/2,width,thickness,color);
      var capWidth=Math.min(thickness,width);
      shape(g,left,y1-capLength/2,capWidth,capLength,color);
      shape(g,right-capWidth,y1-capLength/2,capWidth,capLength,color);
    }
    var horizontalLabel=text(g,length(value),0,0);
    horizontalLabel.frame.x=(x1+x2)/2-horizontalLabel.frame.width/2;
    horizontalLabel.frame.y=y1-thickness/2-4-horizontalLabel.frame.height;
  } else {
    var top=Math.min(y1,y2),bottom=Math.max(y1,y2),height=bottom-top;
    if(height>0){
      shape(g,x1-thickness/2,top,thickness,height,color);
      var capHeight=Math.min(thickness,height);
      shape(g,x1-capLength/2,top,capLength,capHeight,color);
      shape(g,x1-capLength/2,bottom-capHeight,capLength,capHeight,color);
    }
    var verticalLabel=text(g,length(value),x1+thickness/2+4,0);
    verticalLabel.frame.y=(y1+y2)/2-verticalLabel.frame.height/2;
  }
}
function commandDimension(axis) { return run(function () {
  selection(1, 1000).forEach(function (l) {
    var r = markRect(l, markContainer(l)), g = markGroup(l);
    if (axis === 'width') measurement(g, r.x, r.y - 10, r.x + r.width, r.y - 10, r.width);
    else measurement(g, r.x + r.width + 10, r.y, r.x + r.width + 10, r.y + r.height, r.height);
    finish(g);
  });
}); }
function commandWidths() { return commandDimension('width'); }
function commandHeights() { return commandDimension('height'); }
function commandOverlays() { return run(function () {
  selection(1, 1000).forEach(function (l) {
    var r = markRect(l, markContainer(l)), g = markGroup(l);
    new dom.ShapePath({ parent: g, name: '标注区域', shapeType: dom.ShapePath.ShapeType.Rectangle,
      frame: { x: r.x, y: r.y, width: r.width, height: r.height },
      style: { fills: [{ color: '#E33E50' }], opacity: 0.2, borders: [] } });
    text(g, length(r.width) + ' × ' + length(r.height), r.x, r.y); finish(g);
  });
}); }
// Spacing measures only the positive gaps between exactly two design layers.
function commandSpacings() { return run(function () {
  var layers = selection(2, 2), a = layers[0], b = layers[1], parent = markContainer(a);
  if (b.getParentPage().id !== a.getParentPage().id) throw deliveryError('请选择同一页面的图层','间距标注需要比较同一页面中的两个图层。请调整选择后重试。');
  var r = markRect(a, parent), q = markRect(b, parent), lines = [];
  if (r.x + r.width < q.x || q.x + q.width < r.x) {
    var left = r.x < q.x ? r : q, right = r.x < q.x ? q : r;
    var y = (Math.max(r.y, q.y) + Math.min(r.y + r.height, q.y + q.height)) / 2;
    lines.push([left.x + left.width, y, right.x, y, right.x - left.x - left.width]);
  }
  if (r.y + r.height < q.y || q.y + q.height < r.y) {
    var top = r.y < q.y ? r : q, bottom = r.y < q.y ? q : r;
    var x = (Math.max(r.x, q.x) + Math.min(r.x + r.width, q.x + q.width)) / 2;
    lines.push([x, top.y + top.height, x, bottom.y, bottom.y - top.y - top.height]);
  }
  if (!lines.length) throw deliveryError('这两个图层之间没有间距','选中的两个图层重叠或边缘相接，因此没有可添加的间距标注。可以选择其他图层进行比较。');
  var g = markGroup(a);
  lines.forEach(function (line) { measurement(g, line[0], line[1], line[2], line[3], line[4]); });
  finish(g);
}); }
// Margins retain the existing reference: the nearest containing artboard / Frame.
function commandMargin(side) { return run(function () {
  if (['left','right','top','bottom'].indexOf(side) < 0) throw new Error('无效的边距方向。');
  // Validate the entire selection first, so a mixed invalid selection creates no partial marks.
  var items = selection(1, 1000).map(function (layer) {
    var parent = markContainer(layer);
    if (!parent || parent.type === 'Page') throw deliveryError('请在画板内选择图层','边距标注测量图层与所在画板或 Frame 的距离。请先选择画板内的图层，再添加边距标注。');
    return {layer:layer, parent:parent, bounds:markRect(layer,parent)};
  });
  items.forEach(function (item) {
    var r=item.bounds, q=item.parent.frame, cx=r.x+r.width/2, cy=r.y+r.height/2;
    var g=markGroup(item.layer);
    if(side==='left') measurement(g,0,cy,r.x,cy,r.x);
    else if(side==='right') measurement(g,r.x+r.width,cy,q.width,cy,q.width-r.x-r.width);
    else if(side==='top') measurement(g,cx,0,cx,r.y,r.y,'vertical');
    else measurement(g,cx,r.y+r.height,cx,q.height,q.height-r.y-r.height,'vertical');
    finish(g);
  });
}); }
function commandLeftMargins() { return commandMargin('left'); }
function commandRightMargins() { return commandMargin('right'); }
function commandTopMargins() { return commandMargin('top'); }
function commandBottomMargins() { return commandMargin('bottom'); }
function commandProperties() { return run(function () {
  selection(1, 1000).forEach(function (l) {
    var r = markRect(l, markContainer(l)), g = markGroup(l), data = layerData(l, g.parent, config(), l.style ? l.style.opacity : 1);
    var lines = ['图层：' + l.name, '尺寸：' + length(r.width) + ' × ' + length(r.height), '不透明度：' + Math.round(data.opacity * 100) + '%'];
    if (data.radius) lines.push('圆角：' + length(data.radius));
    data.fills.forEach(function (f) { lines.push(f.fillType === 'color' ? '填充：' + f.color[config().colorFormat] : '填充：渐变'); });
    data.borders.forEach(function (b) { lines.push('边框：' + length(b.thickness) + ' ' + b.color[config().colorFormat]); });
    data.shadows.forEach(function (s) { lines.push((s.type === 'inner' ? '内阴影：' : '外阴影：') + [length(s.offsetX), length(s.offsetY), length(s.blurRadius), length(s.spread), s.color[config().colorFormat]].join(' ')); });
    if (l.type === 'Text') lines.push('字体：' + data.fontFace, '字号：' + length(data.fontSize, true), '行高：' + length(data.lineHeight, true), '字间距：' + length(data.letterSpacing, true), '文字颜色：' + data.color[config().colorFormat]);
    text(g, lines.join('\n'), r.x + r.width + 16, r.y); finish(g);
  });
}); }
if (typeof module !== 'undefined') module.exports = { performExport: performExport, getBoards: getBoards, config: config,
  commandWidths: commandWidths, commandHeights: commandHeights, commandSpacings: commandSpacings, commandProperties: commandProperties,
  commandOverlays: commandOverlays, commandLeftMargins: commandLeftMargins, commandRightMargins: commandRightMargins,
  commandTopMargins: commandTopMargins, commandBottomMargins: commandBottomMargins };

// Render from a private snapshot in a separate process.
var labSnapshotPath = null;
var labOriginalPath = null;
var labRasterIDs = {};
var labOwnRasterIDs = {};
var labCodeEffectIDs = {};
var labTextOutlineFailureCount = {};
function labPNGBatches(items, scale) {
  var batches = [];
  items.map(function (item) { return {item:item,pixels:Math.max(1,item.width)*Math.max(1,item.height)*scale*scale}; })
    .sort(function (a,b) { return b.pixels-a.pixels; }).forEach(function (entry) {
      var target = null;
      for (var i=0;i<batches.length;i++) {
        if (batches[i].items.length<40&&batches[i].pixels+entry.pixels<=32000000) { target=batches[i]; break; }
      }
      if (!target) { target={items:[],pixels:0}; batches.push(target); }
      target.items.push(entry.item); target.pixels+=entry.pixels;
    });
  return batches;
}
function labRenderPNGs(items, source, directory, scale, contentsOnly, logPath) {
  var cli = String(NSBundle.mainBundle().bundlePath()) + '/Contents/MacOS/sketchtool';
  labPNGBatches(items,scale).forEach(function (batch) {
    var args = ['export','layers',source,'--items='+batch.items.map(function(item){return item.id}).join(','),'--output='+directory,
      '--formats=png','--scales='+scale,'--use-id-for-name=YES','--overwriting=YES','--save-for-web=YES'];
    if (contentsOnly) args.push('--group-contents-only=YES');
    labRun(cli,args,logPath);
  });
}
function labRun(executable, args, logPath) {
  var manager = NSFileManager.defaultManager();
  manager.createFileAtPath_contents_attributes(logPath, NSData.data(), null);
  var log = NSFileHandle.fileHandleForWritingAtPath(logPath);
  var task = NSTask.alloc().init();
  task.setLaunchPath(executable); task.setArguments(args);
  task.setStandardOutput(log); task.setStandardError(log);
  try {
    task.launch();
    var deadline = Date.now() + 180000;
    while (task.isRunning()) {
      if (Date.now() > deadline) {
        task.terminate();
        var stopDeadline = Date.now() + 2000;
        while (task.isRunning() && Date.now() < stopDeadline) NSThread.sleepForTimeInterval(0.05);
        if (task.isRunning()) {
          var stop = NSTask.alloc().init(); stop.setLaunchPath('/bin/kill');
          stop.setArguments(['-KILL', String(task.processIdentifier())]); stop.launch(); stop.waitUntilExit();
        }
        task.waitUntilExit();
        throw new Error('独立渲染超时，已停止；原文档未修改。');
      }
      NSThread.sleepForTimeInterval(0.05);
    }
    if (Number(task.terminationStatus()) !== 0) throw new Error('独立渲染失败：' + readText(logPath).slice(-1600));
  } finally { log.closeFile(); }
}
function labPrepareSnapshot(copy) {
  if (!copy || !copy.path || !copy.directory) throw new Error('缺少独立导出副本。');
  var directory = copy.directory + '/svg-source';
  labOriginalPath = copy.path;
  labRasterIDs = {};
  labOwnRasterIDs = {};
  labCodeEffectIDs = {};
  labTextOutlineFailureCount = {};
  mkdir(directory);
  labRun('/usr/bin/ditto', ['-x', '-k', copy.path, directory], copy.directory + '/unpack.log');
  var documentPath = directory + '/document.json';
  var data = JSON.parse(readText(documentPath));
  function visit(layer) {
    if (layer.do_objectID && layer.name != null) layer.name = 'lab-' + layer.do_objectID;
    if (layer.layers) layer.layers = layer.layers.filter(function (child) { return !isMark(child); });
    (layer.layers || []).forEach(visit);
  }
  (data.pages || []).forEach(function (ref) {
    if (!/^pages\/[A-Za-z0-9_-]+$/.test(String(ref._ref))) throw new Error('页面路径无效。');
    var path = directory + '/' + ref._ref + '.json';
    var page = JSON.parse(readText(path)); visit(page); writeText(path, JSON.stringify(page));
  });
  (data.foreignSymbols || []).forEach(function (symbol) { if (symbol.symbolMaster) visit(symbol.symbolMaster); });
  writeText(documentPath, JSON.stringify(data));
  labSnapshotPath = copy.directory + '/svg-source.sketch';
}
boardPreview = function (layer, output, id) {
  // A detached layer lacks the document required by MSHighLevelExporter.
  // Reject it before any rendering; render only the on-disk private snapshot.
  if (!layer || !layer.getParentPage() || !labOriginalPath || !fileExists(labOriginalPath)) {
    throw new Error('只能从已保存的独立文档副本渲染，无法导出游离图层。');
  }
  return {path: 'preview/' + id + '.svg', format: 'svg', scale: 1, svgSource: '', warnings: []};
};
function labArchive(native) {
  var archiver = MSJSONDataArchiver.alloc().init(), error = MOPointer.alloc().init();
  archiver.archiveObjectIDs = true;
  archiver.archivedDataWithRootObject_error(native.immutableModelObject(), error);
  if (error.value()) throw new Error('无法保存渲染副本：' + error.value());
  return JSON.parse(String(NSString.alloc().initWithData_encoding(archiver.archivedData(), NSUTF8StringEncoding)));
}
function labOutlinedBoard(board) {
  // Freeze layout before Sketch's outline command replaces text in the private copy.
  var outlined = {}, frozen = labArchive(board.sketchObject);
  var boardKey = String(board.id || frozen.do_objectID);
  function unsupported(raw) {
    if (((raw.style && raw.style.blurs) || []).some(function (blur) { return blur.isEnabled; })) labCodeEffectIDs[raw.do_objectID] = true;
    var own = ((raw.style && raw.style.blurs) || []).some(function (blur) { return blur.isEnabled && Number(blur.type) !== 0 && (Number(blur.radius) > 0 || Number(blur.type) === 4); });
    if (own) labOwnRasterIDs[raw.do_objectID] = true;
    (raw.layers || []).forEach(function (child) { if (unsupported(child)) own = true; });
    if (own) labRasterIDs[raw.do_objectID] = true;
    return own && raw.isVisible !== false && !(raw.style && raw.style.contextSettings && Number(raw.style.contextSettings.opacity) === 0);
  }
  unsupported(frozen);
  function capture(layer) {
    if (layer.type === 'Text' && String(layer.text || '').length) {
      var key = String(layer.id), original = labArchive(layer.sketchObject);
      try {
        var paths = layer.sketchObject.layersByConvertingToOutlines(), items = [];
        for (var i = 0; i < paths.count(); i++) items.push(labArchive(paths[i]));
        if (!items.length) throw new Error('转换结果为空');
        var raw = items[0];
        if (items.length > 1) {
          raw = { _class: 'group', frame: original.frame,
            groupLayout: { _class: 'MSImmutableFreeformGroupLayout' }, layers: items };
          items.forEach(function (item) { item.frame.x -= raw.frame.x; item.frame.y -= raw.frame.y; });
        }
        raw.do_objectID = key; raw.name = 'lab-' + key;
        raw.exportOptions = original.exportOptions;
        outlined[key] = raw;
      } catch (error) {
        // Keep the original text in the private snapshot. The native 4x PNG
        // renderer can still reproduce it even when outlining is unavailable.
        labTextOutlineFailureCount[boardKey] = (labTextOutlineFailureCount[boardKey] || 0) + 1;
      }
    }
    (layer.layers || []).slice().forEach(capture);
  }
  capture(board);
  if (labTextOutlineFailureCount[boardKey]) labRasterIDs[boardKey] = true;
  function visit(raw) {
    if (outlined[raw.do_objectID]) raw = outlined[raw.do_objectID];
    if (raw.do_objectID) raw.name = 'lab-' + raw.do_objectID;
    if (raw.layers) raw.layers = raw.layers.filter(function (l) { return !isMark(l); }).map(visit);
    return raw;
  }
  return visit(frozen);
}
function labNormalize(paths, copy, context) {
  var plan = copy.directory + '/normalize-plan.json'; writeText(plan, JSON.stringify(paths));
  labRun('/usr/bin/osascript', ['-l', 'JavaScript', resource(context, 'normalize-svg.js'), plan], copy.directory + '/normalize.log');
}
function labImageSVG(path, width, height) {
  var data = NSData.dataWithContentsOfFile(path);
  if (!data) throw new Error('缺少原生效果图：' + path);
  return '<svg xmlns="http://www.w3.org/2000/svg" width="' + width + '" height="' + height + '" viewBox="0 0 ' + width + ' ' + height + '"><image width="' + width + '" height="' + height + '" href="data:image/png;base64,' + String(data.base64EncodedStringWithOptions(0)) + '"/></svg>';
}
function labAssetIndex(replacements) {
  var index = {}, parents = {};
  function indexLayer(raw, parent) {
    index[raw.do_objectID] = raw; parents[raw.do_objectID] = parent;
    (raw.layers || []).forEach(function (child) { indexLayer(child, raw); });
  }
  Object.keys(replacements).forEach(function (key) { indexLayer(replacements[key], null); });
  return {layers:index, parents:parents};
}
function labAssetRoot(layer, index) {
  var target = index.layers[layer.labNativeID];
  if (!target) throw new Error('切图原始图层缺失：' + layer.name);
  var root = target._class === 'slice' ? index.parents[layer.labNativeID] : target;
  if (!root) throw new Error('切片缺少内容容器：' + layer.name);
  return root;
}
function labRawHasPaint(raw) {
  var style = raw.style || {}, context = style.contextSettings || {};
  if (raw.isVisible === false || (context.opacity != null && Number(context.opacity) <= 0)) return false;
  if (raw._class === 'bitmap' && raw.image) return true;
  if (raw._class === 'text' && raw.attributedString && raw.attributedString.string) return true;
  function painted(paint) {
    if (paint.isEnabled === false || (paint.contextSettings && Number(paint.contextSettings.opacity) === 0)) return false;
    if (Number(paint.fillType) === 1 && paint.gradient) return (paint.gradient.stops || []).some(function(stop){return !stop.color || Number(stop.color.alpha) > 0;});
    if (Number(paint.fillType) === 4) return Boolean(paint.image);
    return !paint.color || paint.color.alpha == null || Number(paint.color.alpha) > 0;
  }
  if ((style.fills || []).some(painted) || (style.borders || []).some(function(border){return Number(border.thickness) > 0 && painted(border);})) return true;
  return (raw.layers || []).some(labRawHasPaint);
}
function labPlanAssets(candidates, replacements) {
  var index = labAssetIndex(replacements), groups = {}, unique = [], aliases = [];
  // Prefer an authored cut as the owner when an internal fallback is identical.
  candidates.slice().sort(function(a,b){return Number(Boolean(b.labBuiltIn))-Number(Boolean(a.labBuiltIn));}).forEach(function(layer){
    var root = labAssetRoot(layer,index), target = index.layers[layer.labNativeID];
    if (!labRawHasPaint(root)) {
      layer.labSliceError = '此图层没有可见绘制内容，未生成空白切图。';
      return;
    }
    var normalized = Object.assign({},root,{frame:Object.assign({},root.frame,{x:0,y:0})});
    delete normalized.flexItem;
    // Only exact native content is shared. Size, effects, image references and
    // slice configuration remain in the key; placement and object names do not.
    var key = JSON.stringify({raster:Boolean(labRasterIDs[layer.labNativeID]),
      slice:target._class==='slice'?target.frame:null,root:normalized},function(name,value){
      return name==='do_objectID'||name==='name'?undefined:value;
    });
    var owner = groups[key];
    if (owner) aliases.push({layer:layer,owner:owner});
    else { groups[key]=layer;unique.push(layer); }
  });
  return {layers:unique,aliases:aliases};
}
function labAssetSnapshot(copy, layers, replacements) {
  var sourceDirectory = copy.directory + '/svg-source', directory = copy.directory + '/slice-source';
  labRun('/usr/bin/ditto', [sourceDirectory, directory], copy.directory + '/copy-slices.log');
  var doc = JSON.parse(readText(directory + '/document.json')), index = labAssetIndex(replacements);
  var pagePath = directory + '/' + doc.pages[0]._ref + '.json';
  var page = JSON.parse(readText(pagePath)); page.layers = [];
  layers.forEach(function (layer) {
    // A native slice needs its siblings; a layer export needs only its subtree.
    var clone = JSON.parse(JSON.stringify(labAssetRoot(layer,index)));
    function remap(raw) {
      if (raw.do_objectID !== layer.labNativeID) raw.do_objectID = String(NSUUID.UUID().UUIDString());
      (raw.layers || []).forEach(remap);
    }
    remap(clone);
    clone.frame.x = 0; clone.frame.y = 0;
    delete clone.flexItem;
    page.layers.push(clone);
  });
  // The private asset document has no original page siblings or ancestor clips.
  doc.pages = [doc.pages[0]];
  writeText(pagePath, JSON.stringify(page)); writeText(directory + '/document.json', JSON.stringify(doc));
  var snapshot = copy.directory + '/slices.sketch';
  labRun('/usr/bin/ditto', ['-c', '-k', '--zlibCompressionLevel', '0', directory, snapshot], copy.directory + '/pack-slices.log');
  return snapshot;
}
function labFinalizeProject(copy, boards, project, output, context) {
  var replacements = {}, directory = copy.directory + '/svg-source';
  boards.forEach(function (board) { var key = String(board.id); replacements[key] = labOutlinedBoard(board); });
  var doc = JSON.parse(readText(directory + '/document.json'));
  (doc.pages || []).forEach(function (ref) {
    var path = directory + '/' + ref._ref + '.json', page = JSON.parse(readText(path));
    function visit(raw) {
      if (replacements[raw.do_objectID]) return replacements[raw.do_objectID];
      if (raw.layers) raw.layers = raw.layers.map(visit);
      return raw;
    }
    writeText(path, JSON.stringify(visit(page)));
  });
  removePath(labSnapshotPath);
  labRun('/usr/bin/ditto', ['-c', '-k', '--zlibCompressionLevel', '0', directory, labSnapshotPath], copy.directory + '/pack-outlines.log');
  var cli = String(NSBundle.mainBundle().bundlePath()) + '/Contents/MacOS/sketchtool';
  labRun(cli, ['export', 'layers', labSnapshotPath, '--items=' + boards.map(function (b) { return b.id; }).join(','),
    '--output=' + output + '/preview', '--formats=svg', '--scales=1', '--use-id-for-name=YES',
    '--overwriting=YES', '--save-for-web=YES'], output + '/svg-render.log');
  var svgPaths = project.artboards.map(function (b) { return output + '/' + b.imagePath; });
  labNormalize(svgPaths, copy, context);
  // Always use the native 4x render for the board preview. SVG remains in the
  // payload as a backend for on-demand cuts and code inspection.
  labRenderPNGs(project.artboards.map(function (b) {
    return {id:b.objectID,width:b.width,height:b.height};
  }),labOriginalPath,output+'/preview',4,false,output+'/native-effects.log');
  var dedicated = [];
  project.artboards.forEach(function (board) {
    board.svgPath = board.imagePath;
    board.svgSource = readText(output + '/' + board.svgPath);
    board.imagePath = 'preview/' + board.objectID + '@4x.png';
    board.previewFormat = 'png';
    board.previewScale = 4;
    if (!fileExists(output + '/' + board.imagePath)) throw new Error('原生画板预览缺失：' + board.name);
    var byID = {};
    board.layers.forEach(function (l) { byID[l.objectID] = l; });
    board.layers.forEach(function (l) {
      if (labCodeEffectIDs[l.labNativeID] || (l.blendMode && l.blendMode !== 'Normal')) l.labCodeWarning = '此图层含模糊或混合效果，下方代码不包含该效果，不能用于完整复现。';
      var parent = byID[l.parentObjectID];
      l.labBuiltIn = Boolean(l.manualExport || l.autoIcon || (l.nativeType === 'Slice' && !(parent && parent.manualExport)));
      if (l.labBuiltIn && l.hidden) l.labSliceError = '此切图在 Sketch 中被隐藏，没有可见内容；未生成空白下载。';
      // Boolean operands and Slice markers are not separate visual assets.
      // Ordinary vector layers are cut from the shared board SVG on demand.
      var unmappedGroup = l.nativeType === 'Group' && l.hasChildren && board.svgSource.indexOf('id="' + l.svgNodeID + '"') < 0;
      if (l.labNativeID && !l.hidden && (l.labBuiltIn || unmappedGroup || (l.nativeType !== 'Slice' && labRasterIDs[l.labNativeID]))) dedicated.push(l);
    });
    if (labRasterIDs[board.objectID]) {
      // Backdrop compositing depends on the whole scene, not just layer bounds.
      board.nativeEffects = true;
      board.svgWarnings = ['此画板含 SVG 无法独立复现的效果，使用原生位图保持外观。'];
    }
  });
  var plan = labPlanAssets(dedicated,replacements);
  dedicated = plan.layers;
  var assetSnapshot = dedicated.length ? labAssetSnapshot(copy, dedicated, replacements) : labSnapshotPath;
  var assetDirectory = copy.directory + '/asset-render';
  mkdir(assetDirectory);
  var vectorLayers = dedicated.filter(function (l) { return !labRasterIDs[l.labNativeID]; });
  for (var start = 0; start < vectorLayers.length; start += 40) {
    var batch = vectorLayers.slice(start, start + 40);
    labRun(cli, ['export', 'layers', assetSnapshot, '--items=' + batch.map(function (l) { return l.labNativeID; }).join(','),
      '--output=' + assetDirectory, '--formats=svg', '--scales=1', '--use-id-for-name=YES',
      '--overwriting=YES', '--save-for-web=YES', '--group-contents-only=YES'], output + '/asset-render.log');
  }
  // Native PNG jobs are independent of the vector batch boundaries. Pack them
  // together without raising the existing pixel or item limit per renderer.
  var vectorPaths = dedicated.filter(function(l){return !labRasterIDs[l.labNativeID]}).map(function(l){return assetDirectory+'/'+l.labNativeID+'.svg'});
  for (var offset=0;offset<vectorPaths.length;offset+=128) labNormalize(vectorPaths.slice(offset,offset+128),copy,context);
  labRenderPNGs(dedicated.filter(function (l) { return labRasterIDs[l.labNativeID]; }).map(function (l) {
    var r=l.visualRect||l.rect; return {id:l.labNativeID,width:r.width,height:r.height};
  }),assetSnapshot,assetDirectory,4,true,output+'/native-asset-effects.log');
  dedicated.forEach(function (l) {
      var path = assetDirectory + '/' + l.labNativeID + '.svg';
      // Raster fallback replaces this SVG completely. Do not render a vector
      // version first, only to discard it after an expensive native export.
      if (labRasterIDs[l.labNativeID]) {
        var png = assetDirectory + '/' + l.labNativeID + '@4x.png', size = inspectExportResource(png, 'png');
        if (!size.width || !size.height) throw new Error('原生切图尺寸无效：' + l.name);
        l.labAssetSource = labImageSVG(png, size.width / 4, size.height / 4); writeText(path, l.labAssetSource);
        removePath(png);
        l.labRasterFallback = true;
      } else {
        if (!fileExists(path)) throw new Error('原生切图缺失：' + l.name);
        l.labAssetSource = readText(path);
      }
      if (!/<svg\b/.test(l.labAssetSource) || !/<(?:path|rect|circle|ellipse|polygon|polyline|line|image|use)\b/.test(l.labAssetSource)) {
        if (l.labBuiltIn && !l.hidden) throw new Error('已有切图导出为空，已停止交付：' + l.name);
        l.labSliceError = l.hidden ? '此切图在 Sketch 中被隐藏，没有可见内容；未生成空白下载。' : 'Sketch 未生成此内部图层的独立可见内容，请选择包含它的编组。';
        delete l.labAssetSource;
        removePath(path);
        return;
      }
      if (l.labBuiltIn) {
        l.labAssetPath = 'assets/' + l.labNativeID + '.svg';
        writeText(output + '/' + l.labAssetPath,l.labAssetSource);
      }
  });
  plan.aliases.forEach(function(alias){
    alias.layer.labAssetSource=alias.owner.labAssetSource;
    if(alias.owner.labRasterFallback)alias.layer.labRasterFallback=true;
    if(alias.owner.labSliceError)alias.layer.labSliceError=alias.owner.labSliceError;
    if(alias.owner.labAssetPath)alias.layer.labAssetPath=alias.owner.labAssetPath;
  });
}
function labProjectPayload(project, output, copy, context) {
  var json = JSON.stringify(project);
  writeText(output + '/规范数据.json', json);
  if (json.length < 32768) return {runtime:'', expression:scriptJSON(project)};
  var packedJSON = require('../Resources/project-codec.js').encode(project);
  var packedInput = copy.directory + '/project-packed.json';
  writeText(packedInput, packedJSON);
  var packedPath = copy.directory + '/project.json.gz';
  labRun('/usr/bin/gzip', ['-1', '-n', '-c', packedInput], packedPath);
  var bytes = NSData.dataWithContentsOfFile(packedPath);
  if (!bytes || !Number(bytes.length())) throw new Error('交付数据压缩失败。');
  return {runtime:readText(resource(context, 'vendor/fflate.min.js')) + '\n' + readText(resource(context, 'project-codec.js')),
    expression:'(await SMProjectCodec.load(' + scriptJSON(String(bytes.base64EncodedStringWithOptions(0))) + '))'};
}
// Use shared SVG nodes where possible; dedicated assets cover authored exports and unsupported mappings.
exportAssets = function () {};
exportWebSlicesBatch = function () {};
image = function () { throw new Error('画板与切图应使用独立文档渲染。'); };

var DEV_PROFILE_KEY = 'measure.zh-modern.profile.v1';
var DEV_DEFAULT_AVATAR = '';
var DEV_VALIDATED_AVATARS = [];
function devInitializeAvatar(context) {
  if (DEV_DEFAULT_AVATAR) return;
  var data=NSData.dataWithContentsOfFile(resource(context,'default-avatar.png'));
  if(!data)throw new Error('默认头像资源缺失，请安装完整插件。');
  DEV_DEFAULT_AVATAR='data:image/png;base64,'+String(data.base64EncodedStringWithOptions(0));
  if(!devAvatarDataValid(DEV_DEFAULT_AVATAR))throw new Error('默认头像资源损坏，请重新复制完整插件。');
}
function devAvatarDataValid(value) {
  if(!/^data:image\/(png|jpeg);base64,[A-Za-z0-9+/=]+$/.test(value)||value.length>150000)return false;
  var encoded=value.slice(value.indexOf(',')+1),alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',bytes=[],bits=0,buffer=0;
  if(encoded.length%4)return false;
  for(var i=0;i<encoded.length;i++){var c=encoded.charAt(i);if(c==='=')break;var digit=alphabet.indexOf(c);if(digit<0)return false;buffer=(buffer<<6)|digit;bits+=6;if(bits>=8){bits-=8;bytes.push((buffer>>>bits)&255);}}
  if(value.indexOf('image/jpeg')>=0)return bytes.length>4&&bytes[0]===255&&bytes[1]===216&&bytes[bytes.length-2]===255&&bytes[bytes.length-1]===217;
  if(bytes.slice(0,8).join(',')!=='137,80,78,71,13,10,26,10')return false;
  function uint32(offset){return ((bytes[offset]*16777216)+(bytes[offset+1]<<16)+(bytes[offset+2]<<8)+bytes[offset+3])>>>0;}
  var offset=8,hasPixels=false,first=true;
  while(offset+12<=bytes.length){var length=uint32(offset),end=offset+8+length;if(end+4>bytes.length)return false;var type=String.fromCharCode.apply(null,bytes.slice(offset+4,offset+8));if(first&&(type!=='IHDR'||length!==13))return false;first=false;var crc=0xffffffff;for(var n=offset+4;n<end;n++){crc^=bytes[n];for(var bit=0;bit<8;bit++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}if(((crc^0xffffffff)>>>0)!==uint32(end))return false;if(type==='IDAT')hasPixels=true;if(type==='IEND')return hasPixels&&length===0&&end+4===bytes.length;offset=end+4;}
  return false;
}
function devSafeAvatar(value) {
  value=String(value||'');if(!value)return '';
  if(value===DEV_DEFAULT_AVATAR||DEV_VALIDATED_AVATARS.indexOf(value)>=0)return value;
  if(!devAvatarDataValid(value))return DEV_DEFAULT_AVATAR;
  var cls=NSClassFromString('SMNativeDeveloperControllerV62');
  if(cls&&!cls.isAvatarDataValid(value))return DEV_DEFAULT_AVATAR;
  DEV_VALIDATED_AVATARS.push(value);if(DEV_VALIDATED_AVATARS.length>32)DEV_VALIDATED_AVATARS.shift();return value;
}
function devProfile() {
  var saved=Settings.settingForKey(DEV_PROFILE_KEY)||{};
  return {name:String(saved.name||'执手听风丶'),avatar:devSafeAvatar(saved.avatar)||DEV_DEFAULT_AVATAR};
}
function devComposeProfile(note) { var p=devProfile();note.composerAuthor=p.name;note.composerAvatar=p.avatar;return note; }
// Document metadata is the only writable surface exposed by the inspector.
var DEV_NOTE_KEY = 'measure.zh-modern.annotations.v1';
var DEV_NOTE_NAMESPACE = 'com.utom.measure.zh-modern';
function devNoteDocumentData(d) { return d.sketchObject.documentData(); }
function devNotes(d) {
  // Native callbacks must not depend on the active plugin command namespace.
  var info=devNoteDocumentData(d).userInfo(),value=null;
  [DEV_NOTE_NAMESPACE,'com.utom.measure.zh-modern.native','com.sketchapp.temporary-script'].some(function(namespace){
    var group=info&&info.objectForKey(namespace),raw=group&&group.objectForKey(DEV_NOTE_KEY);
    if(raw!=null){value=JSON.parse(String(raw));return true;}return false;
  });
  if(value==null)value=Settings.documentSettingForKey(d,DEV_NOTE_KEY);
  if (!value) return [];
  if (value.version !== 1 || !Array.isArray(value.notes)) throw deliveryError('暂时无法读取这些标注','文档中的标注由其他版本保存。请先备份设计稿，再使用创建这些标注时的插件版本打开，避免覆盖原有内容。');
  var notes=JSON.parse(JSON.stringify(value.notes));
  notes.forEach(function(note){note.avatar=devSafeAvatar(note.avatar);(note.replies||[]).forEach(function(reply){reply.avatar=devSafeAvatar(reply.avatar);});});
  return notes;
}
function devStoreNotes(d, notes) {
  var data=devNoteDocumentData(d),original=data.userInfo();
  var info=original?original.mutableCopy():NSMutableDictionary.dictionary();
  var existing=info.objectForKey(DEV_NOTE_NAMESPACE);
  var group=existing?existing.mutableCopy():NSMutableDictionary.dictionary();
  var serialized=JSON.stringify({version:1,notes:notes});
  if(String(group.objectForKey(DEV_NOTE_KEY)||'')===serialized)return;
  group.setObject_forKey(serialized,DEV_NOTE_KEY);info.setObject_forKey(group,DEV_NOTE_NAMESPACE);
  data.setUserInfo(info);
  // Metadata alone does not mark NSDocument edited. Register it for Save/Close.
  flushDocumentChanges(d);
  d.sketchObject.updateChangeCount(NSChangeDone);
}
function devNotePageID(d,note) {
  var id=String(note.boardId||'');
  if(id.indexOf('page:')===0)return id.slice(5);
  var board=d.getLayerWithID(id),page=board&&(board.type==='Page'?board:board.getParentPage());
  return page?String(page.id):String(note.pageId||'');
}
function devDeleteNotes(d,scope) {
  if(scope!=='all'&&scope!=='page')throw new Error('无效的标注删除范围。');
  var notes=devNotes(d),pageId=String(d.selectedPage.id);
  var remaining=scope==='all'?[]:notes.filter(function(note){return devNotePageID(d,note)!==pageId;});
  var count=notes.length-remaining.length;
  if(count)devStoreNotes(d,remaining);
  return count;
}
function commandDeleteNotes(context,scope) { return run(function(){
  var d=document(),controller=nativeDeveloperDocuments().objectForKey(String(d.id));
  if(controller&&!Number(controller.closed())&&Number(controller.developer()))throw deliveryError('请先切换到设计模式','开发模式用于查看设计稿。请在交付工具栏中切换到“设计模式”，再删除标注。');
  var notes=devNotes(d),count=notes.filter(function(note){return scope==='all'||devNotePageID(d,note)===String(d.selectedPage.id);}).length;
  if(!count){UI.message(scope==='all'?'当前文档没有标注。':'当前页面没有标注。');return;}
  if(controller&&!Number(controller.closed())&&!controller.canDiscardComment())return;
  var title=scope==='all'?'删除全部标注':'删除当前页面标注';
  if(deliveryAlert(title+'？','将删除'+(scope==='all'?'当前文档':'当前页面')+'中的 '+count+' 条标注及其全部回复。此操作无法撤销，请确认后再删除。',['取消','删除标注'],0,context)!==1)return;
  devDeleteNotes(d,scope);
  if(controller&&!Number(controller.closed())){controller.closeComment();controller.setPins(nativeDeveloperPins(d));}
  UI.message('已删除 '+count+' 条标注及其全部回复。');
}); }
function devAttachAnnotations(d, project) {
  var notes = devNotes(d);
  project.artboards.forEach(function (board) {
    board.annotations = notes.filter(function (note) { return note.boardId === String(board.objectID); }).map(function (note) {
      var result = JSON.parse(JSON.stringify(note));
      var target = board.layers.filter(function (l) { return (String(l.objectID) === note.layerId || String(l.labNativeID || '') === note.layerId); })[0];
      if (target) {
        result.layerId = String(target.objectID);
        var r = target.selectionRect || target.logicalRect || target.rect;
        result.x = r.x + r.width * number(note.u, .5); result.y = r.y + r.height * number(note.v, .5);
      } else {
        if (note.layerId) result.detached = true;
        if (board.virtualOrigin) { result.x += number(note.originX)-board.virtualOrigin.x; result.y += number(note.originY)-board.virtualOrigin.y; }
      }
      result.x = Math.max(0, Math.min(board.width, number(result.x)));
      result.y = Math.max(0, Math.min(board.height, number(result.y)));
      return result;
    });
  });
}

// This toolbar operates on the original Sketch canvas. No HTML or snapshot is opened.
var NATIVE_DEV_KEY = 'measure.zh-modern.native-developer.v2';
var NATIVE_DEV_DOCUMENTS_KEY = NATIVE_DEV_KEY + '.documents';
function nativeDeveloperDocuments() {
  var dict=NSThread.mainThread().threadDictionary(),sessions=dict[NATIVE_DEV_DOCUMENTS_KEY];
  if(!sessions){sessions=NSMutableDictionary.dictionary();dict[NATIVE_DEV_DOCUMENTS_KEY]=sessions;}
  return sessions;
}
function nativeDeveloperSupports(object, selector) { return !!object && !!object.respondsToSelector(NSSelectorFromString(selector)); }
function nativeDeveloperRefresh(n) {
  if (nativeDeveloperSupports(n, 'performSelectionChangedUpdates')) n.performSelectionChangedUpdates();
  var canvas = n.contentDrawView();
  if (nativeDeveloperSupports(canvas, 'refreshSidebarWithMask:')) canvas.refreshSidebarWithMask(65535);
  if (nativeDeveloperSupports(n, 'updateScene')) n.updateScene();
  canvas.setNeedsDisplay(true);
}
function nativeDeveloperHit(d,x,y,deep) {
  var page=d.selectedPage.sketchObject,point=NSMakePoint(x,y),options=deep?2:0,hit;
  if(nativeDeveloperSupports(page,'hitTest:options:'))hit=page.hitTest_options(point,options);
  else {
    var canvas=d.sketchObject.contentDrawView(),zoom=nativeDeveloperSupports(canvas,'zoomValue')?Number(canvas.zoomValue()):1;
    hit=page.selectionHitTest_options_zoomValue(point,options,zoom);
  }
  return hit?sketch.fromNative(hit.layer()):null;
}
function nativeDeveloperLoadBundle(context) {
  devInitializeAvatar(context);
  // A matching revision may already be loaded from an installed or test copy.
  // Reuse it instead of registering the same Objective-C classes twice.
  var loaded=NSClassFromString('SMNativeDeveloperControllerV62');
  if(loaded)return loaded;
  var path = resource(context, 'NativeDeveloperV62.bundle');
  if (!NSFileManager.defaultManager().fileExistsAtPath(path)) throw new Error('缺少原生组件，请复制完整的 .sketchplugin 文件。');
  var bundle = NSBundle.bundleWithPath(path);
  if (!bundle) throw new Error('原生组件目录不完整，请重新安装。');
  var pointer = MOPointer.alloc().init();
  if (!bundle.loadAndReturnError(pointer)) {
    var reason = pointer.value();
    throw new Error('原生组件加载失败。' + (reason ? '\n' + String(reason.localizedDescription()) + '\n' + String(reason) : '请检查 macOS 版本和插件文件完整性。'));
  }
  var cls = NSClassFromString('SMNativeDeveloperControllerV62');
  if (!cls) throw new Error('原生组件不完整，找不到工具栏类。');
  return cls;
}
function nativeDeveloperState() { var c=NSThread.mainThread().threadDictionary()[NATIVE_DEV_KEY];if(c && Number(c.closed())){NSThread.mainThread().threadDictionary().removeObjectForKey(NATIVE_DEV_KEY);return null;}return c?{controller:c,document:sketch.fromNative(c.document())}:null; }
// Menu command and shortcut toggle the existing bar; preserve unsaved-comment confirmation.
function nativeDeveloperToggle(context) {
  var state=nativeDeveloperState();
  if(state){
    if(String(state.controller.className())!=='SMNativeDeveloperControllerV62')return nativeDeveloperOpen(context,false);
    nativeDeveloperCloseAll();return null;
  }
  return nativeDeveloperOpen(context,false);
}
function nativeDeveloperCloseAll() {
  var registered=nativeDeveloperDocuments().allValues(),controllers=[],i;
  for(i=0;i<Number(registered.count());i++)controllers.push(registered.objectAtIndex(i));
  var active=NSThread.mainThread().threadDictionary()[NATIVE_DEV_KEY];
  if(active&&!controllers.some(function(c){return c.isEqual(active);}))controllers.push(active);
  // Confirm every draft before closing any document's toolbar.
  for(i=0;i<controllers.length;i++)if(!controllers[i].canDiscardComment())return false;
  for(i=0;i<controllers.length;i++)controllers[i].shutdown();
  return true;
}
function nativeDeveloperFollow(context,controller) {
  var dict=NSThread.mainThread().threadDictionary(),active=dict[NATIVE_DEV_KEY];
  if(active && !active.isEqual(controller))return;
  var d=sketch.getSelectedDocument();
  if(!d || (active && String(sketch.fromNative(active.document()).id)===String(d.id)))return;
  nativeDeveloperOpen(context,active?Number(active.developer())!==0:false);
}
function nativeDeveloperRect(layer) {
  if(!nativeDeveloperSupports(layer.sketchObject,'alignmentRectInCoordinateSpace:'))throw new Error('当前 Sketch 缺少图层坐标接口。');
  var r=layer.sketchObject.alignmentRectInCoordinateSpace(layer.getParentPage().sketchObject);
  return {x:Number(r.origin.x),y:Number(r.origin.y),w:Number(r.size.width),h:Number(r.size.height)};
}
function nativeDeveloperPins(d) {
  return devNotes(d).map(function(note){
    var target=note.layerId && d.getLayerWithID(note.layerId),board=d.getLayerWithID(note.boardId.indexOf('page:')===0?note.boardId.slice(5):note.boardId);
    if(!board || (board.type==='Page'?board.id:board.getParentPage().id)!==d.selectedPage.id)return null;
    var br=board.type==='Page'?{x:0,y:0}:nativeDeveloperRect(board);
    var r=target?nativeDeveloperRect(target):br;
    return {id:note.id,x:target?r.x+r.w*number(note.u,.5):br.x+note.x,
      y:target?r.y+r.h*number(note.v,.5):br.y+note.y,initial:String(note.author||'注').slice(0,1),author:note.author,text:note.text,createdAt:note.createdAt,avatar:devSafeAvatar(note.avatar)};
  }).filter(function(n){return n;});
}
function nativeDeveloperSetCursorProfile(controller) {
  var profile=devProfile();
  controller.setCommentCursorAvatar_author(profile.avatar,profile.name);
  return JSON.stringify([profile.avatar,profile.name]);
}
function nativeDeveloperOpen(context,activate) {
  DELIVERY_PLUGIN_CONTEXT=context;
  devInitializeAvatar(context);
  var dict=NSThread.mainThread().threadDictionary(),state=nativeDeveloperState(),d=document(),sessions=nativeDeveloperDocuments();
  // A previously installed native class can remain alive until Sketch restarts.
  // Close it before registering the new controller, including its old callback.
  if(state&&String(state.controller.className())!=='SMNativeDeveloperControllerV62'){
    if(!nativeDeveloperCloseAll())return state;
    state=null;sessions=nativeDeveloperDocuments();
  }
  if(state && state.document.id===d.id){nativeDeveloperSetCursorProfile(state.controller);if(activate)state.controller.activate();return state;}
  var previous=state&&state.controller,existing=sessions.objectForKey(String(d.id));
  if(previous)previous.suspendForDocumentSwitch();
  if(existing && !Number(existing.closed())){nativeDeveloperSetCursorProfile(existing);dict[NATIVE_DEV_KEY]=existing;existing.tick();return {controller:existing,document:d};}
  var cls=nativeDeveloperLoadBundle(context),n=d.sketchObject;
  // Probe before calling private APIs; the version number alone is not a capability check.
  var compatibility=cls.compatibilityErrorForDocument(n);
  if(compatibility && String(compatibility).length)throw new Error(String(compatibility));
  var page=d.selectedPage && d.selectedPage.sketchObject;
  if(!nativeDeveloperSupports(page,'hitTest:options:')&&!nativeDeveloperSupports(page,'selectionHitTest:options:zoomValue:'))throw new Error('当前 Sketch 缺少图层命中接口，无法安全开启画布检查。');
  var canvas=n.contentDrawView();
  var controller=cls.alloc().initWithDocument(n);
  var lastCursorProfile=nativeDeveloperSetCursorProfile(controller);
  state={document:d,controller:controller};sessions.setObject_forKey(controller,String(d.id));dict[NATIVE_DEV_KEY]=controller;coscript.setShouldKeepAround(true);
  var lastPins='',lastSelection='';
  function refresh(){
    var cursorProfile=devProfile(),cursorKey=JSON.stringify([cursorProfile.avatar,cursorProfile.name]);
    if(cursorKey!==lastCursorProfile){controller.setCommentCursorAvatar_author(cursorProfile.avatar,cursorProfile.name);lastCursorProfile=cursorKey;}
    var pins=nativeDeveloperPins(d),p=JSON.stringify(pins);
    if(p!==lastPins){controller.setPins(pins);lastPins=p;}
    var selected=d.selectedLayers.layers.slice(0,2),rects=selected.map(nativeDeveloperRect),s=JSON.stringify(rects);
    if(s!==lastSelection){controller.setMeasureRects(rects);lastSelection=s;}
  }
  var desc=MOClassDescription.allocateDescriptionForClassWithName_superclass_('SMCanvasEvents'+String(NSUUID.UUID().UUIDString()).replace(/-/g,''),NSObject);
  desc.addInstanceMethodWithSelector_function_('developerEvent:',function(event){try{
    var raw=event;event={};['kind','id','layer','x','y','shift','deep','developer','op','text','author','boardId','layerId','u','v','replyId'].forEach(function(k){event[k]=raw.objectForKey(k);});var kind=String(event.kind);
    if(kind==='closed'){
      sessions.removeObjectForKey(String(d.id));
      if(dict[NATIVE_DEV_KEY]&&dict[NATIVE_DEV_KEY].isEqual(controller)){dict.removeObjectForKey(NATIVE_DEV_KEY);if(Number(sessions.count()))dict[NATIVE_DEV_KEY]=sessions.allValues().objectAtIndex(0);}
      if(!Number(sessions.count())){dict.removeObjectForKey(NATIVE_DEV_DOCUMENTS_KEY);coscript.setShouldKeepAround(false);}
      return;
    }
    if(kind==='requestClose'){nativeDeveloperCloseAll();return;}
    if(kind==='focus'){nativeDeveloperFollow(context,controller);return;}
    if(kind==='tick'){nativeDeveloperFollow(context,controller);refresh();return;}
    if(kind==='contextLayer'){
      var target=event.layer?sketch.fromNative(event.layer):nativeDeveloperHit(d,Number(event.x),Number(event.y),Number(event.deep)!==0);
      if(target&&d.selectedLayers.layers.every(function(layer){return layer.id!==target.id;})){d.selectedLayers.layers=[target];nativeDeveloperRefresh(n);refresh();}return;
    }
    if(kind==='mode'){nativeDeveloperRefresh(n);refresh();return;}
    if(kind==='mark'){if(!Number(controller.developer())){var actions={area:commandOverlays,width:commandWidths,height:commandHeights,spacing:commandSpacings,marginLeft:commandLeftMargins,marginRight:commandRightMargins,marginTop:commandTopMargins,marginBottom:commandBottomMargins,properties:commandProperties};var action=actions[String(event.id)];if(action){action();flushDocumentChanges(d);nativeDeveloperRefresh(n);}}return;}
    if(kind==='settings'){if(!Number(controller.developer()))commandSettings(context);refresh();return;}
    if(kind==='export'){if(!Number(controller.developer())){if(String(event.id)==='selected-board')commandExportSelectedBoard(context);else if(String(event.id)==='page')commandExport(context);else if(String(event.id)==='all')commandExportAllPages(context);}return;}
    if(kind==='moveComment'){
      if(Number(controller.developer()))return;
      var notes=devNotes(d),index=notes.map(function(note){return note.id;}).indexOf(String(event.id));
      if(index>=0){var anchor=nativeDeveloperAddDraft(d,Number(event.x),Number(event.y));['boardId','pageId','layerId','x','y','u','v'].forEach(function(key){notes[index][key]=anchor[key];});notes[index].updatedAt=new Date().toISOString();devStoreNotes(d,notes);flushDocumentChanges(d);refresh();}
      return;
    }
    if(kind==='addComment'){
      if(Number(controller.developer()))return;
      controller.showThreadJSON(JSON.stringify(nativeDeveloperAddDraft(d,Number(event.x),Number(event.y))));return;
    }
    if(kind==='saveComment'){
      if(Number(controller.developer()))return;
      try{var saved=nativeDeveloperSaveNote(d,event);if(saved){controller.showThreadJSON(JSON.stringify(devComposeProfile(saved)));}else controller.closeComment();refresh();UI.message('标注已更新，保存 Sketch 文档后即可随文件共享。');}catch(error){UI.message(String(error.message||error));}return;
    }
    if(kind==='comment'){
      var note=devNotes(d).filter(function(n){return n.id===String(event.id);})[0];
      if(note){controller.showThreadJSON(JSON.stringify(devComposeProfile(note)));}return;
    }
    var layer=null;
    if(kind==='select'){
      layer=nativeDeveloperHit(d,Number(event.x),Number(event.y),Number(event.deep)!==0);
    }else if(kind==='layer'){layer=sketch.fromNative(event.layer);}
    else if(kind==='page'){
      var page=sketch.fromNative(event.layer);if(page.type==='Page'){d.selectedPage=page;nativeDeveloperRefresh(n);refresh();}return;
    }
    if(kind==='select'||kind==='layer'){
      var existing=(Number(event.shift)!==0)?d.selectedLayers.layers.slice():[];
      if(layer){var index=existing.map(function(l){return l.id;}).indexOf(layer.id);if(index>=0)existing.splice(index,1);else existing.push(layer);}
      d.selectedLayers.layers=existing;
      nativeDeveloperRefresh(n);
      refresh();
    }
  }catch(error){console.error('Native developer: '+String(error.stack||error));}});
  desc.registerClass();controller.setEventDelegate(NSClassFromString(desc.name()).alloc().init());
  try { refresh();if(activate)controller.activate();return state; }
  catch(error){controller.shutdown();if(previous&&!Number(previous.closed()))dict[NATIVE_DEV_KEY]=previous;throw error;}
}
function commandDeveloperToolbar(context) {run(function(){nativeDeveloperOpen(context,false);});}
function nativeDeveloperAddDraft(d,x,y){
  var layer=nativeDeveloperHit(d,x,y,true);
  var b=layer;while(b && b.type!=='Page' && !isBoard(b))b=b.parent;
  if(b && b.type!=='Page'){var ancestor=b.parent;while(ancestor && ancestor.type!=='Page'){if(isBoard(ancestor))b=ancestor;ancestor=ancestor.parent;}}
  var boardId=b&&isBoard(b)?String(b.id):'page:'+String(d.selectedPage.id),br=b&&isBoard(b)?nativeDeveloperRect(b):{x:0,y:0};
  var r=layer?nativeDeveloperRect(layer):null;
  return {boardId:boardId,pageId:String(d.selectedPage.id),layerId:layer?String(layer.id):'',x:x-br.x,y:y-br.y,u:r&&r.w?(x-r.x)/r.w:.5,v:r&&r.h?(y-r.y)/r.h:.5,
    pageX:x,pageY:y,author:devProfile().name,avatar:devProfile().avatar,composerAuthor:devProfile().name,composerAvatar:devProfile().avatar,text:''};
}
function nativeDeveloperSaveNote(d,payload){
  var notes=devNotes(d),op=String(payload.op),index=notes.map(function(n){return n.id;}).indexOf(String(payload.id||''));
  if(['add','update','delete','reply','updateReply','deleteReply'].indexOf(op)<0)throw new Error('无效的注释操作。');
  if(op!=='add'&&index<0)throw new Error('这条标注已经被删除。请关闭标注窗口，选择其他标注后再操作。');
  if(op==='delete')notes.splice(index,1);
  else{
    var replyIndex=-1;
    if(op==='updateReply'||op==='deleteReply'){replyIndex=(notes[index].replies||[]).map(function(r){return r.id;}).indexOf(String(payload.replyId));if(replyIndex<0)throw new Error('这条回复已经被删除。请重新打开标注，查看最新内容。');}
    if(op==='deleteReply'){notes[index].replies.splice(replyIndex,1);notes[index].updatedAt=new Date().toISOString();devStoreNotes(d,notes);flushDocumentChanges(d);return notes[index];}
    var author=String(payload.author||'').trim(),text=String(payload.text||'').trim();
    if(!author||author.length>80)throw new Error(!author?'请填写标注名字，方便同事识别你的标注。':'标注名字超过了 80 个字，请缩短后再保存。');
    if(!text||text.length>10000)throw new Error(!text?'请先填写标注内容，再点击保存。':'标注内容超过了 10000 个字，请精简或分成多条标注后保存。');
    var now=new Date().toISOString();
    if(op==='reply'||op==='updateReply'){
      if(!notes[index].replies)notes[index].replies=[];
      if(op==='reply'){if(notes[index].replies.length>=500)throw new Error('这条标注已有 500 条回复，无法继续追加。可以新建一条标注继续讨论。');notes[index].replies.push({id:String(NSUUID.UUID().UUIDString()),author:author,avatar:devProfile().avatar,text:text,createdAt:now,updatedAt:now});}
      else{notes[index].replies[replyIndex].author=author;notes[index].replies[replyIndex].text=text;notes[index].replies[replyIndex].updatedAt=now;}
      notes[index].updatedAt=now;
    }
    else if(op==='update'){notes[index].author=author;notes[index].text=text;notes[index].updatedAt=now;}
    else{
      if(notes.length>=5000)throw new Error('当前文档已有 5000 条标注，无法继续添加。可以整理不再需要的标注，或在另一份文档中继续。');
      var boardId=String(payload.boardId||''),board=d.getLayerWithID(boardId.indexOf('page:')===0?boardId.slice(5):boardId);
      if(!board||!isFinite(Number(payload.x))||!isFinite(Number(payload.y)))throw new Error('暂时无法确定标注位置。请关闭标注窗口，在画布上重新点击需要标注的位置。');
      notes.push({id:String(NSUUID.UUID().UUIDString()),boardId:boardId,pageId:String((board.type==='Page'?board:board.getParentPage()).id),layerId:String(payload.layerId||''),x:Number(payload.x),y:Number(payload.y),u:Number(payload.u),v:Number(payload.v),author:author,avatar:devProfile().avatar,text:text,createdAt:now,updatedAt:now,resolved:false});
    }
    Settings.setSettingForKey('measure.zh-modern.note-author',author);
  }
  devStoreNotes(d,notes);flushDocumentChanges(d);return op==='delete'?null:notes[op==='add'?notes.length-1:index];
}
