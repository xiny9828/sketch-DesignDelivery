(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.SMProjectCodec = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  function encode(project) {
    var images = [], ids = new Map();
    // The image table is serialized after the project has populated it.
    return JSON.stringify({version:1, project:project, images:images}, function (key, value) {
      if ((key !== 'svgSource' && key !== 'labAssetSource') || typeof value !== 'string') return value;
      // This is lossless transport tokenization, not SVG rewriting. Every byte
      // outside a shared image token stays in order, including whitespace.
      var re = /data:image\/[a-zA-Z0-9.+-]+;base64,[A-Za-z0-9+/=\r\n]+/g;
      var parts = [], position = 0, match;
      while ((match = re.exec(value))) {
        parts.push(value.slice(position, match.index));
        if (!ids.has(match[0])) { ids.set(match[0], images.length); images.push(match[0]); }
        parts.push(ids.get(match[0])); position = re.lastIndex;
      }
      if (!parts.length) return value;
      parts.push(value.slice(position));
      return {pieces:parts};
    });
  }
  function decode(packet) {
    if (!packet || packet.version !== 1 || !Array.isArray(packet.images)) throw Error('交付数据格式无效');
    function restore(object, key) {
      var value = object[key];
      if (!value || typeof value === 'string') return;
      if (!Array.isArray(value.pieces)) throw Error('切图资源数据无效');
      object[key] = value.pieces.map(function (part) {
        if (typeof part === 'string') return part;
        if (!Number.isInteger(part) || typeof packet.images[part] !== 'string') throw Error('切图资源引用缺失');
        return packet.images[part];
      }).join('');
    }
    packet.project.artboards.forEach(function (board) {
      restore(board, 'svgSource');
      board.layers.forEach(function (layer) { restore(layer, 'labAssetSource'); });
    });
    return packet.project;
  }
  async function load(base64) {
    var binary = atob(base64), bytes = new Uint8Array(binary.length);
    for (var i=0; i<binary.length; i++) bytes[i] = binary.charCodeAt(i);
    if (typeof DecompressionStream === 'function') {
      var stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));
      return decode(await new Response(stream).json());
    }
    return decode(JSON.parse(fflate.strFromU8(fflate.gunzipSync(bytes))));
  }
  return {encode:encode, decode:decode, load:load};
});
