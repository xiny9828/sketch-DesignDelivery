/* Browser-only SVG extraction. Shared definitions are retained once per asset. */
(function (global) {
  'use strict';
  var ns = 'http://www.w3.org/2000/svg';
  function parse(source) {
    var doc = new DOMParser().parseFromString(source, 'image/svg+xml');
    if (doc.querySelector('parsererror') || doc.documentElement.localName !== 'svg') throw Error('SVG 结构无效');
    if (doc.querySelector('script,foreignObject,animate,animateTransform,set')) throw Error('SVG 含不支持的活动内容');
    function checkURLs(value) {
      if (/@import/i.test(value)) throw Error('SVG 含外部样式');
      var re=/url\(\s*(["']?)(.*?)\1\s*\)/gi, match;
      while ((match=re.exec(value))) if (!/^#[^\s]+$/.test(match[2].trim())) throw Error('SVG 含外部资源，不能保证离线一致性');
    }
    Array.from(doc.querySelectorAll('*')).forEach(function (el) {
      if (el.localName === 'style') checkURLs(el.textContent);
      Array.from(el.attributes).forEach(function (a) {
        if (/^on/i.test(a.name)) throw Error('SVG 含活动事件');
        if (a.localName === 'href' && a.value && !/^(#|data:image\/(?:png|jpeg|webp|gif);base64,)/i.test(a.value)) throw Error('SVG 含外部资源，不能保证离线一致性');
        checkURLs(a.value);
      });
    });
    return doc;
  }
  function unique(doc, id) {
    var nodes = Array.from(doc.querySelectorAll('[id]')).filter(function (n) { return n.id === id; });
    if (nodes.length !== 1) throw Error(nodes.length ? 'SVG 图层标识重复，已阻止错误切图' : '此图层未映射到独立 SVG 节点');
    return nodes[0];
  }
  // Parsed source trees stay private and immutable; returned assets are clones.
  var sourceCache = new Map(), sourceCacheSize = 0;
  function cachedSource(source) {
    var entry = sourceCache.get(source);
    if (entry) { sourceCache.delete(source); sourceCache.set(source, entry); return entry; }
    var doc = parse(source), ids = new Map();
    doc.querySelectorAll('[id]').forEach(function (node) {
      ids.set(node.id, ids.has(node.id) ? null : node);
    });
    entry = {doc:doc, ids:ids};
    if (source.length <= 8000000) {
      while (sourceCache.size && (sourceCache.size >= 4 || sourceCacheSize + source.length > 8000000)) {
        var oldest = sourceCache.keys().next().value;
        sourceCacheSize -= oldest.length; sourceCache.delete(oldest);
      }
      sourceCache.set(source, entry); sourceCacheSize += source.length;
    }
    return entry;
  }
  function indexedNode(entry, id) {
    if (!entry.ids.has(id)) throw Error('此图层未映射到独立 SVG 节点');
    var node = entry.ids.get(id);
    if (!node) throw Error('SVG 图层标识重复，已阻止错误切图');
    return node;
  }
  function prepare(source, id) {
    var entry = cachedSource(source), doc = entry.doc, target = indexedNode(entry, id), root = doc.documentElement;
    var result = root.cloneNode(false), definitions = doc.createElementNS(ns, 'defs');
    result.appendChild(definitions);
    // Resolve only referenced definitions, not unrelated board bitmap payloads.
    root.querySelectorAll('style').forEach(function (n) { result.appendChild(n.cloneNode(true)); });
    var branch = target.cloneNode(true);
    for (var parent = target.parentElement; parent && parent !== root; parent = parent.parentElement) {
      var shell = parent.cloneNode(false);
      // Sketch exports the selected subtree, not its ancestors' shadows,
      // opacity or masks. Keep geometric transforms and inherited paint only.
      ['filter','mask','clip-path','opacity','fill-opacity','stroke-opacity'].forEach(function(name){shell.removeAttribute(name)});
      ['filter','mix-blend-mode','mask','clip-path','opacity','fill-opacity','stroke-opacity'].forEach(function(name){shell.style.removeProperty(name)});
      shell.appendChild(branch); branch = shell;
    }
    result.appendChild(branch);
    var complete = new Set(Array.from(result.querySelectorAll('[id]')).map(function (n) { return n.id; }));
    for (var pass = 0; pass < 64; pass++) {
      var missing = new Set();
      result.querySelectorAll('*').forEach(function (el) { Array.from(el.attributes).forEach(function (a) {
        if (a.localName === 'href' && a.value[0] === '#' && !complete.has(a.value.slice(1))) missing.add(a.value.slice(1));
        var re = /url\(["']?#([^)"']+)["']?\)/g, m;
        while ((m = re.exec(a.value))) if (!complete.has(m[1])) missing.add(m[1]);
      }); });
      if (!missing.size) break;
      missing.forEach(function (key) {
        var dependency = indexedNode(entry, key).cloneNode(true);
        definitions.appendChild(dependency); complete.add(key);
        dependency.querySelectorAll('[id]').forEach(function (n) { complete.add(n.id); });
      });
      if (pass === 63) throw Error('SVG 依赖过深');
    }
    return result;
  }
  var checkedFonts = new Map();
  async function fonts(root) {
    for (var node of root.querySelectorAll('text')) {
      var family = node.getAttribute('font-family');
      for (var p=node.parentElement; !family && p; p=p.parentElement) family=p.getAttribute('font-family');
      if (!family) throw Error('SVG 文字缺少字体信息');
      if (!checkedFonts.has(family)) checkedFonts.set(family, (async function (value) {
        for (var name of value.split(',').map(function (s) { return s.trim().replace(/^["']|["']$/g, ''); })) {
          try { var face = new FontFace('lab-check-' + checkedFonts.size, 'local(' + JSON.stringify(name) + ')'); await face.load(); return; }
          catch (_) {}
        }
        throw Error('本机缺少 SVG 字体：' + value);
      })(family));
      await checkedFonts.get(family);
    }
  }
  function union(a,b) {
    if (!a) return b;
    var x=Math.min(a.x,b.x),y=Math.min(a.y,b.y);
    return {x:x,y:y,width:Math.max(a.x+a.width,b.x+b.width)-x,height:Math.max(a.y+a.height,b.y+b.height)-y};
  }
  function transformed(r,m) {
    var points=[[r.x,r.y],[r.x+r.width,r.y],[r.x,r.y+r.height],[r.x+r.width,r.y+r.height]].map(function(p){return{x:m.a*p[0]+m.c*p[1]+m.e,y:m.b*p[0]+m.d*p[1]+m.f};});
    var xs=points.map(function(p){return p.x}),ys=points.map(function(p){return p.y}),x=Math.min.apply(Math,xs),y=Math.min.apply(Math,ys);
    return{x:x,y:y,width:Math.max.apply(Math,xs)-x,height:Math.max.apply(Math,ys)-y};
  }
  function bounds(root,id) {
    var holder=document.createElement('div'); holder.style.cssText='position:fixed;left:-100000px;top:0;visibility:hidden;pointer-events:none';
    var view = (root.getAttribute('viewBox') || '').split(/[ ,]+/).map(Number);
    root.setAttribute('width',view[2]);root.setAttribute('height',view[3]);
    holder.appendChild(root);document.body.appendChild(holder);
    try {
      var target=unique(root,id), box=transformed(target.getBBox(),target.getCTM());
      [target].concat(Array.from(target.querySelectorAll('*'))).forEach(function(node){
        if(!node.getBBox || node.closest('defs')) return;
        var r;try{r=node.getBBox()}catch(_){return}
        var stroke=Number.parseFloat(getComputedStyle(node).strokeWidth)||0;
        if(getComputedStyle(node).stroke!=='none')box=union(box,transformed({x:r.x-stroke,y:r.y-stroke,width:r.width+2*stroke,height:r.height+2*stroke},node.getCTM()));
        var match=/url\(["']?#([^)"']+)/.exec(node.getAttribute('filter')||'');
        if(match){
          var f=unique(root,match[1]);
          if(f.getAttribute('filterUnits')==='userSpaceOnUse') throw Error('此效果使用绝对滤镜边界，暂不支持自动裁切');
          function value(key,fallback,size,origin){var v=f.getAttribute(key)||fallback;return origin+(v.indexOf('%')>=0?parseFloat(v)/100:parseFloat(v))*size;}
          box=union(box,transformed({x:value('x','-10%',r.width,r.x),y:value('y','-10%',r.height,r.y),
            width:value('width','120%',r.width,0),height:value('height','120%',r.height,0)},node.getCTM()));
        }
      });
      var x=Math.floor(box.x*100)/100,y=Math.floor(box.y*100)/100;
      box={x:x,y:y,width:Math.ceil((box.x+box.width-x)*100)/100,height:Math.ceil((box.y+box.height-y)*100)/100};
      if(!Object.values(box).every(Number.isFinite)||box.width<=0||box.height<=0)throw Error('图层没有可下载的可见内容');
      return box;
    } finally {holder.remove();}
  }
  async function asset(source,id,options) {
    options=options||{};
    var root=id?prepare(source,id):cachedSource(source).doc.documentElement.cloneNode(true);await fonts(root);
    var view=(root.getAttribute('viewBox')||'').trim().split(/[ ,]+/).map(Number);
    var box=id?bounds(root,id):{x:view[0]||0,y:view[1]||0,width:view.length===4?view[2]:parseFloat(root.getAttribute('width')),height:view.length===4?view[3]:parseFloat(root.getAttribute('height'))};
    if(id&&options.frame&&Object.values(options.frame).every(Number.isFinite))box=union(box,options.frame);
    if(!Object.values(box).every(Number.isFinite)||box.width<=0||box.height<=0)throw Error('切图尺寸无效');
    var scale=Number(options.scale||1), designScale=Number(options.designScale||1);
    if(!(scale>0&&designScale>0))throw Error('倍率无效');
    var width=Math.max(1,Math.round(box.width/designScale*scale)),height=Math.max(1,Math.round(box.height/designScale*scale));
    if(width>16384||height>16384||width*height>64000000)throw Error('切图尺寸过大，请降低倍率');
    root.setAttribute('viewBox',[box.x,box.y,box.width,box.height].join(' '));root.setAttribute('width',width);root.setAttribute('height',height);
    var text=!!root.querySelector('text'),bitmap=!!root.querySelector('image');
    return {source:new XMLSerializer().serializeToString(root),box:box,width:width,height:height,text:text,bitmap:bitmap};
  }
  async function blob(asset,format,background,allowText) {
    if(!['svg','png','jpg'].includes(format))throw Error('不支持的格式');
    if(format==='svg'&&asset.text&&!allowText)throw Error('SVG 含文字，需确认字体依赖后才能下载');
    var svg=new Blob([asset.source],{type:'image/svg+xml;charset=utf-8'});
    if(format==='svg')return svg;
    var url=URL.createObjectURL(svg);
    try {
      var img=new Image();img.src=url;await img.decode();
      var canvas=document.createElement('canvas');canvas.width=asset.width;canvas.height=asset.height;
      var ctx=canvas.getContext('2d');if(!ctx)throw Error('无法创建图像');
      if(format==='jpg'){ctx.fillStyle=background||'#ffffff';ctx.fillRect(0,0,canvas.width,canvas.height);}
      ctx.drawImage(img,0,0);
      return await new Promise(function(resolve,reject){canvas.toBlob(function(result){if(result)resolve(result);else reject(Error('图像编码失败'));},format==='jpg'?'image/jpeg':'image/png',1);});
    } finally {URL.revokeObjectURL(url);}
  }
  global.SVGLab={parse:parse,prepare:prepare,asset:asset,blob:blob};
})(window);
