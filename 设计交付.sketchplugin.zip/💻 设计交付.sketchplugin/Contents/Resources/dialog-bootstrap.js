// The standalone bootstrap also handles errors before the main runtime loads.
var DELIVERY_PLUGIN_CONTEXT = null;
// Carry a useful title with expected validation errors; retain Error.message
// for logs and callers without coupling the UI to string matching.
function deliveryError(title, message) {
  var error=new Error(message);error.deliveryTitle=title;return error;
}
function deliveryShowError(error, title, pluginContext) {
  var message=String(error.message||error);
  if(!error.deliveryTitle){
    if(title==='暂时无法完成导出')message+='\n\n请检查设计稿和保存位置后重试。如果仍然失败，请保留导出文件夹中的“导出未完成.txt”，方便排查。';
    else if(!/请|可以|重试/.test(message))message+='\n\n请重试此操作。如果仍然出现此提示，请将提示内容反馈给插件作者。';
  }
  return deliveryAlert(error.deliveryTitle||title||'暂时无法完成操作',message,['知道了'],0,pluginContext);
}
function deliveryAlert(title, message, buttons, primary, pluginContext) {
  buttons=buttons&&buttons.length?buttons:['知道了'];primary=primary||0;
  var presentation=deliveryDialogPresentation(message,buttons);title=presentation.title;message=presentation.message;
  try {
    var cls=NSClassFromString('SMDeliveryAlertControllerV62'),ctx=pluginContext||DELIVERY_PLUGIN_CONTEXT;
    if(!cls&&ctx){
      var url=ctx.plugin.urlForResourceNamed('NativeDeveloperV62.bundle');
      if(url){var bundle=NSBundle.bundleWithPath(String(url.path()));if(bundle)bundle.load();}
      cls=NSClassFromString('SMDeliveryAlertControllerV62');
    }
    if(cls){var parent=NSApp.modalWindow()||NSApp.keyWindow();return Number(cls.showJSON_forWindow(JSON.stringify({title:String(title),message:String(message||''),buttons:buttons,primary:primary}),parent))-1000;}
  } catch(error){console.error('提示组件加载失败：'+String(error));}
  // Keep an OS fallback when the native component itself is missing or corrupt.
  return deliverySystemAlert(title,message,buttons,primary);
}

// NSAlert lays out its first button on the right. Preserve logical result
// indices while placing cancellation on the left, including OS fallback UI.
function deliveryDialogPresentation(message,buttons) {
  var confirmation=(buttons||[]).some(function(label){return /^(删除|放弃|delete|discard)/i.test(String(label));});
  return {title:confirmation?'操作确认':'提示',message:String(message||'').replace(/[。．.]+(?=[ \t]*(?:\r?\n|$))/g,'')};
}
function deliverySystemAlert(title,message,buttons,primary) {
  buttons=buttons&&buttons.length?buttons:['知道了'];primary=Math.max(0,Math.min(buttons.length-1,Number(primary)||0));
  var presentation=deliveryDialogPresentation(message,buttons);title=presentation.title;message=presentation.message;
  var cancel=-1,order=[];
  buttons.some(function(label,index){if(/^(取消.*|关闭|继续编辑|cancel|close)$/i.test(String(label))){cancel=index;return true;}return false;});
  if(primary===cancel&&buttons.length>1){for(var i=buttons.length-1;i>=0;i--)if(i!==cancel){primary=i;break;}}
  if(cancel>=0)order.push(cancel);
  buttons.forEach(function(label,index){if(index!==cancel&&index!==primary)order.push(index);});
  if(primary!==cancel)order.push(primary);
  order.reverse();
  var fallback=NSAlert.alloc().init();fallback.setMessageText(String(title));fallback.setInformativeText(String(message||''));
  order.forEach(function(index){var button=fallback.addButtonWithTitle(String(buttons[index]));if(index===primary){button.setKeyEquivalent('\r');button.setKeyEquivalentModifierMask(0);fallback.window().setDefaultButtonCell(button.cell());}else button.setKeyEquivalent('');if(index===cancel){if(index!==primary)button.setKeyEquivalent('\u001b');button.setKeyEquivalentModifierMask(0);}});
  var result=Number(fallback.runModal())-1000;
  return result>=0&&result<order.length?order[result]:(cancel>=0?cancel:primary);
}
