// All toolbar icons are generated from the latest supplied SVGs.
// A common 128-unit canvas renders at 22 pt; 10-unit primary outlines render at 1.71875 pt.
// Paths, padding, transforms, masks and original red details are preserved.
static NSImage *SMProvidedToolbarIcon(NSString *name, NSColor *color) {
 if (![@[@"cursorarrow",@"hand.draw",@"bubble.left",@"pencil",@"chevron.left.forwardslash.chevron.right",@"width",@"height",@"spacing",@"marginLeft",@"marginRight",@"marginTop",@"marginBottom",@"properties",@"export",@"settings",@"area",@"xmark"] containsObject:name]) return nil;
 return [NSImage imageWithSize:NSMakeSize(24,24) flipped:YES drawingHandler:^BOOL(NSRect rect) {
 [NSGraphicsContext saveGraphicsState];
 CGContextRef cg=NSGraphicsContext.currentContext.CGContext;CGContextScaleCTM(cg,24.0/128.0,24.0/128.0);
 [[NSBezierPath bezierPathWithRect:NSMakeRect(0,0,128,128)] addClip];
 if ([name isEqualToString:@"cursorarrow"]) { // 鼠标.svg
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(21.6317556,19.055996)];
[p lineToPoint:NSMakePoint(21.9574684,19.1497583)];
[p lineToPoint:NSMakePoint(111.596151,52.2928285)];
[p curveToPoint:NSMakePoint(111.508343,56.3888619) controlPoint1:NSMakePoint(113.503911,52.9982049) controlPoint2:NSMakePoint(113.459989,55.7277414)];
[p lineToPoint:NSMakePoint(76.0421035,68.4030581)];
[p curveToPoint:NSMakePoint(68.4030581,76.0421035) controlPoint1:NSMakePoint(72.4460173,69.621233) controlPoint2:NSMakePoint(69.621233,72.4460173)];
[p lineToPoint:NSMakePoint(56.3888619,111.508343)];
[p curveToPoint:NSMakePoint(52.2928285,111.596151) controlPoint1:NSMakePoint(55.7277414,113.459989) controlPoint2:NSMakePoint(52.9982049,113.503911)];
[p lineToPoint:NSMakePoint(19.1497583,21.9574684)];
[p curveToPoint:NSMakePoint(21.6317556,19.055996) controlPoint1:NSMakePoint(18.5458598,20.3241658) controlPoint2:NSMakePoint(20.0107637,18.7194368)];
[p closePath];
p.windingRule=NSWindingRuleNonZero;
[color setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleButt;p.lineJoinStyle=NSLineJoinStyleMiter;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
 }
 if ([name isEqualToString:@"hand.draw"]) { // 移动.svg
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
CGContextTranslateCTM(cg,64,64);
CGContextScaleCTM(cg,-1,1);
CGContextTranslateCTM(cg,-64,-64);
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(54.7083581,25.1071426)];
[p curveToPoint:NSMakePoint(50.8698134,17.9624328) controlPoint1:NSMakePoint(54.7083581,22.1597015) controlPoint2:NSMakePoint(53.2451132,19.4361535)];
[p curveToPoint:NSMakePoint(43.1927237,17.9624328) controlPoint1:NSMakePoint(48.4945136,16.4887122) controlPoint2:NSMakePoint(45.5680235,16.4887122)];
[p curveToPoint:NSMakePoint(39.354179,25.1071426) controlPoint1:NSMakePoint(40.8174239,19.4361535) controlPoint2:NSMakePoint(39.354179,22.1597015)];
[p lineToPoint:NSMakePoint(39.354179,40.8214284)];
[p moveToPoint:NSMakePoint(54.7083581,25.1071426)];
[p lineToPoint:NSMakePoint(54.7083581,17.2499998)];
[p curveToPoint:NSMakePoint(62.3854476,9) controlPoint1:NSMakePoint(54.7083581,12.6936507) controlPoint2:NSMakePoint(58.1455082,9)];
[p curveToPoint:NSMakePoint(70.0625371,17.2499998) controlPoint1:NSMakePoint(66.625387,9) controlPoint2:NSMakePoint(70.0625371,12.6936507)];
[p lineToPoint:NSMakePoint(70.0625371,25.1071426)];
[p moveToPoint:NSMakePoint(54.7083581,25.1071426)];
[p lineToPoint:NSMakePoint(55.0739338,56.142857)];
[p moveToPoint:NSMakePoint(70.0625371,60.0714284)];
[p lineToPoint:NSMakePoint(70.0625371,25.1071426)];
[p moveToPoint:NSMakePoint(70.0625371,25.1071426)];
[p curveToPoint:NSMakePoint(77.7396267,16.8571426) controlPoint1:NSMakePoint(70.0625371,20.5507935) controlPoint2:NSMakePoint(73.4996872,16.8571426)];
[p curveToPoint:NSMakePoint(85.4167162,25.1071426) controlPoint1:NSMakePoint(81.9795661,16.8571426) controlPoint2:NSMakePoint(85.4167162,20.5507935)];
[p lineToPoint:NSMakePoint(85.4167162,79.7142856)];
[p moveToPoint:NSMakePoint(39.354179,40.8214284)];
[p curveToPoint:NSMakePoint(31.6770895,32.5714284) controlPoint1:NSMakePoint(39.354179,36.2650792) controlPoint2:NSMakePoint(35.917029,32.5714284)];
[p curveToPoint:NSMakePoint(24,40.8214284) controlPoint1:NSMakePoint(27.4371501,32.5714284) controlPoint2:NSMakePoint(24,36.2650792)];
[p lineToPoint:NSMakePoint(24,83.6428571)];
[p curveToPoint:NSMakePoint(56.9018122,119) controlPoint1:NSMakePoint(24,103.170068) controlPoint2:NSMakePoint(38.7306431,119)];
[p lineToPoint:NSMakePoint(66.7382355,119)];
[p curveToPoint:NSMakePoint(84.8317951,110.94381) controlPoint1:NSMakePoint(73.5248973,119) controlPoint2:NSMakePoint(80.033302,116.101258)];
[p lineToPoint:NSMakePoint(93.2741564,101.871429)];
[p curveToPoint:NSMakePoint(100.770895,82.427619) controlPoint1:NSMakePoint(98.0734525,96.7148431) controlPoint2:NSMakePoint(100.770092,89.7207422)];
[p lineToPoint:NSMakePoint(100.785518,71.8257142)];
[p curveToPoint:NSMakePoint(101.750638,69.3585713) controlPoint1:NSMakePoint(100.791354,70.8986244) controlPoint2:NSMakePoint(101.138317,70.0116791)];
[p curveToPoint:NSMakePoint(103.738163,61.3874878) controlPoint1:NSMakePoint(103.690597,67.2738415) controlPoint2:NSMakePoint(104.448237,64.2352817)];
[p curveToPoint:NSMakePoint(98.3081449,55.5522496) controlPoint1:NSMakePoint(103.028088,58.5396939) controlPoint2:NSMakePoint(100.958177,56.3153137)];
[p curveToPoint:NSMakePoint(90.8906029,57.6880951) controlPoint1:NSMakePoint(95.6581124,54.7891856) controlPoint2:NSMakePoint(92.8305613,55.6033653)];
[p curveToPoint:NSMakePoint(85.4313392,71.762857) controlPoint1:NSMakePoint(87.4134732,61.4214503) controlPoint2:NSMakePoint(85.4510595,66.4808332)];
[p moveToPoint:NSMakePoint(39.354179,40.8214284)];
[p lineToPoint:NSMakePoint(39.354179,63.9999999)];
[p moveToPoint:NSMakePoint(69.9163069,86.6180952)];
[p curveToPoint:NSMakePoint(85.4167162,79.7142856) controlPoint1:NSMakePoint(74.0274811,82.2001733) controlPoint2:NSMakePoint(79.6026731,79.717009)];
p.windingRule=NSWindingRuleNonZero;
[color setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleRound;p.lineJoinStyle=NSLineJoinStyleRound;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
 }
 if ([name isEqualToString:@"bubble.left"]) { // 标注.svg
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(114,64)];
[p curveToPoint:NSMakePoint(64,114) controlPoint1:NSMakePoint(114,91.6139763) controlPoint2:NSMakePoint(91.6139763,114)];
[p curveToPoint:NSMakePoint(41.7407514,108.785255) controlPoint1:NSMakePoint(56.1630968,114) controlPoint2:NSMakePoint(48.594378,112.199187)];
[p curveToPoint:NSMakePoint(31.9041575,107.69589) controlPoint1:NSMakePoint(38.6595695,107.251235) controlPoint2:NSMakePoint(35.1778183,106.819883)];
[p lineToPoint:NSMakePoint(19.6610823,110.971652)];
[p curveToPoint:NSMakePoint(17.0283828,108.339269) controlPoint1:NSMakePoint(18.0628944,111.399174) controlPoint2:NSMakePoint(16.6008231,109.937161)];
[p lineToPoint:NSMakePoint(20.3042617,96.0956305)];
[p curveToPoint:NSMakePoint(19.2145272,86.2594173) controlPoint1:NSMakePoint(21.1802996,92.8218762) controlPoint2:NSMakePoint(20.7488043,89.3395555)];
[p curveToPoint:NSMakePoint(14,64) controlPoint1:NSMakePoint(15.8007688,79.4052176) controlPoint2:NSMakePoint(14,71.8365777)];
[p curveToPoint:NSMakePoint(64,14) controlPoint1:NSMakePoint(14,36.3857487) controlPoint2:NSMakePoint(36.3857487,14)];
[p curveToPoint:NSMakePoint(114,64) controlPoint1:NSMakePoint(91.6140751,14) controlPoint2:NSMakePoint(114,36.3858476)];
[p closePath];
p.windingRule=NSWindingRuleNonZero;
[color setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleButt;p.lineJoinStyle=NSLineJoinStyleMiter;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(43,51.5)];
[p lineToPoint:NSMakePoint(85,51.5)];
p.windingRule=NSWindingRuleNonZero;
[color setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleRound;p.lineJoinStyle=NSLineJoinStyleMiter;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(43,76.5001)];
[p lineToPoint:NSMakePoint(73,76.5001)];
p.windingRule=NSWindingRuleNonZero;
[color setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleRound;p.lineJoinStyle=NSLineJoinStyleMiter;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
 }
 if ([name isEqualToString:@"pencil"]) { // 设计.svg
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
CGContextTranslateCTM(cg,16,11.2533);
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(26.1495082,30.8940317)];
[p lineToPoint:NSMakePoint(41.1795331,45.9251862)];
[p moveToPoint:NSMakePoint(3.20947003,14.442768)];
[p lineToPoint:NSMakePoint(16.2886934,60.2284904)];
[p lineToPoint:NSMakePoint(16.2909166,60.2362712)];
[p curveToPoint:NSMakePoint(45.073261,83.2330313) controlPoint1:NSMakePoint(20.1788035,73.8379883) controlPoint2:NSMakePoint(30.937834,83.2170107)];
[p curveToPoint:NSMakePoint(45.1531781,83.2329007) controlPoint1:NSMakePoint(45.0999001,83.2330615) controlPoint2:NSMakePoint(45.1265392,83.2330137)];
[p curveToPoint:NSMakePoint(51.4024216,82.4993456) controlPoint1:NSMakePoint(47.257185,83.2239742) controlPoint2:NSMakePoint(49.3534999,82.9779062)];
[p curveToPoint:NSMakePoint(51.5404757,82.4685122) controlPoint1:NSMakePoint(51.4483391,82.4886208) controlPoint2:NSMakePoint(51.4943461,82.4782846)];
[p curveToPoint:NSMakePoint(51.6906292,82.4384919) controlPoint1:NSMakePoint(51.5904507,82.4579251) controlPoint2:NSMakePoint(51.6405063,82.4479179)];
[p curveToPoint:NSMakePoint(57.1277676,84.1213281) controlPoint1:NSMakePoint(53.6698358,82.0662887) controlPoint2:NSMakePoint(55.7037787,82.6972321)];
[p lineToPoint:NSMakePoint(69.2145797,96.2090486)];
[p curveToPoint:NSMakePoint(75.8160555,96.8817565) controlPoint1:NSMakePoint(71.0083327,98.0029364) controlPoint2:NSMakePoint(73.7782592,98.2271723)];
[p curveToPoint:NSMakePoint(76.6432102,96.2054289) controlPoint1:NSMakePoint(76.1140092,96.6850383) controlPoint2:NSMakePoint(76.3908,96.4579433)];
[p lineToPoint:NSMakePoint(91.4559985,81.3865294)];
[p lineToPoint:NSMakePoint(91.4603389,81.3821884)];
[p curveToPoint:NSMakePoint(93,77.6676244) controlPoint1:NSMakePoint(92.4461011,80.3973976) controlPoint2:NSMakePoint(93,79.0610962)];
[p curveToPoint:NSMakePoint(91.4603389,73.9530604) controlPoint1:NSMakePoint(93,76.2741526) controlPoint2:NSMakePoint(92.4461011,74.9378511)];
[p lineToPoint:NSMakePoint(91.4566199,73.9493419)];
[p lineToPoint:NSMakePoint(79.1845963,61.6763961)];
[p curveToPoint:NSMakePoint(77.7645939,56.2059759) controlPoint1:NSMakePoint(77.7645939,60.256287) controlPoint2:NSMakePoint(77.3195932,58.1611261)];
[p curveToPoint:NSMakePoint(78.4894255,49.8996465) controlPoint1:NSMakePoint(78.2380029,54.140036) controlPoint2:NSMakePoint(78.4796134,52.0379262)];
[p curveToPoint:NSMakePoint(78.4895746,49.8191939) controlPoint1:NSMakePoint(78.4895485,49.8728292) controlPoint2:NSMakePoint(78.489605,49.8460115)];
[p curveToPoint:NSMakePoint(55.4945427,21.0296988) controlPoint1:NSMakePoint(78.4735552,35.6777176) controlPoint2:NSMakePoint(69.0952376,24.9178779)];
[p lineToPoint:NSMakePoint(55.4867624,21.0274758)];
[p lineToPoint:NSMakePoint(9.73522032,7.96104854)];
[p curveToPoint:NSMakePoint(9.70377844,7.95206703) controlPoint1:NSMakePoint(9.72473953,7.95805528) controlPoint2:NSMakePoint(9.71425207,7.95508523)];
[p curveToPoint:NSMakePoint(4.53924857,9.28317366) controlPoint1:NSMakePoint(7.86834108,7.42314591) controlPoint2:NSMakePoint(5.89045182,7.93290832)];
[p curveToPoint:NSMakePoint(3.20447002,14.4477684) controlPoint1:NSMakePoint(3.18787295,10.6336112) controlPoint2:NSMakePoint(2.67666891,12.6115886)];
p.windingRule=NSWindingRuleNonZero;
[color setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleButt;p.lineJoinStyle=NSLineJoinStyleMiter;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
 }
 if ([name isEqualToString:@"chevron.left.forwardslash.chevron.right"]) { // 开发.svg
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p appendBezierPathWithRoundedRect:NSMakeRect(15.5,15.5,97,97) xRadius:28 yRadius:28];
p.windingRule=NSWindingRuleNonZero;
[color setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleButt;p.lineJoinStyle=NSLineJoinStyleMiter;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(52,46)];
[p lineToPoint:NSMakePoint(45.2315488,52.1072732)];
[p curveToPoint:NSMakePoint(36,64.00002) controlPoint1:NSMakePoint(39.0771563,57.660427) controlPoint2:NSMakePoint(36,60.437224)];
[p curveToPoint:NSMakePoint(45.2315488,75.8928068) controlPoint1:NSMakePoint(36,67.562816) controlPoint2:NSMakePoint(39.0771563,70.339613)];
[p lineToPoint:NSMakePoint(52,82)];
p.windingRule=NSWindingRuleNonZero;
[color setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleButt;p.lineJoinStyle=NSLineJoinStyleMiter;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(71.5,83.5)];
[p lineToPoint:NSMakePoint(91.5,83.5)];
p.windingRule=NSWindingRuleNonZero;
[color setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleButt;p.lineJoinStyle=NSLineJoinStyleMiter;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
 }
 if ([name isEqualToString:@"width"]) { // 标注宽.svg
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p appendBezierPathWithRoundedRect:NSMakeRect(14,16,100,66) xRadius:16 yRadius:16];
p.windingRule=NSWindingRuleNonZero;
[color setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleButt;p.lineJoinStyle=NSLineJoinStyleMiter;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(96.3334531,94.1091435)];
[p curveToPoint:NSMakePoint(97.5136384,92.2234574) controlPoint1:NSMakePoint(96.3325323,93.308223) controlPoint2:NSMakePoint(96.7904065,92.576637)];
[p curveToPoint:NSMakePoint(99.7365803,92.4472768) controlPoint1:NSMakePoint(98.2368704,91.8702778) controlPoint2:NSMakePoint(99.0993008,91.9571126)];
[p lineToPoint:NSMakePoint(113.188644,102.846534)];
[p curveToPoint:NSMakePoint(114,104.5) controlPoint1:NSMakePoint(113.700719,103.244198) controlPoint2:NSMakePoint(114,103.854107)];
[p curveToPoint:NSMakePoint(113.188644,106.153481) controlPoint1:NSMakePoint(114,105.145907) controlPoint2:NSMakePoint(113.700719,105.755816)];
[p lineToPoint:NSMakePoint(99.7365803,116.561131)];
[p curveToPoint:NSMakePoint(97.5136384,116.78495) controlPoint1:NSMakePoint(99.0993008,117.051295) controlPoint2:NSMakePoint(98.2368704,117.13813)];
[p curveToPoint:NSMakePoint(96.3334531,114.899264) controlPoint1:NSMakePoint(96.7904065,116.431771) controlPoint2:NSMakePoint(96.3325323,115.700185)];
[p lineToPoint:NSMakePoint(96.3334531,108.69664)];
[p lineToPoint:NSMakePoint(31.6665469,108.69664)];
[p lineToPoint:NSMakePoint(31.6665469,114.907658)];
[p curveToPoint:NSMakePoint(30.4825758,116.786804) controlPoint1:NSMakePoint(31.664251,115.707065) controlPoint2:NSMakePoint(31.2051518,116.435726)];
[p curveToPoint:NSMakePoint(28.2634197,116.561131) controlPoint1:NSMakePoint(29.7599998,117.137881) controlPoint2:NSMakePoint(28.899495,117.050374)];
[p lineToPoint:NSMakePoint(14.8113561,106.153481)];
[p curveToPoint:NSMakePoint(14,104.5) controlPoint1:NSMakePoint(14.2992811,105.755816) controlPoint2:NSMakePoint(14,105.145907)];
[p curveToPoint:NSMakePoint(14.8113561,102.846534) controlPoint1:NSMakePoint(14,103.854107) controlPoint2:NSMakePoint(14.2992811,103.244198)];
[p lineToPoint:NSMakePoint(28.2634197,92.4388835)];
[p curveToPoint:NSMakePoint(30.4901701,92.2168951) controlPoint1:NSMakePoint(28.9019035,91.9477768) controlPoint2:NSMakePoint(29.7662748,91.8616062)];
[p curveToPoint:NSMakePoint(31.6665469,94.1091435) controlPoint1:NSMakePoint(31.2140654,92.5721841) controlPoint2:NSMakePoint(31.6707067,93.3067096)];
[p lineToPoint:NSMakePoint(31.6665469,100.303374)];
[p lineToPoint:NSMakePoint(96.3334531,100.303374)];
[p lineToPoint:NSMakePoint(96.3334531,94.1091435)];
[p closePath];
p.windingRule=NSWindingRuleNonZero;
[[NSColor colorWithSRGBRed:1 green:0 blue:0 alpha:1] setFill];
[p fill];
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
 }
 if ([name isEqualToString:@"height"]) { // 标注高.svg
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
CGContextTranslateCTM(cg,64,64);
CGContextRotateCTM(cg,90*M_PI/180.0);
CGContextTranslateCTM(cg,-64,-64);
CGContextTranslateCTM(cg,14,4);
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p appendBezierPathWithRoundedRect:NSMakeRect(0,39,100,76) xRadius:16 yRadius:16];
p.windingRule=NSWindingRuleNonZero;
[color setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleButt;p.lineJoinStyle=NSLineJoinStyleMiter;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(87.3334531,2.10914351)];
[p curveToPoint:NSMakePoint(88.5136384,0.223457428) controlPoint1:NSMakePoint(87.3325323,1.30822299) controlPoint2:NSMakePoint(87.7904065,0.576637045)];
[p curveToPoint:NSMakePoint(90.7365803,0.447276767) controlPoint1:NSMakePoint(89.2368704,-0.129722188) controlPoint2:NSMakePoint(90.0993008,-0.0428874375)];
[p lineToPoint:NSMakePoint(104.188644,10.8465338)];
[p curveToPoint:NSMakePoint(105,12.5) controlPoint1:NSMakePoint(104.700719,11.2441984) controlPoint2:NSMakePoint(105,11.8541074)];
[p curveToPoint:NSMakePoint(104.188644,14.1534808) controlPoint1:NSMakePoint(105,13.1459072) controlPoint2:NSMakePoint(104.700719,13.7558162)];
[p lineToPoint:NSMakePoint(90.7365803,24.5611311)];
[p curveToPoint:NSMakePoint(88.5136384,24.7849504) controlPoint1:NSMakePoint(90.0993008,25.0512953) controlPoint2:NSMakePoint(89.2368704,25.1381301)];
[p curveToPoint:NSMakePoint(87.3334531,22.8992644) controlPoint1:NSMakePoint(87.7904065,24.4317708) controlPoint2:NSMakePoint(87.3325323,23.7001849)];
[p lineToPoint:NSMakePoint(87.3334531,16.6966405)];
[p lineToPoint:NSMakePoint(12.6665469,16.6966405)];
[p lineToPoint:NSMakePoint(12.6665469,22.9076576)];
[p curveToPoint:NSMakePoint(11.4825758,24.7868036) controlPoint1:NSMakePoint(12.664251,23.7070647) controlPoint2:NSMakePoint(12.2051518,24.4357264)];
[p curveToPoint:NSMakePoint(9.2634197,24.5611311) controlPoint1:NSMakePoint(10.7599998,25.1378808) controlPoint2:NSMakePoint(9.89949505,25.0503735)];
[p lineToPoint:NSMakePoint(-4.18864389,14.1534808)];
[p curveToPoint:NSMakePoint(-5,12.5) controlPoint1:NSMakePoint(-4.70071886,13.7558162) controlPoint2:NSMakePoint(-5,13.1459072)];
[p curveToPoint:NSMakePoint(-4.18864389,10.8465338) controlPoint1:NSMakePoint(-5,11.8541074) controlPoint2:NSMakePoint(-4.70071886,11.2441984)];
[p lineToPoint:NSMakePoint(9.2634197,0.4388835)];
[p curveToPoint:NSMakePoint(11.4901701,0.216895143) controlPoint1:NSMakePoint(9.90190351,-0.0522232032) controlPoint2:NSMakePoint(10.7662748,-0.138393776)];
[p curveToPoint:NSMakePoint(12.6665469,2.10914351) controlPoint1:NSMakePoint(12.2140654,0.572184062) controlPoint2:NSMakePoint(12.6707067,1.30670963)];
[p lineToPoint:NSMakePoint(12.6665469,8.30337411)];
[p lineToPoint:NSMakePoint(87.3334531,8.30337411)];
[p lineToPoint:NSMakePoint(87.3334531,2.10914351)];
[p closePath];
p.windingRule=NSWindingRuleNonZero;
[[NSColor colorWithSRGBRed:1 green:0 blue:0 alpha:1] setFill];
[p fill];
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
 }
 if ([name isEqualToString:@"spacing"]) { // 标注间距.svg
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
CGContextTranslateCTM(cg,12,-48);
{ [NSGraphicsContext saveGraphicsState];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
[[NSBezierPath bezierPathWithRect:NSMakeRect(0,60,104,104)] addClip];
NSBezierPath *p=[NSBezierPath bezierPath];
[p appendBezierPathWithRoundedRect:NSMakeRect(7,5,90,76) xRadius:16 yRadius:16];
p.windingRule=NSWindingRuleNonZero;
[color setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleButt;p.lineJoinStyle=NSLineJoinStyleMiter;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
[[NSBezierPath bezierPathWithRect:NSMakeRect(0,60,104,104)] addClip];
NSBezierPath *p=[NSBezierPath bezierPath];
[p appendBezierPathWithRoundedRect:NSMakeRect(7,143,90,76) xRadius:16 yRadius:16];
p.windingRule=NSWindingRuleNonZero;
[color setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleButt;p.lineJoinStyle=NSLineJoinStyleMiter;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
CGContextTranslateCTM(cg,51.5,112);
CGContextRotateCTM(cg,-90*M_PI/180.0);
CGContextTranslateCTM(cg,-51.5,-112);
[[NSBezierPath bezierPathWithRect:NSMakeRect(0,60,104,104)] addClip];
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(56.8334531,101.609144)];
[p curveToPoint:NSMakePoint(58.0136384,99.7234574) controlPoint1:NSMakePoint(56.8325323,100.808223) controlPoint2:NSMakePoint(57.2904065,100.076637)];
[p curveToPoint:NSMakePoint(60.2365803,99.9472768) controlPoint1:NSMakePoint(58.7368704,99.3702778) controlPoint2:NSMakePoint(59.5993008,99.4571126)];
[p lineToPoint:NSMakePoint(73.6886439,110.346534)];
[p curveToPoint:NSMakePoint(74.5,112) controlPoint1:NSMakePoint(74.2007189,110.744198) controlPoint2:NSMakePoint(74.5,111.354107)];
[p curveToPoint:NSMakePoint(73.6886439,113.653481) controlPoint1:NSMakePoint(74.5,112.645907) controlPoint2:NSMakePoint(74.2007189,113.255816)];
[p lineToPoint:NSMakePoint(60.2365803,124.061131)];
[p curveToPoint:NSMakePoint(58.0136384,124.28495) controlPoint1:NSMakePoint(59.5993008,124.551295) controlPoint2:NSMakePoint(58.7368704,124.63813)];
[p curveToPoint:NSMakePoint(56.8334531,122.399264) controlPoint1:NSMakePoint(57.2904065,123.931771) controlPoint2:NSMakePoint(56.8325323,123.200185)];
[p lineToPoint:NSMakePoint(56.8334531,116.19664)];
[p lineToPoint:NSMakePoint(46.1665469,116.19664)];
[p lineToPoint:NSMakePoint(46.1665469,122.407658)];
[p curveToPoint:NSMakePoint(44.9825758,124.286804) controlPoint1:NSMakePoint(46.164251,123.207065) controlPoint2:NSMakePoint(45.7051518,123.935726)];
[p curveToPoint:NSMakePoint(42.7634197,124.061131) controlPoint1:NSMakePoint(44.2599998,124.637881) controlPoint2:NSMakePoint(43.399495,124.550374)];
[p lineToPoint:NSMakePoint(29.3113561,113.653481)];
[p curveToPoint:NSMakePoint(28.5,112) controlPoint1:NSMakePoint(28.7992811,113.255816) controlPoint2:NSMakePoint(28.5,112.645907)];
[p curveToPoint:NSMakePoint(29.3113561,110.346534) controlPoint1:NSMakePoint(28.5,111.354107) controlPoint2:NSMakePoint(28.7992811,110.744198)];
[p lineToPoint:NSMakePoint(42.7634197,99.9388835)];
[p curveToPoint:NSMakePoint(44.9901701,99.7168951) controlPoint1:NSMakePoint(43.4019035,99.4477768) controlPoint2:NSMakePoint(44.2662748,99.3616062)];
[p curveToPoint:NSMakePoint(46.1665469,101.609144) controlPoint1:NSMakePoint(45.7140654,100.072184) controlPoint2:NSMakePoint(46.1707067,100.80671)];
[p lineToPoint:NSMakePoint(46.1665469,107.803374)];
[p lineToPoint:NSMakePoint(56.8334531,107.803374)];
[p lineToPoint:NSMakePoint(56.8334531,101.609144)];
[p closePath];
p.windingRule=NSWindingRuleNonZero;
[[NSColor colorWithSRGBRed:1 green:0 blue:0 alpha:1] setFill];
[p fill];
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
 }
 if ([name isEqualToString:@"marginLeft"]) { // 标注左边距.svg
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
CGContextTranslateCTM(cg,64,64);
CGContextScaleCTM(cg,-1,1);
CGContextRotateCTM(cg,90*M_PI/180.0);
CGContextTranslateCTM(cg,-64,-64);
CGContextTranslateCTM(cg,12,-48);
{ [NSGraphicsContext saveGraphicsState];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
[[NSBezierPath bezierPathWithRect:NSMakeRect(-4,56,112,112)] addClip];
NSBezierPath *p=[NSBezierPath bezierPath];
[p appendBezierPathWithRoundedRect:NSMakeRect(3,143,98,76) xRadius:16 yRadius:16];
p.windingRule=NSWindingRuleNonZero;
[color setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleButt;p.lineJoinStyle=NSLineJoinStyleMiter;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
CGContextTranslateCTM(cg,51.5,96.5);
CGContextRotateCTM(cg,-90*M_PI/180.0);
CGContextTranslateCTM(cg,-51.5,-96.5);
[[NSBezierPath bezierPathWithRect:NSMakeRect(-4,56,112,112)] addClip];
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(70.3334531,86.1091435)];
[p curveToPoint:NSMakePoint(71.5136384,84.2234574) controlPoint1:NSMakePoint(70.3325323,85.308223) controlPoint2:NSMakePoint(70.7904065,84.576637)];
[p curveToPoint:NSMakePoint(73.7365803,84.4472768) controlPoint1:NSMakePoint(72.2368704,83.8702778) controlPoint2:NSMakePoint(73.0993008,83.9571126)];
[p lineToPoint:NSMakePoint(87.1886439,94.8465338)];
[p curveToPoint:NSMakePoint(88,96.5) controlPoint1:NSMakePoint(87.7007189,95.2441984) controlPoint2:NSMakePoint(88,95.8541074)];
[p curveToPoint:NSMakePoint(87.1886439,98.1534808) controlPoint1:NSMakePoint(88,97.1459072) controlPoint2:NSMakePoint(87.7007189,97.7558162)];
[p lineToPoint:NSMakePoint(73.7365803,108.561131)];
[p curveToPoint:NSMakePoint(71.5136384,108.78495) controlPoint1:NSMakePoint(73.0993008,109.051295) controlPoint2:NSMakePoint(72.2368704,109.13813)];
[p curveToPoint:NSMakePoint(70.3334531,106.899264) controlPoint1:NSMakePoint(70.7904065,108.431771) controlPoint2:NSMakePoint(70.3325323,107.700185)];
[p lineToPoint:NSMakePoint(70.3334531,100.69664)];
[p lineToPoint:NSMakePoint(32.6665469,100.69664)];
[p lineToPoint:NSMakePoint(32.6665469,106.907658)];
[p curveToPoint:NSMakePoint(31.4825758,108.786804) controlPoint1:NSMakePoint(32.664251,107.707065) controlPoint2:NSMakePoint(32.2051518,108.435726)];
[p curveToPoint:NSMakePoint(29.2634197,108.561131) controlPoint1:NSMakePoint(30.7599998,109.137881) controlPoint2:NSMakePoint(29.899495,109.050374)];
[p lineToPoint:NSMakePoint(15.8113561,98.1534808)];
[p curveToPoint:NSMakePoint(15,96.5) controlPoint1:NSMakePoint(15.2992811,97.7558162) controlPoint2:NSMakePoint(15,97.1459072)];
[p curveToPoint:NSMakePoint(15.8113561,94.8465338) controlPoint1:NSMakePoint(15,95.8541074) controlPoint2:NSMakePoint(15.2992811,95.2441984)];
[p lineToPoint:NSMakePoint(29.2634197,84.4388835)];
[p curveToPoint:NSMakePoint(31.4901701,84.2168951) controlPoint1:NSMakePoint(29.9019035,83.9477768) controlPoint2:NSMakePoint(30.7662748,83.8616062)];
[p curveToPoint:NSMakePoint(32.6665469,86.1091435) controlPoint1:NSMakePoint(32.2140654,84.5721841) controlPoint2:NSMakePoint(32.6707067,85.3067096)];
[p lineToPoint:NSMakePoint(32.6665469,92.3033741)];
[p lineToPoint:NSMakePoint(70.3334531,92.3033741)];
[p lineToPoint:NSMakePoint(70.3334531,86.1091435)];
[p closePath];
p.windingRule=NSWindingRuleNonZero;
[[NSColor colorWithSRGBRed:1 green:0 blue:0 alpha:1] setFill];
[p fill];
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
 }
 if ([name isEqualToString:@"marginRight"]) { // 标注右边距.svg
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
CGContextTranslateCTM(cg,64,64);
CGContextRotateCTM(cg,90*M_PI/180.0);
CGContextTranslateCTM(cg,-64,-64);
CGContextTranslateCTM(cg,12,-48);
{ [NSGraphicsContext saveGraphicsState];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
[[NSBezierPath bezierPathWithRect:NSMakeRect(-4,56,112,112)] addClip];
NSBezierPath *p=[NSBezierPath bezierPath];
[p appendBezierPathWithRoundedRect:NSMakeRect(3,143,98,76) xRadius:16 yRadius:16];
p.windingRule=NSWindingRuleNonZero;
[color setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleButt;p.lineJoinStyle=NSLineJoinStyleMiter;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
CGContextTranslateCTM(cg,51.5,96.5);
CGContextRotateCTM(cg,-90*M_PI/180.0);
CGContextTranslateCTM(cg,-51.5,-96.5);
[[NSBezierPath bezierPathWithRect:NSMakeRect(-4,56,112,112)] addClip];
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(70.3334531,86.1091435)];
[p curveToPoint:NSMakePoint(71.5136384,84.2234574) controlPoint1:NSMakePoint(70.3325323,85.308223) controlPoint2:NSMakePoint(70.7904065,84.576637)];
[p curveToPoint:NSMakePoint(73.7365803,84.4472768) controlPoint1:NSMakePoint(72.2368704,83.8702778) controlPoint2:NSMakePoint(73.0993008,83.9571126)];
[p lineToPoint:NSMakePoint(87.1886439,94.8465338)];
[p curveToPoint:NSMakePoint(88,96.5) controlPoint1:NSMakePoint(87.7007189,95.2441984) controlPoint2:NSMakePoint(88,95.8541074)];
[p curveToPoint:NSMakePoint(87.1886439,98.1534808) controlPoint1:NSMakePoint(88,97.1459072) controlPoint2:NSMakePoint(87.7007189,97.7558162)];
[p lineToPoint:NSMakePoint(73.7365803,108.561131)];
[p curveToPoint:NSMakePoint(71.5136384,108.78495) controlPoint1:NSMakePoint(73.0993008,109.051295) controlPoint2:NSMakePoint(72.2368704,109.13813)];
[p curveToPoint:NSMakePoint(70.3334531,106.899264) controlPoint1:NSMakePoint(70.7904065,108.431771) controlPoint2:NSMakePoint(70.3325323,107.700185)];
[p lineToPoint:NSMakePoint(70.3334531,100.69664)];
[p lineToPoint:NSMakePoint(32.6665469,100.69664)];
[p lineToPoint:NSMakePoint(32.6665469,106.907658)];
[p curveToPoint:NSMakePoint(31.4825758,108.786804) controlPoint1:NSMakePoint(32.664251,107.707065) controlPoint2:NSMakePoint(32.2051518,108.435726)];
[p curveToPoint:NSMakePoint(29.2634197,108.561131) controlPoint1:NSMakePoint(30.7599998,109.137881) controlPoint2:NSMakePoint(29.899495,109.050374)];
[p lineToPoint:NSMakePoint(15.8113561,98.1534808)];
[p curveToPoint:NSMakePoint(15,96.5) controlPoint1:NSMakePoint(15.2992811,97.7558162) controlPoint2:NSMakePoint(15,97.1459072)];
[p curveToPoint:NSMakePoint(15.8113561,94.8465338) controlPoint1:NSMakePoint(15,95.8541074) controlPoint2:NSMakePoint(15.2992811,95.2441984)];
[p lineToPoint:NSMakePoint(29.2634197,84.4388835)];
[p curveToPoint:NSMakePoint(31.4901701,84.2168951) controlPoint1:NSMakePoint(29.9019035,83.9477768) controlPoint2:NSMakePoint(30.7662748,83.8616062)];
[p curveToPoint:NSMakePoint(32.6665469,86.1091435) controlPoint1:NSMakePoint(32.2140654,84.5721841) controlPoint2:NSMakePoint(32.6707067,85.3067096)];
[p lineToPoint:NSMakePoint(32.6665469,92.3033741)];
[p lineToPoint:NSMakePoint(70.3334531,92.3033741)];
[p lineToPoint:NSMakePoint(70.3334531,86.1091435)];
[p closePath];
p.windingRule=NSWindingRuleNonZero;
[[NSColor colorWithSRGBRed:1 green:0 blue:0 alpha:1] setFill];
[p fill];
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
 }
 if ([name isEqualToString:@"marginTop"]) { // 标注上边距.svg
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
CGContextTranslateCTM(cg,12,-48);
{ [NSGraphicsContext saveGraphicsState];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
[[NSBezierPath bezierPathWithRect:NSMakeRect(-4,56,112,112)] addClip];
NSBezierPath *p=[NSBezierPath bezierPath];
[p appendBezierPathWithRoundedRect:NSMakeRect(3,143,98,76) xRadius:16 yRadius:16];
p.windingRule=NSWindingRuleNonZero;
[color setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleButt;p.lineJoinStyle=NSLineJoinStyleMiter;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
CGContextTranslateCTM(cg,51.5,96.5);
CGContextRotateCTM(cg,-90*M_PI/180.0);
CGContextTranslateCTM(cg,-51.5,-96.5);
[[NSBezierPath bezierPathWithRect:NSMakeRect(-4,56,112,112)] addClip];
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(70.3334531,86.1091435)];
[p curveToPoint:NSMakePoint(71.5136384,84.2234574) controlPoint1:NSMakePoint(70.3325323,85.308223) controlPoint2:NSMakePoint(70.7904065,84.576637)];
[p curveToPoint:NSMakePoint(73.7365803,84.4472768) controlPoint1:NSMakePoint(72.2368704,83.8702778) controlPoint2:NSMakePoint(73.0993008,83.9571126)];
[p lineToPoint:NSMakePoint(87.1886439,94.8465338)];
[p curveToPoint:NSMakePoint(88,96.5) controlPoint1:NSMakePoint(87.7007189,95.2441984) controlPoint2:NSMakePoint(88,95.8541074)];
[p curveToPoint:NSMakePoint(87.1886439,98.1534808) controlPoint1:NSMakePoint(88,97.1459072) controlPoint2:NSMakePoint(87.7007189,97.7558162)];
[p lineToPoint:NSMakePoint(73.7365803,108.561131)];
[p curveToPoint:NSMakePoint(71.5136384,108.78495) controlPoint1:NSMakePoint(73.0993008,109.051295) controlPoint2:NSMakePoint(72.2368704,109.13813)];
[p curveToPoint:NSMakePoint(70.3334531,106.899264) controlPoint1:NSMakePoint(70.7904065,108.431771) controlPoint2:NSMakePoint(70.3325323,107.700185)];
[p lineToPoint:NSMakePoint(70.3334531,100.69664)];
[p lineToPoint:NSMakePoint(32.6665469,100.69664)];
[p lineToPoint:NSMakePoint(32.6665469,106.907658)];
[p curveToPoint:NSMakePoint(31.4825758,108.786804) controlPoint1:NSMakePoint(32.664251,107.707065) controlPoint2:NSMakePoint(32.2051518,108.435726)];
[p curveToPoint:NSMakePoint(29.2634197,108.561131) controlPoint1:NSMakePoint(30.7599998,109.137881) controlPoint2:NSMakePoint(29.899495,109.050374)];
[p lineToPoint:NSMakePoint(15.8113561,98.1534808)];
[p curveToPoint:NSMakePoint(15,96.5) controlPoint1:NSMakePoint(15.2992811,97.7558162) controlPoint2:NSMakePoint(15,97.1459072)];
[p curveToPoint:NSMakePoint(15.8113561,94.8465338) controlPoint1:NSMakePoint(15,95.8541074) controlPoint2:NSMakePoint(15.2992811,95.2441984)];
[p lineToPoint:NSMakePoint(29.2634197,84.4388835)];
[p curveToPoint:NSMakePoint(31.4901701,84.2168951) controlPoint1:NSMakePoint(29.9019035,83.9477768) controlPoint2:NSMakePoint(30.7662748,83.8616062)];
[p curveToPoint:NSMakePoint(32.6665469,86.1091435) controlPoint1:NSMakePoint(32.2140654,84.5721841) controlPoint2:NSMakePoint(32.6707067,85.3067096)];
[p lineToPoint:NSMakePoint(32.6665469,92.3033741)];
[p lineToPoint:NSMakePoint(70.3334531,92.3033741)];
[p lineToPoint:NSMakePoint(70.3334531,86.1091435)];
[p closePath];
p.windingRule=NSWindingRuleNonZero;
[[NSColor colorWithSRGBRed:1 green:0 blue:0 alpha:1] setFill];
[p fill];
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
 }
 if ([name isEqualToString:@"marginBottom"]) { // 标注下边距.svg
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
CGContextTranslateCTM(cg,64,64);
CGContextRotateCTM(cg,180*M_PI/180.0);
CGContextTranslateCTM(cg,-64,-64);
CGContextTranslateCTM(cg,12,-48);
{ [NSGraphicsContext saveGraphicsState];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
[[NSBezierPath bezierPathWithRect:NSMakeRect(-4,56,112,112)] addClip];
NSBezierPath *p=[NSBezierPath bezierPath];
[p appendBezierPathWithRoundedRect:NSMakeRect(3,143,98,76) xRadius:16 yRadius:16];
p.windingRule=NSWindingRuleNonZero;
[color setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleButt;p.lineJoinStyle=NSLineJoinStyleMiter;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
CGContextTranslateCTM(cg,51.5,96.5);
CGContextRotateCTM(cg,-90*M_PI/180.0);
CGContextTranslateCTM(cg,-51.5,-96.5);
[[NSBezierPath bezierPathWithRect:NSMakeRect(-4,56,112,112)] addClip];
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(70.3334531,86.1091435)];
[p curveToPoint:NSMakePoint(71.5136384,84.2234574) controlPoint1:NSMakePoint(70.3325323,85.308223) controlPoint2:NSMakePoint(70.7904065,84.576637)];
[p curveToPoint:NSMakePoint(73.7365803,84.4472768) controlPoint1:NSMakePoint(72.2368704,83.8702778) controlPoint2:NSMakePoint(73.0993008,83.9571126)];
[p lineToPoint:NSMakePoint(87.1886439,94.8465338)];
[p curveToPoint:NSMakePoint(88,96.5) controlPoint1:NSMakePoint(87.7007189,95.2441984) controlPoint2:NSMakePoint(88,95.8541074)];
[p curveToPoint:NSMakePoint(87.1886439,98.1534808) controlPoint1:NSMakePoint(88,97.1459072) controlPoint2:NSMakePoint(87.7007189,97.7558162)];
[p lineToPoint:NSMakePoint(73.7365803,108.561131)];
[p curveToPoint:NSMakePoint(71.5136384,108.78495) controlPoint1:NSMakePoint(73.0993008,109.051295) controlPoint2:NSMakePoint(72.2368704,109.13813)];
[p curveToPoint:NSMakePoint(70.3334531,106.899264) controlPoint1:NSMakePoint(70.7904065,108.431771) controlPoint2:NSMakePoint(70.3325323,107.700185)];
[p lineToPoint:NSMakePoint(70.3334531,100.69664)];
[p lineToPoint:NSMakePoint(32.6665469,100.69664)];
[p lineToPoint:NSMakePoint(32.6665469,106.907658)];
[p curveToPoint:NSMakePoint(31.4825758,108.786804) controlPoint1:NSMakePoint(32.664251,107.707065) controlPoint2:NSMakePoint(32.2051518,108.435726)];
[p curveToPoint:NSMakePoint(29.2634197,108.561131) controlPoint1:NSMakePoint(30.7599998,109.137881) controlPoint2:NSMakePoint(29.899495,109.050374)];
[p lineToPoint:NSMakePoint(15.8113561,98.1534808)];
[p curveToPoint:NSMakePoint(15,96.5) controlPoint1:NSMakePoint(15.2992811,97.7558162) controlPoint2:NSMakePoint(15,97.1459072)];
[p curveToPoint:NSMakePoint(15.8113561,94.8465338) controlPoint1:NSMakePoint(15,95.8541074) controlPoint2:NSMakePoint(15.2992811,95.2441984)];
[p lineToPoint:NSMakePoint(29.2634197,84.4388835)];
[p curveToPoint:NSMakePoint(31.4901701,84.2168951) controlPoint1:NSMakePoint(29.9019035,83.9477768) controlPoint2:NSMakePoint(30.7662748,83.8616062)];
[p curveToPoint:NSMakePoint(32.6665469,86.1091435) controlPoint1:NSMakePoint(32.2140654,84.5721841) controlPoint2:NSMakePoint(32.6707067,85.3067096)];
[p lineToPoint:NSMakePoint(32.6665469,92.3033741)];
[p lineToPoint:NSMakePoint(70.3334531,92.3033741)];
[p lineToPoint:NSMakePoint(70.3334531,86.1091435)];
[p closePath];
p.windingRule=NSWindingRuleNonZero;
[[NSColor colorWithSRGBRed:1 green:0 blue:0 alpha:1] setFill];
[p fill];
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
 }
 if ([name isEqualToString:@"properties"]) { // 标注属性.svg
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
CGContextTranslateCTM(cg,19.1667,14);
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(75.9,30.19665)];
[p lineToPoint:NSMakePoint(78.2175,27.87945)];
[p curveToPoint:NSMakePoint(92.1205,27.87945) controlPoint1:NSMakePoint(82.0565,24.0402) controlPoint2:NSMakePoint(88.2815,24.0402)];
[p curveToPoint:NSMakePoint(92.1205,41.7825) controlPoint1:NSMakePoint(95.96,31.7187) controlPoint2:NSMakePoint(95.96,37.9434)];
[p lineToPoint:NSMakePoint(89.8035,44.1)];
[p moveToPoint:NSMakePoint(75.9,30.19665)];
[p curveToPoint:NSMakePoint(80.5345,39.46545) controlPoint1:NSMakePoint(75.9,30.19665) controlPoint2:NSMakePoint(76.19,35.1207)];
[p curveToPoint:NSMakePoint(89.8035,44.1) controlPoint1:NSMakePoint(84.8795,43.81) controlPoint2:NSMakePoint(89.8035,44.1)];
[p moveToPoint:NSMakePoint(89.8035,44.1)];
[p lineToPoint:NSMakePoint(68.5005,65.403)];
[p curveToPoint:NSMakePoint(65.5405,68.188) controlPoint1:NSMakePoint(67.0575,66.846) controlPoint2:NSMakePoint(66.336,67.5675)];
[p curveToPoint:NSMakePoint(62.5125,70.059) controlPoint1:NSMakePoint(64.602,68.9195) controlPoint2:NSMakePoint(63.5865,69.547)];
[p curveToPoint:NSMakePoint(58.698,71.461) controlPoint1:NSMakePoint(61.6015,70.493) controlPoint2:NSMakePoint(60.634,70.816)];
[p lineToPoint:NSMakePoint(52.5,73.527)];
[p lineToPoint:NSMakePoint(50.495,74.1955)];
[p lineToPoint:NSMakePoint(48.4895,74.864)];
[p curveToPoint:NSMakePoint(45.7765,74.2235) controlPoint1:NSMakePoint(47.537,75.1815) controlPoint2:NSMakePoint(46.4865,74.9335)];
[p curveToPoint:NSMakePoint(45.136,71.5105) controlPoint1:NSMakePoint(45.0665,73.5135) controlPoint2:NSMakePoint(44.8185,72.463)];
[p lineToPoint:NSMakePoint(45.8045,69.505)];
[p lineToPoint:NSMakePoint(46.473,67.5)];
[p lineToPoint:NSMakePoint(48.539,61.302)];
[p curveToPoint:NSMakePoint(49.941,57.4875) controlPoint1:NSMakePoint(49.184,59.366) controlPoint2:NSMakePoint(49.507,58.3985)];
[p curveToPoint:NSMakePoint(51.812,54.4595) controlPoint1:NSMakePoint(50.453,56.4135) controlPoint2:NSMakePoint(51.0805,55.398)];
[p curveToPoint:NSMakePoint(54.597,51.4995) controlPoint1:NSMakePoint(52.4325,53.664) controlPoint2:NSMakePoint(53.154,52.9425)];
[p lineToPoint:NSMakePoint(75.9,30.19665)];
[p moveToPoint:NSMakePoint(50.495,74.1955)];
[p lineToPoint:NSMakePoint(45.8045,69.505)];
p.windingRule=NSWindingRuleEvenOdd;
[color setStroke];
p.lineWidth=8;p.lineCapStyle=NSLineCapStyleRound;p.lineJoinStyle=NSLineJoinStyleMiter;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(19,50)];
[p lineToPoint:NSMakePoint(31.5,50)];
p.windingRule=NSWindingRuleEvenOdd;
[[NSColor colorWithSRGBRed:1 green:0 blue:0 alpha:1] setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleRound;p.lineJoinStyle=NSLineJoinStyleMiter;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(19,30)];
[p lineToPoint:NSMakePoint(51.5,30)];
p.windingRule=NSWindingRuleEvenOdd;
[[NSColor colorWithSRGBRed:1 green:0 blue:0 alpha:1] setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleRound;p.lineJoinStyle=NSLineJoinStyleMiter;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(19,70)];
[p lineToPoint:NSMakePoint(26.5,70)];
p.windingRule=NSWindingRuleEvenOdd;
[[NSColor colorWithSRGBRed:1 green:0 blue:0 alpha:1] setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleRound;p.lineJoinStyle=NSLineJoinStyleMiter;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(84.8867439,4.1507425)];
[p curveToPoint:NSMakePoint(49.9691559,-2) controlPoint1:NSMakePoint(78.8961818,-2) controlPoint2:NSMakePoint(69.2534989,-2)];
[p lineToPoint:NSMakePoint(39.7419906,-2)];
[p curveToPoint:NSMakePoint(4.82424922,4.1507425) controlPoint1:NSMakePoint(20.457443,-2) controlPoint2:NSMakePoint(10.8152204,-2)];
[p curveToPoint:NSMakePoint(-1.16667083,40) controlPoint1:NSMakePoint(-1.16667083,10.3015375) controlPoint2:NSMakePoint(-1.16667083,20.20099)];
[p lineToPoint:NSMakePoint(-1.16667083,61)];
[p curveToPoint:NSMakePoint(4.82424922,96.8491) controlPoint1:NSMakePoint(-1.16667083,80.7988) controlPoint2:NSMakePoint(-1.16667083,90.698725)];
[p curveToPoint:NSMakePoint(39.7419906,103) controlPoint1:NSMakePoint(10.8152204,103) controlPoint2:NSMakePoint(20.457443,103)];
[p lineToPoint:NSMakePoint(49.9691559,103)];
[p curveToPoint:NSMakePoint(84.8867439,96.8491) controlPoint1:NSMakePoint(69.2534989,103) controlPoint2:NSMakePoint(78.8961818,103)];
[p curveToPoint:NSMakePoint(90.8333292,71.5) controlPoint1:NSMakePoint(89.7093637,91.897825) controlPoint2:NSMakePoint(90.6497515,84.5179)];
p.windingRule=NSWindingRuleEvenOdd;
[color setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleRound;p.lineJoinStyle=NSLineJoinStyleMiter;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
 }
 if ([name isEqualToString:@"export"]) { // html交付.svg
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
CGContextTranslateCTM(cg,10.6667,16);
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(54,96)];
[p lineToPoint:NSMakePoint(16,96)];
[p curveToPoint:NSMakePoint(1.27897692e-13,80) controlPoint1:NSMakePoint(7.163444,96) controlPoint2:NSMakePoint(1.27897692e-13,88.836556)];
[p lineToPoint:NSMakePoint(1.27897692e-13,16)];
[p curveToPoint:NSMakePoint(16,0) controlPoint1:NSMakePoint(1.27897692e-13,7.163444) controlPoint2:NSMakePoint(7.163444,0)];
[p lineToPoint:NSMakePoint(90.6666667,0)];
[p curveToPoint:NSMakePoint(106.666667,16) controlPoint1:NSMakePoint(99.5032227,0) controlPoint2:NSMakePoint(106.666667,7.163444)];
[p lineToPoint:NSMakePoint(106.666667,51.6666667)];
p.windingRule=NSWindingRuleEvenOdd;
[color setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleRound;p.lineJoinStyle=NSLineJoinStyleMiter;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(4.26325641e-14,35.3333333)];
[p lineToPoint:NSMakePoint(106.666667,35.3333333)];
p.windingRule=NSWindingRuleEvenOdd;
[color setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleRound;p.lineJoinStyle=NSLineJoinStyleRound;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p appendBezierPathWithOvalInRect:NSMakeRect(49,12,12,12)];
p.windingRule=NSWindingRuleEvenOdd;
[color setFill];
[p fill];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p appendBezierPathWithOvalInRect:NSMakeRect(31,12,12,12)];
p.windingRule=NSWindingRuleEvenOdd;
[color setFill];
[p fill];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p appendBezierPathWithOvalInRect:NSMakeRect(13,12,12,12)];
p.windingRule=NSWindingRuleEvenOdd;
[color setFill];
[p fill];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
CGContextTranslateCTM(cg,87.3333,80.5);
CGContextRotateCTM(cg,90*M_PI/180.0);
CGContextTranslateCTM(cg,-87.3333,-80.5);
CGContextTranslateCTM(cg,73.8333,64.5);
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(13.3333333,32)];
[p lineToPoint:NSMakePoint(13.3333333,0)];
p.windingRule=NSWindingRuleEvenOdd;
[color setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleRound;p.lineJoinStyle=NSLineJoinStyleRound;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(13.3333333,0)];
[p lineToPoint:NSMakePoint(0,13.3333333)];
p.windingRule=NSWindingRuleEvenOdd;
[color setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleRound;p.lineJoinStyle=NSLineJoinStyleRound;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(13.3333333,0)];
[p lineToPoint:NSMakePoint(26.6666667,13.3333333)];
p.windingRule=NSWindingRuleEvenOdd;
[color setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleRound;p.lineJoinStyle=NSLineJoinStyleRound;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
 }
 if ([name isEqualToString:@"settings"]) { // 设置.svg
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
CGContextTranslateCTM(cg,16,11.2533);
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(0,37.3333333)];
[p lineToPoint:NSMakePoint(0,68.1066667)];
[p curveToPoint:NSMakePoint(10.117767,86.2427659) controlPoint1:NSMakePoint(0,79.2159635) controlPoint2:NSMakePoint(0,79.409888)];
[p curveToPoint:NSMakePoint(11.0569661,86.8389974) controlPoint1:NSMakePoint(10.4251674,86.450364) controlPoint2:NSMakePoint(10.7358437,86.6533302)];
[p lineToPoint:NSMakePoint(39.9964193,103.571263)];
[p curveToPoint:NSMakePoint(40.0016212,103.574271) controlPoint1:NSMakePoint(39.9981533,103.572266) controlPoint2:NSMakePoint(39.9998872,103.573268)];
[p curveToPoint:NSMakePoint(55.9887829,103.57989) controlPoint1:NSMakePoint(44.4246413,106.131146) controlPoint2:NSMakePoint(51.6148984,106.133019)];
[p curveToPoint:NSMakePoint(56.039388,103.55056) controlPoint1:NSMakePoint(56.005621,103.570061) controlPoint2:NSMakePoint(56.0225093,103.560319)];
[p lineToPoint:NSMakePoint(84.9430339,86.8389974)];
[p curveToPoint:NSMakePoint(85.882233,86.2427662) controlPoint1:NSMakePoint(85.2641563,86.6533303) controlPoint2:NSMakePoint(85.5748325,86.4503639)];
[p curveToPoint:NSMakePoint(96,68.16) controlPoint1:NSMakePoint(96,79.4099043) controlPoint2:NSMakePoint(96,79.2168945)];
[p lineToPoint:NSMakePoint(96,37.3333333)];
[p curveToPoint:NSMakePoint(85.882233,19.2505671) controlPoint1:NSMakePoint(96,26.2764388) controlPoint2:NSMakePoint(96,26.083429)];
[p curveToPoint:NSMakePoint(84.9430339,18.6543359) controlPoint1:NSMakePoint(85.5748325,19.0429694) controlPoint2:NSMakePoint(85.2641563,18.8400031)];
[p lineToPoint:NSMakePoint(56.0107422,1.92621094)];
[p curveToPoint:NSMakePoint(55.9759482,1.90596325) controlPoint1:NSMakePoint(55.9991253,1.91949427) controlPoint2:NSMakePoint(55.9875466,1.91271176)];
[p curveToPoint:NSMakePoint(40.0016212,1.91906261) controlPoint1:NSMakePoint(51.6008439,-0.639680061) controlPoint2:NSMakePoint(44.4203177,-0.635313606)];
[p curveToPoint:NSMakePoint(39.9964193,1.92207031) controlPoint1:NSMakePoint(39.9998872,1.92006505) controlPoint2:NSMakePoint(39.9981533,1.92106775)];
[p lineToPoint:NSMakePoint(11.0569661,18.6543359)];
[p curveToPoint:NSMakePoint(10.117767,19.2505671) controlPoint1:NSMakePoint(10.7358437,18.8400031) controlPoint2:NSMakePoint(10.4251675,19.0429694)];
[p curveToPoint:NSMakePoint(0,37.3333333) controlPoint1:NSMakePoint(0,26.083429) controlPoint2:NSMakePoint(0,26.2764388)];
p.windingRule=NSWindingRuleNonZero;
[color setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleButt;p.lineJoinStyle=NSLineJoinStyleMiter;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(48,68.7466667)];
[p curveToPoint:NSMakePoint(64,52.7466667) controlPoint1:NSMakePoint(56.836556,68.7466667) controlPoint2:NSMakePoint(64,61.5832227)];
[p curveToPoint:NSMakePoint(48,36.7466667) controlPoint1:NSMakePoint(64,43.9101107) controlPoint2:NSMakePoint(56.836556,36.7466667)];
[p curveToPoint:NSMakePoint(32,52.7466667) controlPoint1:NSMakePoint(39.163444,36.7466667) controlPoint2:NSMakePoint(32,43.9101107)];
[p curveToPoint:NSMakePoint(48,68.7466667) controlPoint1:NSMakePoint(32,61.5832227) controlPoint2:NSMakePoint(39.163444,68.7466667)];
p.windingRule=NSWindingRuleNonZero;
[color setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleButt;p.lineJoinStyle=NSLineJoinStyleMiter;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
 }
 if ([name isEqualToString:@"area"]) { // 标注区域.svg
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
CGContextTranslateCTM(cg,63.6464,67.5251);
CGContextRotateCTM(cg,-45*M_PI/180.0);
CGContextTranslateCTM(cg,-63.6464,-67.5251);
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(50.6464466,116.525126)];
[p lineToPoint:NSMakePoint(82.6464466,116.525126)];
[p lineToPoint:NSMakePoint(82.6464466,126.525126)];
[p lineToPoint:NSMakePoint(50.6464466,126.525126)];
[p closePath];
[p moveToPoint:NSMakePoint(26.6464466,90.5251263)];
[p lineToPoint:NSMakePoint(106.646447,90.5251263)];
[p lineToPoint:NSMakePoint(106.646447,100.525126)];
[p lineToPoint:NSMakePoint(26.6464466,100.525126)];
[p closePath];
[p moveToPoint:NSMakePoint(-0.353553391,64.5251263)];
[p lineToPoint:NSMakePoint(130.646447,64.5251263)];
[p lineToPoint:NSMakePoint(130.646447,74.5251263)];
[p lineToPoint:NSMakePoint(-0.353553391,74.5251263)];
[p closePath];
[p moveToPoint:NSMakePoint(16.6464466,38.5251263)];
[p lineToPoint:NSMakePoint(114.646447,38.5251263)];
[p lineToPoint:NSMakePoint(114.646447,48.5251263)];
[p lineToPoint:NSMakePoint(16.6464466,48.5251263)];
[p closePath];
[p moveToPoint:NSMakePoint(41.1464466,12.5251263)];
[p lineToPoint:NSMakePoint(89.1464466,12.5251263)];
[p lineToPoint:NSMakePoint(89.1464466,22.5251263)];
[p lineToPoint:NSMakePoint(41.1464466,22.5251263)];
[p closePath];
p.windingRule=NSWindingRuleNonZero;
[[NSColor colorWithSRGBRed:1 green:0 blue:0 alpha:1] setFill];
[p fill];
[NSGraphicsContext restoreGraphicsState]; }
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p appendBezierPathWithRoundedRect:NSMakeRect(14,15,100,98) xRadius:16 yRadius:16];
p.windingRule=NSWindingRuleNonZero;
[color setStroke];
p.lineWidth=10;p.lineCapStyle=NSLineCapStyleButt;p.lineJoinStyle=NSLineJoinStyleMiter;
[p stroke];
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
 }
 if ([name isEqualToString:@"xmark"]) { // 关闭.svg
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
CGContextTranslateCTM(cg,64,64);
CGContextRotateCTM(cg,-45*M_PI/180.0);
CGContextTranslateCTM(cg,-64,-64);
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(64,20)];
[p curveToPoint:NSMakePoint(69,25) controlPoint1:NSMakePoint(66.7614237,20) controlPoint2:NSMakePoint(69,22.2385763)];
[p lineToPoint:NSMakePoint(69,59)];
[p lineToPoint:NSMakePoint(103,59)];
[p curveToPoint:NSMakePoint(108,64) controlPoint1:NSMakePoint(105.761424,59) controlPoint2:NSMakePoint(108,61.2385763)];
[p curveToPoint:NSMakePoint(103,69) controlPoint1:NSMakePoint(108,66.7614237) controlPoint2:NSMakePoint(105.761424,69)];
[p lineToPoint:NSMakePoint(69,69)];
[p lineToPoint:NSMakePoint(69,103)];
[p curveToPoint:NSMakePoint(64,108) controlPoint1:NSMakePoint(69,105.761424) controlPoint2:NSMakePoint(66.7614237,108)];
[p curveToPoint:NSMakePoint(59,103) controlPoint1:NSMakePoint(61.2385763,108) controlPoint2:NSMakePoint(59,105.761424)];
[p lineToPoint:NSMakePoint(59,69)];
[p lineToPoint:NSMakePoint(25,69)];
[p curveToPoint:NSMakePoint(20,64) controlPoint1:NSMakePoint(22.2385763,69) controlPoint2:NSMakePoint(20,66.7614237)];
[p curveToPoint:NSMakePoint(25,59) controlPoint1:NSMakePoint(20,61.2385763) controlPoint2:NSMakePoint(22.2385763,59)];
[p lineToPoint:NSMakePoint(59,59)];
[p lineToPoint:NSMakePoint(59,25)];
[p curveToPoint:NSMakePoint(64,20) controlPoint1:NSMakePoint(59,22.2385763) controlPoint2:NSMakePoint(61.2385763,20)];
[p closePath];
p.windingRule=NSWindingRuleEvenOdd;
[color setFill];
[p fill];
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
 }
 [NSGraphicsContext restoreGraphicsState];return YES;
 }];
}
