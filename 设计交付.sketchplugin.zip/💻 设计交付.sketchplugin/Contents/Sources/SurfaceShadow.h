// Shadow values supplied in the latest popup artboards.
// CSS blur is twice the Core Animation standard deviation.
static void SMApplySurfaceShadow(NSView *view,CGFloat corner,CGFloat blur){
 NSShadow *shadow=[NSShadow new];shadow.shadowColor=[NSColor colorWithWhite:0 alpha:.251];shadow.shadowBlurRadius=blur/2;shadow.shadowOffset=NSMakeSize(0,-10);view.shadow=shadow;
 view.wantsLayer=YES;view.layer.masksToBounds=NO;view.layer.shadowColor=NSColor.blackColor.CGColor;view.layer.shadowOpacity=.251;view.layer.shadowRadius=blur/2;view.layer.shadowOffset=CGSizeMake(0,10);
 CGPathRef path=CGPathCreateWithRoundedRect(NSRectToCGRect(view.bounds),corner,corner,NULL);view.layer.shadowPath=path;CGPathRelease(path);
}
