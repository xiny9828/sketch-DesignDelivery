// Render from a private snapshot in a separate process.
var labSnapshotPath = null;
var labOriginalPath = null;
var labRasterIDs = {};
var labOwnRasterIDs = {};
var labCodeEffectIDs = {};
var labTextOutlineFailureCount = {};
function labPNGBatches(items, scale) {
  var batches = [];
  items.map(function (item) { return {item:item,pixels:Math.max(1,item.width)*Math.max(1,item.height)*scale*scale}; })
    .sort(function (a,b) { return b.pixels-a.pixels; }).forEach(function (entry) {
      var target = null;
      for (var i=0;i<batches.length;i++) {
        if (batches[i].items.length<40&&batches[i].pixels+entry.pixels<=32000000) { target=batches[i]; break; }
      }
      if (!target) { target={items:[],pixels:0}; batches.push(target); }
      target.items.push(entry.item); target.pixels+=entry.pixels;
    });
  return batches;
}
function labRenderPNGs(items, source, directory, scale, contentsOnly, logPath) {
  var cli = String(NSBundle.mainBundle().bundlePath()) + '/Contents/MacOS/sketchtool';
  labPNGBatches(items,scale).forEach(function (batch) {
    var args = ['export','layers',source,'--items='+batch.items.map(function(item){return item.id}).join(','),'--output='+directory,
      '--formats=png','--scales='+scale,'--use-id-for-name=YES','--overwriting=YES','--save-for-web=YES'];
    if (contentsOnly) args.push('--group-contents-only=YES');
    labRun(cli,args,logPath);
  });
}
function labRun(executable, args, logPath) {
  var manager = NSFileManager.defaultManager();
  manager.createFileAtPath_contents_attributes(logPath, NSData.data(), null);
  var log = NSFileHandle.fileHandleForWritingAtPath(logPath);
  var task = NSTask.alloc().init();
  task.setLaunchPath(executable); task.setArguments(args);
  task.setStandardOutput(log); task.setStandardError(log);
  try {
    task.launch();
    var deadline = Date.now() + 180000;
    while (task.isRunning()) {
      if (Date.now() > deadline) {
        task.terminate();
        var stopDeadline = Date.now() + 2000;
        while (task.isRunning() && Date.now() < stopDeadline) NSThread.sleepForTimeInterval(0.05);
        if (task.isRunning()) {
          var stop = NSTask.alloc().init(); stop.setLaunchPath('/bin/kill');
          stop.setArguments(['-KILL', String(task.processIdentifier())]); stop.launch(); stop.waitUntilExit();
        }
        task.waitUntilExit();
        throw new Error('独立渲染超时，已停止；原文档未修改。');
      }
      NSThread.sleepForTimeInterval(0.05);
    }
    if (Number(task.terminationStatus()) !== 0) throw new Error('独立渲染失败：' + readText(logPath).slice(-1600));
  } finally { log.closeFile(); }
}
function labPrepareSnapshot(copy) {
  if (!copy || !copy.path || !copy.directory) throw new Error('缺少独立导出副本。');
  var directory = copy.directory + '/svg-source';
  labOriginalPath = copy.path;
  labRasterIDs = {};
  labOwnRasterIDs = {};
  labCodeEffectIDs = {};
  labTextOutlineFailureCount = {};
  mkdir(directory);
  labRun('/usr/bin/ditto', ['-x', '-k', copy.path, directory], copy.directory + '/unpack.log');
  var documentPath = directory + '/document.json';
  var data = JSON.parse(readText(documentPath));
  function visit(layer) {
    if (layer.do_objectID && layer.name != null) layer.name = 'lab-' + layer.do_objectID;
    if (layer.layers) layer.layers = layer.layers.filter(function (child) { return !isMark(child); });
    (layer.layers || []).forEach(visit);
  }
  (data.pages || []).forEach(function (ref) {
    if (!/^pages\/[A-Za-z0-9_-]+$/.test(String(ref._ref))) throw new Error('页面路径无效。');
    var path = directory + '/' + ref._ref + '.json';
    var page = JSON.parse(readText(path)); visit(page); writeText(path, JSON.stringify(page));
  });
  (data.foreignSymbols || []).forEach(function (symbol) { if (symbol.symbolMaster) visit(symbol.symbolMaster); });
  writeText(documentPath, JSON.stringify(data));
  labSnapshotPath = copy.directory + '/svg-source.sketch';
}
boardPreview = function (layer, output, id) {
  // A detached layer lacks the document required by MSHighLevelExporter.
  // Reject it before any rendering; render only the on-disk private snapshot.
  if (!layer || !layer.getParentPage() || !labOriginalPath || !fileExists(labOriginalPath)) {
    throw new Error('只能从已保存的独立文档副本渲染，无法导出游离图层。');
  }
  return {path: 'preview/' + id + '.svg', format: 'svg', scale: 1, svgSource: '', warnings: []};
};
function labArchive(native) {
  var archiver = MSJSONDataArchiver.alloc().init(), error = MOPointer.alloc().init();
  archiver.archiveObjectIDs = true;
  archiver.archivedDataWithRootObject_error(native.immutableModelObject(), error);
  if (error.value()) throw new Error('无法保存渲染副本：' + error.value());
  return JSON.parse(String(NSString.alloc().initWithData_encoding(archiver.archivedData(), NSUTF8StringEncoding)));
}
function labOutlinedBoard(board) {
  // Freeze layout before Sketch's outline command replaces text in the private copy.
  var outlined = {}, frozen = labArchive(board.sketchObject);
  var boardKey = String(board.id || frozen.do_objectID);
  function unsupported(raw) {
    if (((raw.style && raw.style.blurs) || []).some(function (blur) { return blur.isEnabled; })) labCodeEffectIDs[raw.do_objectID] = true;
    var own = ((raw.style && raw.style.blurs) || []).some(function (blur) { return blur.isEnabled && Number(blur.type) !== 0 && (Number(blur.radius) > 0 || Number(blur.type) === 4); });
    if (own) labOwnRasterIDs[raw.do_objectID] = true;
    (raw.layers || []).forEach(function (child) { if (unsupported(child)) own = true; });
    if (own) labRasterIDs[raw.do_objectID] = true;
    return own && raw.isVisible !== false && !(raw.style && raw.style.contextSettings && Number(raw.style.contextSettings.opacity) === 0);
  }
  unsupported(frozen);
  function capture(layer) {
    if (layer.type === 'Text' && String(layer.text || '').length) {
      var key = String(layer.id), original = labArchive(layer.sketchObject);
      try {
        var paths = layer.sketchObject.layersByConvertingToOutlines(), items = [];
        for (var i = 0; i < paths.count(); i++) items.push(labArchive(paths[i]));
        if (!items.length) throw new Error('转换结果为空');
        var raw = items[0];
        if (items.length > 1) {
          raw = { _class: 'group', frame: original.frame,
            groupLayout: { _class: 'MSImmutableFreeformGroupLayout' }, layers: items };
          items.forEach(function (item) { item.frame.x -= raw.frame.x; item.frame.y -= raw.frame.y; });
        }
        raw.do_objectID = key; raw.name = 'lab-' + key;
        raw.exportOptions = original.exportOptions;
        outlined[key] = raw;
      } catch (error) {
        // Keep the original text in the private snapshot. The native 4x PNG
        // renderer can still reproduce it even when outlining is unavailable.
        labTextOutlineFailureCount[boardKey] = (labTextOutlineFailureCount[boardKey] || 0) + 1;
      }
    }
    (layer.layers || []).slice().forEach(capture);
  }
  capture(board);
  if (labTextOutlineFailureCount[boardKey]) labRasterIDs[boardKey] = true;
  function visit(raw) {
    if (outlined[raw.do_objectID]) raw = outlined[raw.do_objectID];
    if (raw.do_objectID) raw.name = 'lab-' + raw.do_objectID;
    if (raw.layers) raw.layers = raw.layers.filter(function (l) { return !isMark(l); }).map(visit);
    return raw;
  }
  return visit(frozen);
}
function labNormalize(paths, copy, context) {
  var plan = copy.directory + '/normalize-plan.json'; writeText(plan, JSON.stringify(paths));
  labRun('/usr/bin/osascript', ['-l', 'JavaScript', resource(context, 'normalize-svg.js'), plan], copy.directory + '/normalize.log');
}
function labImageSVG(path, width, height) {
  var data = NSData.dataWithContentsOfFile(path);
  if (!data) throw new Error('缺少原生效果图：' + path);
  return '<svg xmlns="http://www.w3.org/2000/svg" width="' + width + '" height="' + height + '" viewBox="0 0 ' + width + ' ' + height + '"><image width="' + width + '" height="' + height + '" href="data:image/png;base64,' + String(data.base64EncodedStringWithOptions(0)) + '"/></svg>';
}
function labAssetIndex(replacements) {
  var index = {}, parents = {};
  function indexLayer(raw, parent) {
    index[raw.do_objectID] = raw; parents[raw.do_objectID] = parent;
    (raw.layers || []).forEach(function (child) { indexLayer(child, raw); });
  }
  Object.keys(replacements).forEach(function (key) { indexLayer(replacements[key], null); });
  return {layers:index, parents:parents};
}
function labAssetRoot(layer, index) {
  var target = index.layers[layer.labNativeID];
  if (!target) throw new Error('切图原始图层缺失：' + layer.name);
  var root = target._class === 'slice' ? index.parents[layer.labNativeID] : target;
  if (!root) throw new Error('切片缺少内容容器：' + layer.name);
  return root;
}
function labRawHasPaint(raw) {
  var style = raw.style || {}, context = style.contextSettings || {};
  if (raw.isVisible === false || (context.opacity != null && Number(context.opacity) <= 0)) return false;
  if (raw._class === 'bitmap' && raw.image) return true;
  if (raw._class === 'text' && raw.attributedString && raw.attributedString.string) return true;
  function painted(paint) {
    if (paint.isEnabled === false || (paint.contextSettings && Number(paint.contextSettings.opacity) === 0)) return false;
    if (Number(paint.fillType) === 1 && paint.gradient) return (paint.gradient.stops || []).some(function(stop){return !stop.color || Number(stop.color.alpha) > 0;});
    if (Number(paint.fillType) === 4) return Boolean(paint.image);
    return !paint.color || paint.color.alpha == null || Number(paint.color.alpha) > 0;
  }
  if ((style.fills || []).some(painted) || (style.borders || []).some(function(border){return Number(border.thickness) > 0 && painted(border);})) return true;
  return (raw.layers || []).some(labRawHasPaint);
}
function labPlanAssets(candidates, replacements) {
  var index = labAssetIndex(replacements), groups = {}, unique = [], aliases = [];
  // Prefer an authored cut as the owner when an internal fallback is identical.
  candidates.slice().sort(function(a,b){return Number(Boolean(b.labBuiltIn))-Number(Boolean(a.labBuiltIn));}).forEach(function(layer){
    var root = labAssetRoot(layer,index), target = index.layers[layer.labNativeID];
    if (!labRawHasPaint(root)) {
      layer.labSliceError = '此图层没有可见绘制内容，未生成空白切图。';
      return;
    }
    var normalized = Object.assign({},root,{frame:Object.assign({},root.frame,{x:0,y:0})});
    delete normalized.flexItem;
    // Only exact native content is shared. Size, effects, image references and
    // slice configuration remain in the key; placement and object names do not.
    var key = JSON.stringify({raster:Boolean(labRasterIDs[layer.labNativeID]),
      slice:target._class==='slice'?target.frame:null,root:normalized},function(name,value){
      return name==='do_objectID'||name==='name'?undefined:value;
    });
    var owner = groups[key];
    if (owner) aliases.push({layer:layer,owner:owner});
    else { groups[key]=layer;unique.push(layer); }
  });
  return {layers:unique,aliases:aliases};
}
function labAssetSnapshot(copy, layers, replacements) {
  var sourceDirectory = copy.directory + '/svg-source', directory = copy.directory + '/slice-source';
  labRun('/usr/bin/ditto', [sourceDirectory, directory], copy.directory + '/copy-slices.log');
  var doc = JSON.parse(readText(directory + '/document.json')), index = labAssetIndex(replacements);
  var pagePath = directory + '/' + doc.pages[0]._ref + '.json';
  var page = JSON.parse(readText(pagePath)); page.layers = [];
  layers.forEach(function (layer) {
    // A native slice needs its siblings; a layer export needs only its subtree.
    var clone = JSON.parse(JSON.stringify(labAssetRoot(layer,index)));
    function remap(raw) {
      if (raw.do_objectID !== layer.labNativeID) raw.do_objectID = String(NSUUID.UUID().UUIDString());
      (raw.layers || []).forEach(remap);
    }
    remap(clone);
    clone.frame.x = 0; clone.frame.y = 0;
    delete clone.flexItem;
    page.layers.push(clone);
  });
  // The private asset document has no original page siblings or ancestor clips.
  doc.pages = [doc.pages[0]];
  writeText(pagePath, JSON.stringify(page)); writeText(directory + '/document.json', JSON.stringify(doc));
  var snapshot = copy.directory + '/slices.sketch';
  labRun('/usr/bin/ditto', ['-c', '-k', '--zlibCompressionLevel', '0', directory, snapshot], copy.directory + '/pack-slices.log');
  return snapshot;
}
function labFinalizeProject(copy, boards, project, output, context) {
  var replacements = {}, directory = copy.directory + '/svg-source';
  boards.forEach(function (board) { var key = String(board.id); replacements[key] = labOutlinedBoard(board); });
  var doc = JSON.parse(readText(directory + '/document.json'));
  (doc.pages || []).forEach(function (ref) {
    var path = directory + '/' + ref._ref + '.json', page = JSON.parse(readText(path));
    function visit(raw) {
      if (replacements[raw.do_objectID]) return replacements[raw.do_objectID];
      if (raw.layers) raw.layers = raw.layers.map(visit);
      return raw;
    }
    writeText(path, JSON.stringify(visit(page)));
  });
  removePath(labSnapshotPath);
  labRun('/usr/bin/ditto', ['-c', '-k', '--zlibCompressionLevel', '0', directory, labSnapshotPath], copy.directory + '/pack-outlines.log');
  var cli = String(NSBundle.mainBundle().bundlePath()) + '/Contents/MacOS/sketchtool';
  labRun(cli, ['export', 'layers', labSnapshotPath, '--items=' + boards.map(function (b) { return b.id; }).join(','),
    '--output=' + output + '/preview', '--formats=svg', '--scales=1', '--use-id-for-name=YES',
    '--overwriting=YES', '--save-for-web=YES'], output + '/svg-render.log');
  var svgPaths = project.artboards.map(function (b) { return output + '/' + b.imagePath; });
  labNormalize(svgPaths, copy, context);
  // Always use the native 4x render for the board preview. SVG remains in the
  // payload as a backend for on-demand cuts and code inspection.
  labRenderPNGs(project.artboards.map(function (b) {
    return {id:b.objectID,width:b.width,height:b.height};
  }),labOriginalPath,output+'/preview',4,false,output+'/native-effects.log');
  var dedicated = [];
  project.artboards.forEach(function (board) {
    board.svgPath = board.imagePath;
    board.svgSource = readText(output + '/' + board.svgPath);
    board.imagePath = 'preview/' + board.objectID + '@4x.png';
    board.previewFormat = 'png';
    board.previewScale = 4;
    if (!fileExists(output + '/' + board.imagePath)) throw new Error('原生画板预览缺失：' + board.name);
    var byID = {};
    board.layers.forEach(function (l) { byID[l.objectID] = l; });
    board.layers.forEach(function (l) {
      if (labCodeEffectIDs[l.labNativeID] || (l.blendMode && l.blendMode !== 'Normal')) l.labCodeWarning = '此图层含模糊或混合效果，下方代码不包含该效果，不能用于完整复现。';
      var parent = byID[l.parentObjectID];
      l.labBuiltIn = Boolean(l.manualExport || l.autoIcon || (l.nativeType === 'Slice' && !(parent && parent.manualExport)));
      if (l.labBuiltIn && l.hidden) l.labSliceError = '此切图在 Sketch 中被隐藏，没有可见内容；未生成空白下载。';
      // Boolean operands and Slice markers are not separate visual assets.
      // Ordinary vector layers are cut from the shared board SVG on demand.
      var unmappedGroup = l.nativeType === 'Group' && l.hasChildren && board.svgSource.indexOf('id="' + l.svgNodeID + '"') < 0;
      if (l.labNativeID && !l.hidden && (l.labBuiltIn || unmappedGroup || (l.nativeType !== 'Slice' && labRasterIDs[l.labNativeID]))) dedicated.push(l);
    });
    if (labRasterIDs[board.objectID]) {
      // Backdrop compositing depends on the whole scene, not just layer bounds.
      board.nativeEffects = true;
      board.svgWarnings = ['此画板含 SVG 无法独立复现的效果，使用原生位图保持外观。'];
    }
  });
  var plan = labPlanAssets(dedicated,replacements);
  dedicated = plan.layers;
  var assetSnapshot = dedicated.length ? labAssetSnapshot(copy, dedicated, replacements) : labSnapshotPath;
  var assetDirectory = copy.directory + '/asset-render';
  mkdir(assetDirectory);
  var vectorLayers = dedicated.filter(function (l) { return !labRasterIDs[l.labNativeID]; });
  for (var start = 0; start < vectorLayers.length; start += 40) {
    var batch = vectorLayers.slice(start, start + 40);
    labRun(cli, ['export', 'layers', assetSnapshot, '--items=' + batch.map(function (l) { return l.labNativeID; }).join(','),
      '--output=' + assetDirectory, '--formats=svg', '--scales=1', '--use-id-for-name=YES',
      '--overwriting=YES', '--save-for-web=YES', '--group-contents-only=YES'], output + '/asset-render.log');
  }
  // Native PNG jobs are independent of the vector batch boundaries. Pack them
  // together without raising the existing pixel or item limit per renderer.
  var vectorPaths = dedicated.filter(function(l){return !labRasterIDs[l.labNativeID]}).map(function(l){return assetDirectory+'/'+l.labNativeID+'.svg'});
  for (var offset=0;offset<vectorPaths.length;offset+=128) labNormalize(vectorPaths.slice(offset,offset+128),copy,context);
  labRenderPNGs(dedicated.filter(function (l) { return labRasterIDs[l.labNativeID]; }).map(function (l) {
    var r=l.visualRect||l.rect; return {id:l.labNativeID,width:r.width,height:r.height};
  }),assetSnapshot,assetDirectory,4,true,output+'/native-asset-effects.log');
  dedicated.forEach(function (l) {
      var path = assetDirectory + '/' + l.labNativeID + '.svg';
      // Raster fallback replaces this SVG completely. Do not render a vector
      // version first, only to discard it after an expensive native export.
      if (labRasterIDs[l.labNativeID]) {
        var png = assetDirectory + '/' + l.labNativeID + '@4x.png', size = inspectExportResource(png, 'png');
        if (!size.width || !size.height) throw new Error('原生切图尺寸无效：' + l.name);
        l.labAssetSource = labImageSVG(png, size.width / 4, size.height / 4); writeText(path, l.labAssetSource);
        removePath(png);
        l.labRasterFallback = true;
      } else {
        if (!fileExists(path)) throw new Error('原生切图缺失：' + l.name);
        l.labAssetSource = readText(path);
      }
      if (!/<svg\b/.test(l.labAssetSource) || !/<(?:path|rect|circle|ellipse|polygon|polyline|line|image|use)\b/.test(l.labAssetSource)) {
        if (l.labBuiltIn && !l.hidden) throw new Error('已有切图导出为空，已停止交付：' + l.name);
        l.labSliceError = l.hidden ? '此切图在 Sketch 中被隐藏，没有可见内容；未生成空白下载。' : 'Sketch 未生成此内部图层的独立可见内容，请选择包含它的编组。';
        delete l.labAssetSource;
        removePath(path);
        return;
      }
      if (l.labBuiltIn) {
        l.labAssetPath = 'assets/' + l.labNativeID + '.svg';
        writeText(output + '/' + l.labAssetPath,l.labAssetSource);
      }
  });
  plan.aliases.forEach(function(alias){
    alias.layer.labAssetSource=alias.owner.labAssetSource;
    if(alias.owner.labRasterFallback)alias.layer.labRasterFallback=true;
    if(alias.owner.labSliceError)alias.layer.labSliceError=alias.owner.labSliceError;
    if(alias.owner.labAssetPath)alias.layer.labAssetPath=alias.owner.labAssetPath;
  });
}
function labProjectPayload(project, output, copy, context) {
  var json = JSON.stringify(project);
  writeText(output + '/规范数据.json', json);
  if (json.length < 32768) return {runtime:'', expression:scriptJSON(project)};
  var packedJSON = require('../Resources/project-codec.js').encode(project);
  var packedInput = copy.directory + '/project-packed.json';
  writeText(packedInput, packedJSON);
  var packedPath = copy.directory + '/project.json.gz';
  labRun('/usr/bin/gzip', ['-1', '-n', '-c', packedInput], packedPath);
  var bytes = NSData.dataWithContentsOfFile(packedPath);
  if (!bytes || !Number(bytes.length())) throw new Error('交付数据压缩失败。');
  return {runtime:readText(resource(context, 'vendor/fflate.min.js')) + '\n' + readText(resource(context, 'project-codec.js')),
    expression:'(await SMProjectCodec.load(' + scriptJSON(String(bytes.base64EncodedStringWithOptions(0))) + '))'};
}
// Use shared SVG nodes where possible; dedicated assets cover authored exports and unsupported mappings.
exportAssets = function () {};
exportWebSlicesBatch = function () {};
image = function () { throw new Error('画板与切图应使用独立文档渲染。'); };
