// This toolbar operates on the original Sketch canvas. No HTML or snapshot is opened.
var NATIVE_DEV_KEY = 'measure.zh-modern.native-developer.v2';
var NATIVE_DEV_DOCUMENTS_KEY = NATIVE_DEV_KEY + '.documents';
function nativeDeveloperDocuments() {
  var dict=NSThread.mainThread().threadDictionary(),sessions=dict[NATIVE_DEV_DOCUMENTS_KEY];
  if(!sessions){sessions=NSMutableDictionary.dictionary();dict[NATIVE_DEV_DOCUMENTS_KEY]=sessions;}
  return sessions;
}
function nativeDeveloperSupports(object, selector) { return !!object && !!object.respondsToSelector(NSSelectorFromString(selector)); }
function nativeDeveloperRefresh(n) {
  if (nativeDeveloperSupports(n, 'performSelectionChangedUpdates')) n.performSelectionChangedUpdates();
  var canvas = n.contentDrawView();
  if (nativeDeveloperSupports(canvas, 'refreshSidebarWithMask:')) canvas.refreshSidebarWithMask(65535);
  if (nativeDeveloperSupports(n, 'updateScene')) n.updateScene();
  canvas.setNeedsDisplay(true);
}
function nativeDeveloperHit(d,x,y,deep) {
  var page=d.selectedPage.sketchObject,point=NSMakePoint(x,y),options=deep?2:0,hit;
  if(nativeDeveloperSupports(page,'hitTest:options:'))hit=page.hitTest_options(point,options);
  else {
    var canvas=d.sketchObject.contentDrawView(),zoom=nativeDeveloperSupports(canvas,'zoomValue')?Number(canvas.zoomValue()):1;
    hit=page.selectionHitTest_options_zoomValue(point,options,zoom);
  }
  return hit?sketch.fromNative(hit.layer()):null;
}
function nativeDeveloperLoadBundle(context) {
  devInitializeAvatar(context);
  // A matching revision may already be loaded from an installed or test copy.
  // Reuse it instead of registering the same Objective-C classes twice.
  var loaded=NSClassFromString('SMNativeDeveloperControllerV62');
  if(loaded)return loaded;
  var path = resource(context, 'NativeDeveloperV62.bundle');
  if (!NSFileManager.defaultManager().fileExistsAtPath(path)) throw new Error('缺少原生组件，请复制完整的 .sketchplugin 文件。');
  var bundle = NSBundle.bundleWithPath(path);
  if (!bundle) throw new Error('原生组件目录不完整，请重新安装。');
  var pointer = MOPointer.alloc().init();
  if (!bundle.loadAndReturnError(pointer)) {
    var reason = pointer.value();
    throw new Error('原生组件加载失败。' + (reason ? '\n' + String(reason.localizedDescription()) + '\n' + String(reason) : '请检查 macOS 版本和插件文件完整性。'));
  }
  var cls = NSClassFromString('SMNativeDeveloperControllerV62');
  if (!cls) throw new Error('原生组件不完整，找不到工具栏类。');
  return cls;
}
function nativeDeveloperState() { var c=NSThread.mainThread().threadDictionary()[NATIVE_DEV_KEY];if(c && Number(c.closed())){NSThread.mainThread().threadDictionary().removeObjectForKey(NATIVE_DEV_KEY);return null;}return c?{controller:c,document:sketch.fromNative(c.document())}:null; }
// Menu command and shortcut toggle the existing bar; preserve unsaved-comment confirmation.
function nativeDeveloperToggle(context) {
  var state=nativeDeveloperState();
  if(state){
    if(String(state.controller.className())!=='SMNativeDeveloperControllerV62')return nativeDeveloperOpen(context,false);
    nativeDeveloperCloseAll();return null;
  }
  return nativeDeveloperOpen(context,false);
}
function nativeDeveloperCloseAll() {
  var registered=nativeDeveloperDocuments().allValues(),controllers=[],i;
  for(i=0;i<Number(registered.count());i++)controllers.push(registered.objectAtIndex(i));
  var active=NSThread.mainThread().threadDictionary()[NATIVE_DEV_KEY];
  if(active&&!controllers.some(function(c){return c.isEqual(active);}))controllers.push(active);
  // Confirm every draft before closing any document's toolbar.
  for(i=0;i<controllers.length;i++)if(!controllers[i].canDiscardComment())return false;
  for(i=0;i<controllers.length;i++)controllers[i].shutdown();
  return true;
}
function nativeDeveloperFollow(context,controller) {
  var dict=NSThread.mainThread().threadDictionary(),active=dict[NATIVE_DEV_KEY];
  if(active && !active.isEqual(controller))return;
  var d=sketch.getSelectedDocument();
  if(!d || (active && String(sketch.fromNative(active.document()).id)===String(d.id)))return;
  nativeDeveloperOpen(context,active?Number(active.developer())!==0:false);
}
function nativeDeveloperRect(layer) {
  if(!nativeDeveloperSupports(layer.sketchObject,'alignmentRectInCoordinateSpace:'))throw new Error('当前 Sketch 缺少图层坐标接口。');
  var r=layer.sketchObject.alignmentRectInCoordinateSpace(layer.getParentPage().sketchObject);
  return {x:Number(r.origin.x),y:Number(r.origin.y),w:Number(r.size.width),h:Number(r.size.height)};
}
function nativeDeveloperPins(d) {
  return devNotes(d).map(function(note){
    var target=note.layerId && d.getLayerWithID(note.layerId),board=d.getLayerWithID(note.boardId.indexOf('page:')===0?note.boardId.slice(5):note.boardId);
    if(!board || (board.type==='Page'?board.id:board.getParentPage().id)!==d.selectedPage.id)return null;
    var br=board.type==='Page'?{x:0,y:0}:nativeDeveloperRect(board);
    var r=target?nativeDeveloperRect(target):br;
    return {id:note.id,x:target?r.x+r.w*number(note.u,.5):br.x+note.x,
      y:target?r.y+r.h*number(note.v,.5):br.y+note.y,initial:String(note.author||'注').slice(0,1),author:note.author,text:note.text,createdAt:note.createdAt,avatar:devSafeAvatar(note.avatar)};
  }).filter(function(n){return n;});
}
function nativeDeveloperSetCursorProfile(controller) {
  var profile=devProfile();
  controller.setCommentCursorAvatar_author(profile.avatar,profile.name);
  return JSON.stringify([profile.avatar,profile.name]);
}
function nativeDeveloperOpen(context,activate) {
  DELIVERY_PLUGIN_CONTEXT=context;
  devInitializeAvatar(context);
  var dict=NSThread.mainThread().threadDictionary(),state=nativeDeveloperState(),d=document(),sessions=nativeDeveloperDocuments();
  // A previously installed native class can remain alive until Sketch restarts.
  // Close it before registering the new controller, including its old callback.
  if(state&&String(state.controller.className())!=='SMNativeDeveloperControllerV62'){
    if(!nativeDeveloperCloseAll())return state;
    state=null;sessions=nativeDeveloperDocuments();
  }
  if(state && state.document.id===d.id){nativeDeveloperSetCursorProfile(state.controller);if(activate)state.controller.activate();return state;}
  var previous=state&&state.controller,existing=sessions.objectForKey(String(d.id));
  if(previous)previous.suspendForDocumentSwitch();
  if(existing && !Number(existing.closed())){nativeDeveloperSetCursorProfile(existing);dict[NATIVE_DEV_KEY]=existing;existing.tick();return {controller:existing,document:d};}
  var cls=nativeDeveloperLoadBundle(context),n=d.sketchObject;
  // Probe before calling private APIs; the version number alone is not a capability check.
  var compatibility=cls.compatibilityErrorForDocument(n);
  if(compatibility && String(compatibility).length)throw new Error(String(compatibility));
  var page=d.selectedPage && d.selectedPage.sketchObject;
  if(!nativeDeveloperSupports(page,'hitTest:options:')&&!nativeDeveloperSupports(page,'selectionHitTest:options:zoomValue:'))throw new Error('当前 Sketch 缺少图层命中接口，无法安全开启画布检查。');
  var canvas=n.contentDrawView();
  var controller=cls.alloc().initWithDocument(n);
  var lastCursorProfile=nativeDeveloperSetCursorProfile(controller);
  state={document:d,controller:controller};sessions.setObject_forKey(controller,String(d.id));dict[NATIVE_DEV_KEY]=controller;coscript.setShouldKeepAround(true);
  var lastPins='',lastSelection='';
  function refresh(){
    var cursorProfile=devProfile(),cursorKey=JSON.stringify([cursorProfile.avatar,cursorProfile.name]);
    if(cursorKey!==lastCursorProfile){controller.setCommentCursorAvatar_author(cursorProfile.avatar,cursorProfile.name);lastCursorProfile=cursorKey;}
    var pins=nativeDeveloperPins(d),p=JSON.stringify(pins);
    if(p!==lastPins){controller.setPins(pins);lastPins=p;}
    var selected=d.selectedLayers.layers.slice(0,2),rects=selected.map(nativeDeveloperRect),s=JSON.stringify(rects);
    if(s!==lastSelection){controller.setMeasureRects(rects);lastSelection=s;}
  }
  var desc=MOClassDescription.allocateDescriptionForClassWithName_superclass_('SMCanvasEvents'+String(NSUUID.UUID().UUIDString()).replace(/-/g,''),NSObject);
  desc.addInstanceMethodWithSelector_function_('developerEvent:',function(event){try{
    var raw=event;event={};['kind','id','layer','x','y','shift','deep','developer','op','text','author','boardId','layerId','u','v','replyId'].forEach(function(k){event[k]=raw.objectForKey(k);});var kind=String(event.kind);
    if(kind==='closed'){
      sessions.removeObjectForKey(String(d.id));
      if(dict[NATIVE_DEV_KEY]&&dict[NATIVE_DEV_KEY].isEqual(controller)){dict.removeObjectForKey(NATIVE_DEV_KEY);if(Number(sessions.count()))dict[NATIVE_DEV_KEY]=sessions.allValues().objectAtIndex(0);}
      if(!Number(sessions.count())){dict.removeObjectForKey(NATIVE_DEV_DOCUMENTS_KEY);coscript.setShouldKeepAround(false);}
      return;
    }
    if(kind==='requestClose'){nativeDeveloperCloseAll();return;}
    if(kind==='focus'){nativeDeveloperFollow(context,controller);return;}
    if(kind==='tick'){nativeDeveloperFollow(context,controller);refresh();return;}
    if(kind==='contextLayer'){
      var target=event.layer?sketch.fromNative(event.layer):nativeDeveloperHit(d,Number(event.x),Number(event.y),Number(event.deep)!==0);
      if(target&&d.selectedLayers.layers.every(function(layer){return layer.id!==target.id;})){d.selectedLayers.layers=[target];nativeDeveloperRefresh(n);refresh();}return;
    }
    if(kind==='mode'){nativeDeveloperRefresh(n);refresh();return;}
    if(kind==='mark'){if(!Number(controller.developer())){var actions={area:commandOverlays,width:commandWidths,height:commandHeights,spacing:commandSpacings,marginLeft:commandLeftMargins,marginRight:commandRightMargins,marginTop:commandTopMargins,marginBottom:commandBottomMargins,properties:commandProperties};var action=actions[String(event.id)];if(action){action();flushDocumentChanges(d);nativeDeveloperRefresh(n);}}return;}
    if(kind==='settings'){if(!Number(controller.developer()))commandSettings(context);refresh();return;}
    if(kind==='export'){if(!Number(controller.developer())){if(String(event.id)==='selected-board')commandExportSelectedBoard(context);else if(String(event.id)==='page')commandExport(context);else if(String(event.id)==='all')commandExportAllPages(context);}return;}
    if(kind==='moveComment'){
      if(Number(controller.developer()))return;
      var notes=devNotes(d),index=notes.map(function(note){return note.id;}).indexOf(String(event.id));
      if(index>=0){var anchor=nativeDeveloperAddDraft(d,Number(event.x),Number(event.y));['boardId','pageId','layerId','x','y','u','v'].forEach(function(key){notes[index][key]=anchor[key];});notes[index].updatedAt=new Date().toISOString();devStoreNotes(d,notes);flushDocumentChanges(d);refresh();}
      return;
    }
    if(kind==='addComment'){
      if(Number(controller.developer()))return;
      controller.showThreadJSON(JSON.stringify(nativeDeveloperAddDraft(d,Number(event.x),Number(event.y))));return;
    }
    if(kind==='saveComment'){
      if(Number(controller.developer()))return;
      try{var saved=nativeDeveloperSaveNote(d,event);if(saved){controller.showThreadJSON(JSON.stringify(devComposeProfile(saved)));}else controller.closeComment();refresh();UI.message('标注已更新，保存 Sketch 文档后即可随文件共享。');}catch(error){UI.message(String(error.message||error));}return;
    }
    if(kind==='comment'){
      var note=devNotes(d).filter(function(n){return n.id===String(event.id);})[0];
      if(note){controller.showThreadJSON(JSON.stringify(devComposeProfile(note)));}return;
    }
    var layer=null;
    if(kind==='select'){
      layer=nativeDeveloperHit(d,Number(event.x),Number(event.y),Number(event.deep)!==0);
    }else if(kind==='layer'){layer=sketch.fromNative(event.layer);}
    else if(kind==='page'){
      var page=sketch.fromNative(event.layer);if(page.type==='Page'){d.selectedPage=page;nativeDeveloperRefresh(n);refresh();}return;
    }
    if(kind==='select'||kind==='layer'){
      var existing=(Number(event.shift)!==0)?d.selectedLayers.layers.slice():[];
      if(layer){var index=existing.map(function(l){return l.id;}).indexOf(layer.id);if(index>=0)existing.splice(index,1);else existing.push(layer);}
      d.selectedLayers.layers=existing;
      nativeDeveloperRefresh(n);
      refresh();
    }
  }catch(error){console.error('Native developer: '+String(error.stack||error));}});
  desc.registerClass();controller.setEventDelegate(NSClassFromString(desc.name()).alloc().init());
  try { refresh();if(activate)controller.activate();return state; }
  catch(error){controller.shutdown();if(previous&&!Number(previous.closed()))dict[NATIVE_DEV_KEY]=previous;throw error;}
}
function commandDeveloperToolbar(context) {run(function(){nativeDeveloperOpen(context,false);});}
function nativeDeveloperAddDraft(d,x,y){
  var layer=nativeDeveloperHit(d,x,y,true);
  var b=layer;while(b && b.type!=='Page' && !isBoard(b))b=b.parent;
  if(b && b.type!=='Page'){var ancestor=b.parent;while(ancestor && ancestor.type!=='Page'){if(isBoard(ancestor))b=ancestor;ancestor=ancestor.parent;}}
  var boardId=b&&isBoard(b)?String(b.id):'page:'+String(d.selectedPage.id),br=b&&isBoard(b)?nativeDeveloperRect(b):{x:0,y:0};
  var r=layer?nativeDeveloperRect(layer):null;
  return {boardId:boardId,pageId:String(d.selectedPage.id),layerId:layer?String(layer.id):'',x:x-br.x,y:y-br.y,u:r&&r.w?(x-r.x)/r.w:.5,v:r&&r.h?(y-r.y)/r.h:.5,
    pageX:x,pageY:y,author:devProfile().name,avatar:devProfile().avatar,composerAuthor:devProfile().name,composerAvatar:devProfile().avatar,text:''};
}
function nativeDeveloperSaveNote(d,payload){
  var notes=devNotes(d),op=String(payload.op),index=notes.map(function(n){return n.id;}).indexOf(String(payload.id||''));
  if(['add','update','delete','reply','updateReply','deleteReply'].indexOf(op)<0)throw new Error('无效的注释操作。');
  if(op!=='add'&&index<0)throw new Error('这条标注已经被删除。请关闭标注窗口，选择其他标注后再操作。');
  if(op==='delete')notes.splice(index,1);
  else{
    var replyIndex=-1;
    if(op==='updateReply'||op==='deleteReply'){replyIndex=(notes[index].replies||[]).map(function(r){return r.id;}).indexOf(String(payload.replyId));if(replyIndex<0)throw new Error('这条回复已经被删除。请重新打开标注，查看最新内容。');}
    if(op==='deleteReply'){notes[index].replies.splice(replyIndex,1);notes[index].updatedAt=new Date().toISOString();devStoreNotes(d,notes);flushDocumentChanges(d);return notes[index];}
    var author=String(payload.author||'').trim(),text=String(payload.text||'').trim();
    if(!author||author.length>80)throw new Error(!author?'请填写标注名字，方便同事识别你的标注。':'标注名字超过了 80 个字，请缩短后再保存。');
    if(!text||text.length>10000)throw new Error(!text?'请先填写标注内容，再点击保存。':'标注内容超过了 10000 个字，请精简或分成多条标注后保存。');
    var now=new Date().toISOString();
    if(op==='reply'||op==='updateReply'){
      if(!notes[index].replies)notes[index].replies=[];
      if(op==='reply'){if(notes[index].replies.length>=500)throw new Error('这条标注已有 500 条回复，无法继续追加。可以新建一条标注继续讨论。');notes[index].replies.push({id:String(NSUUID.UUID().UUIDString()),author:author,avatar:devProfile().avatar,text:text,createdAt:now,updatedAt:now});}
      else{notes[index].replies[replyIndex].author=author;notes[index].replies[replyIndex].text=text;notes[index].replies[replyIndex].updatedAt=now;}
      notes[index].updatedAt=now;
    }
    else if(op==='update'){notes[index].author=author;notes[index].text=text;notes[index].updatedAt=now;}
    else{
      if(notes.length>=5000)throw new Error('当前文档已有 5000 条标注，无法继续添加。可以整理不再需要的标注，或在另一份文档中继续。');
      var boardId=String(payload.boardId||''),board=d.getLayerWithID(boardId.indexOf('page:')===0?boardId.slice(5):boardId);
      if(!board||!isFinite(Number(payload.x))||!isFinite(Number(payload.y)))throw new Error('暂时无法确定标注位置。请关闭标注窗口，在画布上重新点击需要标注的位置。');
      notes.push({id:String(NSUUID.UUID().UUIDString()),boardId:boardId,pageId:String((board.type==='Page'?board:board.getParentPage()).id),layerId:String(payload.layerId||''),x:Number(payload.x),y:Number(payload.y),u:Number(payload.u),v:Number(payload.v),author:author,avatar:devProfile().avatar,text:text,createdAt:now,updatedAt:now,resolved:false});
    }
    Settings.setSettingForKey('measure.zh-modern.note-author',author);
  }
  devStoreNotes(d,notes);flushDocumentChanges(d);return op==='delete'?null:notes[op==='add'?notes.length-1:index];
}
