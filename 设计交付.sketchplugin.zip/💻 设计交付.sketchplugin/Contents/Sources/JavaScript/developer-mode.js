var DEV_PROFILE_KEY = 'measure.zh-modern.profile.v1';
var DEV_DEFAULT_AVATAR = '';
var DEV_VALIDATED_AVATARS = [];
function devInitializeAvatar(context) {
  if (DEV_DEFAULT_AVATAR) return;
  var data=NSData.dataWithContentsOfFile(resource(context,'default-avatar.png'));
  if(!data)throw new Error('默认头像资源缺失，请安装完整插件。');
  DEV_DEFAULT_AVATAR='data:image/png;base64,'+String(data.base64EncodedStringWithOptions(0));
  if(!devAvatarDataValid(DEV_DEFAULT_AVATAR))throw new Error('默认头像资源损坏，请重新复制完整插件。');
}
function devAvatarDataValid(value) {
  if(!/^data:image\/(png|jpeg);base64,[A-Za-z0-9+/=]+$/.test(value)||value.length>150000)return false;
  var encoded=value.slice(value.indexOf(',')+1),alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',bytes=[],bits=0,buffer=0;
  if(encoded.length%4)return false;
  for(var i=0;i<encoded.length;i++){var c=encoded.charAt(i);if(c==='=')break;var digit=alphabet.indexOf(c);if(digit<0)return false;buffer=(buffer<<6)|digit;bits+=6;if(bits>=8){bits-=8;bytes.push((buffer>>>bits)&255);}}
  if(value.indexOf('image/jpeg')>=0)return bytes.length>4&&bytes[0]===255&&bytes[1]===216&&bytes[bytes.length-2]===255&&bytes[bytes.length-1]===217;
  if(bytes.slice(0,8).join(',')!=='137,80,78,71,13,10,26,10')return false;
  function uint32(offset){return ((bytes[offset]*16777216)+(bytes[offset+1]<<16)+(bytes[offset+2]<<8)+bytes[offset+3])>>>0;}
  var offset=8,hasPixels=false,first=true;
  while(offset+12<=bytes.length){var length=uint32(offset),end=offset+8+length;if(end+4>bytes.length)return false;var type=String.fromCharCode.apply(null,bytes.slice(offset+4,offset+8));if(first&&(type!=='IHDR'||length!==13))return false;first=false;var crc=0xffffffff;for(var n=offset+4;n<end;n++){crc^=bytes[n];for(var bit=0;bit<8;bit++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}if(((crc^0xffffffff)>>>0)!==uint32(end))return false;if(type==='IDAT')hasPixels=true;if(type==='IEND')return hasPixels&&length===0&&end+4===bytes.length;offset=end+4;}
  return false;
}
function devSafeAvatar(value) {
  value=String(value||'');if(!value)return '';
  if(value===DEV_DEFAULT_AVATAR||DEV_VALIDATED_AVATARS.indexOf(value)>=0)return value;
  if(!devAvatarDataValid(value))return DEV_DEFAULT_AVATAR;
  var cls=NSClassFromString('SMNativeDeveloperControllerV62');
  if(cls&&!cls.isAvatarDataValid(value))return DEV_DEFAULT_AVATAR;
  DEV_VALIDATED_AVATARS.push(value);if(DEV_VALIDATED_AVATARS.length>32)DEV_VALIDATED_AVATARS.shift();return value;
}
function devProfile() {
  var saved=Settings.settingForKey(DEV_PROFILE_KEY)||{};
  return {name:String(saved.name||'执手听风丶'),avatar:devSafeAvatar(saved.avatar)||DEV_DEFAULT_AVATAR};
}
function devComposeProfile(note) { var p=devProfile();note.composerAuthor=p.name;note.composerAvatar=p.avatar;return note; }
// Document metadata is the only writable surface exposed by the inspector.
var DEV_NOTE_KEY = 'measure.zh-modern.annotations.v1';
var DEV_NOTE_NAMESPACE = 'com.utom.measure.zh-modern';
function devNoteDocumentData(d) { return d.sketchObject.documentData(); }
function devNotes(d) {
  // Native callbacks must not depend on the active plugin command namespace.
  var info=devNoteDocumentData(d).userInfo(),value=null;
  [DEV_NOTE_NAMESPACE,'com.utom.measure.zh-modern.native','com.sketchapp.temporary-script'].some(function(namespace){
    var group=info&&info.objectForKey(namespace),raw=group&&group.objectForKey(DEV_NOTE_KEY);
    if(raw!=null){value=JSON.parse(String(raw));return true;}return false;
  });
  if(value==null)value=Settings.documentSettingForKey(d,DEV_NOTE_KEY);
  if (!value) return [];
  if (value.version !== 1 || !Array.isArray(value.notes)) throw deliveryError('暂时无法读取这些标注','文档中的标注由其他版本保存。请先备份设计稿，再使用创建这些标注时的插件版本打开，避免覆盖原有内容。');
  var notes=JSON.parse(JSON.stringify(value.notes));
  notes.forEach(function(note){note.avatar=devSafeAvatar(note.avatar);(note.replies||[]).forEach(function(reply){reply.avatar=devSafeAvatar(reply.avatar);});});
  return notes;
}
function devStoreNotes(d, notes) {
  var data=devNoteDocumentData(d),original=data.userInfo();
  var info=original?original.mutableCopy():NSMutableDictionary.dictionary();
  var existing=info.objectForKey(DEV_NOTE_NAMESPACE);
  var group=existing?existing.mutableCopy():NSMutableDictionary.dictionary();
  var serialized=JSON.stringify({version:1,notes:notes});
  if(String(group.objectForKey(DEV_NOTE_KEY)||'')===serialized)return;
  group.setObject_forKey(serialized,DEV_NOTE_KEY);info.setObject_forKey(group,DEV_NOTE_NAMESPACE);
  data.setUserInfo(info);
  // Metadata alone does not mark NSDocument edited. Register it for Save/Close.
  flushDocumentChanges(d);
  d.sketchObject.updateChangeCount(NSChangeDone);
}
function devNotePageID(d,note) {
  var id=String(note.boardId||'');
  if(id.indexOf('page:')===0)return id.slice(5);
  var board=d.getLayerWithID(id),page=board&&(board.type==='Page'?board:board.getParentPage());
  return page?String(page.id):String(note.pageId||'');
}
function devDeleteNotes(d,scope) {
  if(scope!=='all'&&scope!=='page')throw new Error('无效的标注删除范围。');
  var notes=devNotes(d),pageId=String(d.selectedPage.id);
  var remaining=scope==='all'?[]:notes.filter(function(note){return devNotePageID(d,note)!==pageId;});
  var count=notes.length-remaining.length;
  if(count)devStoreNotes(d,remaining);
  return count;
}
function commandDeleteNotes(context,scope) { return run(function(){
  var d=document(),controller=nativeDeveloperDocuments().objectForKey(String(d.id));
  if(controller&&!Number(controller.closed())&&Number(controller.developer()))throw deliveryError('请先切换到设计模式','开发模式用于查看设计稿。请在交付工具栏中切换到“设计模式”，再删除标注。');
  var notes=devNotes(d),count=notes.filter(function(note){return scope==='all'||devNotePageID(d,note)===String(d.selectedPage.id);}).length;
  if(!count){UI.message(scope==='all'?'当前文档没有标注。':'当前页面没有标注。');return;}
  if(controller&&!Number(controller.closed())&&!controller.canDiscardComment())return;
  var title=scope==='all'?'删除全部标注':'删除当前页面标注';
  if(deliveryAlert(title+'？','将删除'+(scope==='all'?'当前文档':'当前页面')+'中的 '+count+' 条标注及其全部回复。此操作无法撤销，请确认后再删除。',['取消','删除标注'],0,context)!==1)return;
  devDeleteNotes(d,scope);
  if(controller&&!Number(controller.closed())){controller.closeComment();controller.setPins(nativeDeveloperPins(d));}
  UI.message('已删除 '+count+' 条标注及其全部回复。');
}); }
function devAttachAnnotations(d, project) {
  var notes = devNotes(d);
  project.artboards.forEach(function (board) {
    board.annotations = notes.filter(function (note) { return note.boardId === String(board.objectID); }).map(function (note) {
      var result = JSON.parse(JSON.stringify(note));
      var target = board.layers.filter(function (l) { return (String(l.objectID) === note.layerId || String(l.labNativeID || '') === note.layerId); })[0];
      if (target) {
        result.layerId = String(target.objectID);
        var r = target.selectionRect || target.logicalRect || target.rect;
        result.x = r.x + r.width * number(note.u, .5); result.y = r.y + r.height * number(note.v, .5);
      } else {
        if (note.layerId) result.detached = true;
        if (board.virtualOrigin) { result.x += number(note.originX)-board.virtualOrigin.x; result.y += number(note.originY)-board.virtualOrigin.y; }
      }
      result.x = Math.max(0, Math.min(board.width, number(result.x)));
      result.y = Math.max(0, Math.min(board.height, number(result.y)));
      return result;
    });
  });
}
