#import <Cocoa/Cocoa.h>
#import <QuartzCore/QuartzCore.h>
#import <ImageIO/ImageIO.h>
#import "ToolbarIcons.h"
static BOOL SMDark(NSView *v){return [[v.effectiveAppearance bestMatchFromAppearancesWithNames:@[NSAppearanceNameAqua,NSAppearanceNameDarkAqua]]isEqualToString:NSAppearanceNameDarkAqua];}
// Resolve Sketch's own theme tokens when available; older hosts fall back to AppKit.
static id SMHostTheme(void){Class cls=NSClassFromString(@"MSTheme");SEL sel=NSSelectorFromString(@"sharedTheme");if(![cls respondsToSelector:sel])return nil;return ((id(*)(id,SEL))[cls methodForSelector:sel])(cls,sel);}
static NSColor *SMThemeColor(NSString *name,NSColor *fallback){id theme=SMHostTheme();SEL sel=NSSelectorFromString(@"colorNamed:");if([theme respondsToSelector:sel]){id value=((id(*)(id,SEL,id))[theme methodForSelector:sel])(theme,sel,name);if([value isKindOfClass:NSColor.class])return value;}return fallback;}
static NSColor *SMAccent(void){id theme=SMHostTheme();SEL sel=NSSelectorFromString(@"inspectorAccentColor");if([theme respondsToSelector:sel]){id value=((id(*)(id,SEL))[theme methodForSelector:sel])(theme,sel);if([value isKindOfClass:NSColor.class])return value;}return NSColor.controlAccentColor;}
static NSColor *SMInk(NSView *v){
 __block NSColor *ink;[v.effectiveAppearance performAsCurrentDrawingAppearance:^{
  ink=[SMThemeColor(@"inspector-label-text",NSColor.labelColor) colorUsingColorSpace:NSColorSpace.sRGBColorSpace];
  CGFloat brightness=ink?.2126*ink.redComponent+.7152*ink.greenComponent+.0722*ink.blueComponent:0;
  // Legacy Sketch themes may lag behind a window's appearance change.
  if(!ink||(SMDark(v)?brightness<.5:brightness>.5))ink=[NSColor.labelColor colorUsingColorSpace:NSColorSpace.sRGBColorSpace];
 }];return ink;
}
static NSColor *SMInspectorBackground(NSView *root){
 // The inspector's own surface is independent of page and canvas colors.
 if([root isKindOfClass:NSScrollView.class]&&[NSStringFromClass(root.class) rangeOfString:@"Inspector" options:NSCaseInsensitiveSearch].location!=NSNotFound)return ((NSScrollView *)root).backgroundColor;
 for(NSView *child in root.subviews){NSColor *color=SMInspectorBackground(child);if(color)return color;}return nil;
}
static NSColor *SMToolbarBackground(NSView *v){
 NSColor *color=[NSColor colorNamed:@"clr-inspector-background" bundle:NSBundle.mainBundle];
 if(!color)color=SMInspectorBackground(v.window.contentView);
 if(!color)color=SMThemeColor(SMDark(v)?@"inspector-background-dark":@"inspector-background",SMDark(v)?NSColor.windowBackgroundColor:NSColor.whiteColor);
 __block NSColor *resolved;[v.effectiveAppearance performAsCurrentDrawingAppearance:^{resolved=[color colorUsingColorSpace:NSColorSpace.sRGBColorSpace];}];return resolved?:color;
}
static NSColor *SMBackground(NSView *v){return SMDark(v)?[NSColor colorWithSRGBRed:.15 green:.16 blue:.18 alpha:1]:NSColor.whiteColor;}
static NSColor *SMCommentSecondary(void){static NSColor *color;static dispatch_once_t once;dispatch_once(&once,^{color=[NSColor colorWithName:@"SMCommentSecondary" dynamicProvider:^NSColor *(NSAppearance *appearance){BOOL dark=[[appearance bestMatchFromAppearancesWithNames:@[NSAppearanceNameAqua,NSAppearanceNameDarkAqua]]isEqualToString:NSAppearanceNameDarkAqua];return dark?[NSColor colorWithSRGBRed:.68 green:.70 blue:.74 alpha:1]:[NSColor colorWithSRGBRed:.38 green:.41 blue:.46 alpha:1];}];});return color;}
static BOOL SMAvatarPNGComplete(NSData *data){
 const unsigned char *bytes=data.bytes;NSUInteger count=data.length;if(count<8||memcmp(bytes,"\x89PNG\r\n\x1a\n",8))return NO;BOOL pixels=NO,first=YES;
 for(NSUInteger offset=8;offset+12<=count;){uint32_t size=((uint32_t)bytes[offset]<<24)|((uint32_t)bytes[offset+1]<<16)|((uint32_t)bytes[offset+2]<<8)|bytes[offset+3];if(size>count-offset-12)return NO;NSUInteger end=offset+8+size;if(first&&(memcmp(bytes+offset+4,"IHDR",4)||size!=13))return NO;first=NO;uint32_t crc=0xffffffff;for(NSUInteger n=offset+4;n<end;n++){crc^=bytes[n];for(int bit=0;bit<8;bit++)crc=(crc>>1)^((crc&1)?0xedb88320:0);}uint32_t stored=((uint32_t)bytes[end]<<24)|((uint32_t)bytes[end+1]<<16)|((uint32_t)bytes[end+2]<<8)|bytes[end+3];if((crc^0xffffffff)!=stored)return NO;if(!memcmp(bytes+offset+4,"IDAT",4))pixels=YES;if(!memcmp(bytes+offset+4,"IEND",4))return pixels&&size==0&&end+4==count;offset=end+4;}return NO;
}
static NSImage *SMAvatarImage(NSString *value) {
 if(![value isKindOfClass:NSString.class]||value.length>150000||(![value hasPrefix:@"data:image/png;base64,"]&&![value hasPrefix:@"data:image/jpeg;base64,"]))return nil;
 static NSCache *cache;static dispatch_once_t once;dispatch_once(&once,^{cache=[NSCache new];cache.countLimit=128;});NSImage *image=[cache objectForKey:value];if(image)return image;
 NSRange comma=[value rangeOfString:@","];NSData *data=[[NSData alloc]initWithBase64EncodedString:[value substringFromIndex:comma.location+1] options:0];if(!data||([value hasPrefix:@"data:image/png;"]&&!SMAvatarPNGComplete(data)))return nil;
 CGImageSourceRef source=CGImageSourceCreateWithData((__bridge CFDataRef)data,NULL);if(!source)return nil;CGImageRef pixels=CGImageSourceCreateImageAtIndex(source,0,(__bridge CFDictionaryRef)@{(id)kCGImageSourceShouldCacheImmediately:@YES});BOOL complete=CGImageSourceGetStatus(source)==kCGImageStatusComplete&&CGImageSourceGetStatusAtIndex(source,0)==kCGImageStatusComplete;CFRelease(source);if(!pixels||!complete){if(pixels)CGImageRelease(pixels);return nil;}
 NSBitmapImageRep *bitmap=[[NSBitmapImageRep alloc]initWithCGImage:pixels];CGImageRelease(pixels);image=[[NSImage alloc]initWithSize:bitmap.size];[image addRepresentation:bitmap];[cache setObject:image forKey:value];return image;
}
static void SMDrawAvatar(NSString *value,NSString *initial,NSRect rect,BOOL flipped) {
 [NSGraphicsContext saveGraphicsState];[[NSBezierPath bezierPathWithOvalInRect:rect]addClip];NSImage *image=SMAvatarImage(value);
 if(image){NSSize size=image.size;CGFloat edge=MIN(size.width,size.height);[image drawInRect:rect fromRect:NSMakeRect((size.width-edge)/2,(size.height-edge)/2,edge,edge) operation:NSCompositingOperationSourceOver fraction:1 respectFlipped:YES hints:nil];}
 else{[[NSColor colorWithSRGBRed:0 green:.40 blue:.88 alpha:1]setFill];NSRectFill(rect);NSDictionary *attrs=@{NSFontAttributeName:[NSFont systemFontOfSize:15 weight:NSFontWeightSemibold],NSForegroundColorAttributeName:NSColor.whiteColor};NSSize size=[initial sizeWithAttributes:attrs];[initial drawAtPoint:NSMakePoint(NSMidX(rect)-size.width/2,NSMidY(rect)-size.height/2) withAttributes:attrs];}
 [NSGraphicsContext restoreGraphicsState];
}
static NSString *SMRelativeTime(NSString *value) {
 NSISO8601DateFormatter *parser=[NSISO8601DateFormatter new];parser.formatOptions=NSISO8601DateFormatWithInternetDateTime|NSISO8601DateFormatWithFractionalSeconds;NSDate *date=[parser dateFromString:value?:@""];if(!date){parser.formatOptions=NSISO8601DateFormatWithInternetDateTime;date=[parser dateFromString:value?:@""];}if(!date)return @"";
 NSTimeInterval elapsed=MAX(0,-date.timeIntervalSinceNow);if(elapsed<60)return @"刚刚";if(elapsed<3600)return [NSString stringWithFormat:@"%ld 分钟前",(long)(elapsed/60)];if(elapsed<86400)return [NSString stringWithFormat:@"%ld 小时前",(long)(elapsed/3600)];if(elapsed<604800)return [NSString stringWithFormat:@"%ld 天前",(long)(elapsed/86400)];NSDateFormatter *formatter=[NSDateFormatter new];formatter.dateFormat=@"yyyy/MM/dd";return [formatter stringFromDate:date];
}
// Only these read/navigation methods are called on Sketch objects.
@interface NSObject (SMReadOnlySketch)
- (void)developerEvent:(NSDictionary *)event;
- (NSWindow *)documentWindow;
- (NSView *)contentDrawView;
- (id)currentPage;
- (id)hitTest:(NSPoint)p options:(NSUInteger)options;
- (id)layer;
- (id)page;
- (NSString *)name;
- (BOOL)isCurrent;
- (id)eventHandlerManager;
- (id)normalHandler;
- (void)resetToIdle;
- (NSPoint)convertPointToPage:(NSPoint)p;
- (NSPoint)convertPointFromPage:(NSPoint)p;
- (void)scrollBy:(NSPoint)p;
- (void)zoomIn;
- (void)zoomOut;
- (void)centerLayersInCanvas;
@end
static BOOL SMCurrent(id document,NSWindow *window){return [document respondsToSelector:@selector(isCurrent)]?[document isCurrent]:(window.isKeyWindow||window.isMainWindow);}
// Older Sketch releases expose only page-to-canvas conversion. Invert its affine
// transform instead of assuming a zoom factor or depending on scroll-origin internals.
static NSPoint SMPagePoint(NSView *canvas,NSPoint point){
 if([canvas respondsToSelector:@selector(convertPointToPage:)])return [(id)canvas convertPointToPage:point];
 NSPoint origin=[(id)canvas convertPointFromPage:NSZeroPoint],x=[(id)canvas convertPointFromPage:NSMakePoint(1,0)],y=[(id)canvas convertPointFromPage:NSMakePoint(0,1)];
 double a=x.x-origin.x,b=y.x-origin.x,c=x.y-origin.y,d=y.y-origin.y,det=a*d-b*c;
 if(!isfinite(det)||fabs(det)<1e-12)return NSMakePoint(NAN,NAN);
 double px=point.x-origin.x,py=point.y-origin.y;return NSMakePoint((d*px-b*py)/det,(a*py-c*px)/det);
}
// Explicit layout avoids AppKit symbol/template tint and title spacing differences.
@interface SMToolbarButtonV62 : NSButton
@property(nonatomic) BOOL activeStyle;
@end
@implementation SMToolbarButtonV62
- (void)drawRect:(NSRect)dirty {NSColor *ink=_activeStyle?NSColor.whiteColor:SMInk(self);if(_activeStyle){[SMAccent() setFill];[[NSBezierPath bezierPathWithRoundedRect:self.bounds xRadius:10 yRadius:10]fill];}
 NSDictionary *attrs=@{NSFontAttributeName:self.font?:[NSFont systemFontOfSize:13 weight:NSFontWeightMedium],NSForegroundColorAttributeName:ink};NSSize text=[self.title sizeWithAttributes:attrs];CGFloat icon=self.image?22:0,gap=(icon&&self.title.length)?8:0,total=icon+gap+text.width,x=(self.bounds.size.width-total)/2;
 if(self.image)[self.image drawInRect:NSMakeRect(x,(self.bounds.size.height-icon)/2,icon,icon) fromRect:NSZeroRect operation:NSCompositingOperationSourceOver fraction:1 respectFlipped:YES hints:nil];
 if(self.title.length)[self.title drawAtPoint:NSMakePoint(x+icon+gap,(self.bounds.size.height-text.height)/2) withAttributes:attrs];
}
@end
#import "SurfaceShadow.h"
#import "DeliveryDialogs.h"
#import "ExportChoices.h"
#import "CommentComponents.h"
@class SMNativeDeveloperControllerV62;
@interface SMToolbarGripV62 : NSView
@property(nonatomic,weak) SMNativeDeveloperControllerV62 *owner;
@property(nonatomic) NSPoint dragOffset;
@end
@interface SMPinViewV62 : NSView
@property(nonatomic,weak) SMNativeDeveloperControllerV62 *owner;
@property(nonatomic,strong) NSDictionary *note;
@property(nonatomic) BOOL expanded,active;
@property(nonatomic) NSInteger relativeBucket;
@property(nonatomic,strong) NSTrackingArea *hoverTracking;
@end
@interface SMDeveloperShieldV62 : NSView <NSDraggingDestination>
@property(nonatomic,weak) SMNativeDeveloperControllerV62 *owner;
@end
@interface SMNativeDeveloperControllerV62 : NSObject <NSTextViewDelegate,NSTextFieldDelegate,SMExportChoicesDelegateV62>
@property(nonatomic,strong) id document;
@property(nonatomic,strong) NSWindow *window;
@property(nonatomic,strong) NSView *canvas;
@property(nonatomic,strong) SMDeveloperShieldV62 *shield;
@property(nonatomic,strong) NSView *bar;
@property(nonatomic,strong) NSButton *exportButton;
@property(nonatomic,strong) NSPopover *exportPopover;
@property(nonatomic,strong) SMToolbarGripV62 *grip;
@property(nonatomic) BOOL toolbarMoved,toolbarDragging;
@property(nonatomic) NSPoint toolbarAnchor;
@property(nonatomic,strong) NSButton *pointerButton,*handButton,*commentButton,*designButton,*devButton;
@property(nonatomic) BOOL commentTool;
@property(nonatomic,copy) NSString *commentCursorAvatar,*commentCursorInitial;
@property(nonatomic,strong) NSArray *designTools;
@property(nonatomic,strong) NSMapTable *buttonIcons;
@property(nonatomic,strong) NSView *modeDivider;
@property(nonatomic,strong) NSArray *designOnlyButtons;
@property(nonatomic,strong) NSView *deliveryDivider;
@property(nonatomic) BOOL hasLayout,lastLayoutDeveloper,layoutInFlight,compactLayout;
@property(nonatomic) NSUInteger layoutGeneration;
@property(nonatomic,copy) NSString *paletteName;
@property(nonatomic,strong) NSTextView *editorText;
@property(nonatomic,strong) NSTextField *editorAuthor;
@property(nonatomic,strong) NSDictionary *pendingComment;
@property(nonatomic,copy) NSString *editingReplyID,*editorBaseline,*authorBaseline;
@property(nonatomic,strong) NSButton *submitCommentButton,*cancelEditButton;
@property(nonatomic,strong) NSTextField *composerTitle;
@property(nonatomic,strong) id eventDelegate;
- (void)emit:(NSDictionary *)event;
@property(nonatomic,strong) id eventMonitor;
@property(nonatomic,strong) NSTimer *timer,*displayTimer;
@property(nonatomic,strong) NSMenu *originalMenu,*restrictedMenu;
@property(nonatomic,strong) NSArray *pins;
@property(nonatomic,strong) NSMutableDictionary *pinViews;
@property(nonatomic,strong) NSArray *measureRects;
@property(nonatomic,strong) NSArray *overlayState;
@property(nonatomic,strong) NSView *card;
@property(nonatomic) BOOL developer, hand, spaceDown,closed;
@property(nonatomic) NSPoint lastDrag;
@property(nonatomic) BOOL panning;
@property(nonatomic,copy) NSString *pinPressID;
@property(nonatomic,copy) NSString *selectedPinID;
@property(nonatomic,strong) NSTimer *pinLongPressTimer;
@property(nonatomic) BOOL pinMoveActive,pinMoved;
@property(nonatomic) NSPoint pinMovePoint,pinDragOffset;
- (void)beginPinPress:(NSDictionary *)pin;
- (void)dragPinToPagePoint:(NSPoint)point;
- (void)redrawCanvasOverlay;
- (void)syncPinViews;
- (NSMenu *)nativeCopyMenuForEvent:(NSEvent *)event;
- (void)selectContextLayerForEvent:(NSEvent *)event;
- (void)copySelection:(id)sender;
- (NSEvent *)filteredEvent:(NSEvent *)event;
- (BOOL)blocksNativeToolbarClick:(NSEvent *)event;
- (NSRect)toolbarFrameForWidth:(CGFloat)width;
- (void)moveToolbarToOrigin:(NSPoint)origin;
+ (NSString *)avatarDataForFile:(NSString *)path;
+ (BOOL)isAvatarDataValid:(NSString *)value;
- (void)setCommentCursorAvatar:(NSString *)avatar author:(NSString *)author;
- (void)startPinDrag;
- (void)finishPinPress;
+ (NSString *)compatibilityErrorForDocument:(id)document;
- (instancetype)initWithDocument:(id)document;
- (void)activate;
- (void)setDesign;
- (NSImage *)lineIcon:(NSString *)name color:(NSColor *)color;
- (void)refreshButtons;
- (void)applyPalette;
- (BOOL)canDiscardComment;
- (void)closeComment;
- (void)updateCommentSubmit;
- (void)shutdown;
- (void)suspendForDocumentSwitch;
- (BOOL)isNativeExportView:(NSView *)view;
- (NSView *)nativeExportHitAtPoint:(NSPoint)point;
- (NSView *)underlyingHitAtWindowPoint:(NSPoint)point;
- (void)showExportChoices:(id)sender;
- (void)dismissExportChoices;
- (void)exportChoice:(NSButton *)sender;
- (void)tick;
@end
@implementation SMToolbarGripV62
- (BOOL)isFlipped {return YES;}
- (void)resetCursorRects {[self addCursorRect:self.bounds cursor:NSCursor.openHandCursor];}
- (BOOL)isAccessibilityElement {return YES;}
- (NSString *)accessibilityRole {return NSAccessibilityHandleRole;}
- (NSString *)accessibilityLabel {return @"拖动交付工具栏";}
- (void)mouseDown:(NSEvent *)event {SMNativeDeveloperControllerV62 *c=_owner;if(c.layoutInFlight)return;[c dismissExportChoices];c.toolbarDragging=YES;NSPoint p=[c.shield convertPoint:event.locationInWindow fromView:nil];_dragOffset=NSMakePoint(p.x-c.bar.frame.origin.x,p.y-c.bar.frame.origin.y);[NSCursor.closedHandCursor set];}
- (void)mouseDragged:(NSEvent *)event {if(!_owner.toolbarDragging)return;NSPoint p=[_owner.shield convertPoint:event.locationInWindow fromView:nil];[_owner moveToolbarToOrigin:NSMakePoint(p.x-_dragOffset.x,p.y-_dragOffset.y)];}
- (void)mouseUp:(NSEvent *)event {_owner.toolbarDragging=NO;[NSCursor.openHandCursor set];}
- (void)drawRect:(NSRect)dirty {[[SMInk(self)colorWithAlphaComponent:.45]setFill];for(NSUInteger x=0;x<2;x++)for(NSUInteger y=0;y<3;y++)[[NSBezierPath bezierPathWithOvalInRect:NSMakeRect(9+x*5,13+y*6,2,2)]fill];}
@end
@implementation SMPinViewV62
- (BOOL)isFlipped {return YES;}
- (void)resetCursorRects {[self addCursorRect:self.bounds cursor:NSCursor.pointingHandCursor];}
- (void)updateTrackingAreas {[super updateTrackingAreas];if(_hoverTracking)[self removeTrackingArea:_hoverTracking];_hoverTracking=[[NSTrackingArea alloc]initWithRect:NSZeroRect options:NSTrackingMouseEnteredAndExited|NSTrackingActiveInKeyWindow|NSTrackingInVisibleRect owner:self userInfo:nil];[self addTrackingArea:_hoverTracking];}
- (void)mouseEntered:(NSEvent *)event {if(!_active&&!_owner.pinPressID){_expanded=YES;[_owner syncPinViews];}}
- (void)mouseExited:(NSEvent *)event {_expanded=NO;[_owner syncPinViews];}
- (void)mouseDown:(NSEvent *)event {
 SMNativeDeveloperControllerV62 *c=_owner;if(c.card&&![c canDiscardComment])return;[c closeComment];c.selectedPinID=_note[@"id"];_expanded=c.developer;[c syncPinViews];[c.window makeFirstResponder:c.shield];[c beginPinPress:_note];NSPoint point=SMPagePoint(c.canvas,[c.canvas convertPoint:event.locationInWindow fromView:nil]);c.pinDragOffset=NSMakePoint(c.pinMovePoint.x-point.x,c.pinMovePoint.y-point.y);
}
- (void)mouseDragged:(NSEvent *)event {[_owner.shield mouseDragged:event];}
- (void)mouseUp:(NSEvent *)event {if(_owner.pinPressID)[_owner finishPinPress];}
- (void)rightMouseDown:(NSEvent *)event {}
- (BOOL)isAccessibilityElement {return YES;}
- (NSString *)accessibilityRole {return NSAccessibilityButtonRole;}
- (NSString *)accessibilityLabel {return [NSString stringWithFormat:@"%@：%@",_note[@"author"]?:@"标注",_note[@"text"]?:@""];}
- (BOOL)accessibilityPerformPress {[_owner emit:@{@"kind":@"comment",@"id":_note[@"id"]}];return YES;}
- (void)drawRect:(NSRect)dirty {
 NSRect r=_expanded?self.bounds:NSInsetRect(self.bounds,2,2);CGFloat radius=_expanded?30:r.size.width/2;
 NSBezierPath *bubble=SMCommentBubblePath(r,radius);
 [(_expanded?SMCommentTone(@"surface"):NSColor.whiteColor)setFill];[bubble fill];if(_active&&!_owner.developer){[[NSColor colorWithSRGBRed:0 green:.48 blue:1 alpha:1]setStroke];bubble.lineWidth=2;[bubble stroke];}
 NSString *author=_note[@"author"]?:@"设计";NSString *initial=author.length?[author substringWithRange:[author rangeOfComposedCharacterSequenceAtIndex:0]]:@"注";
 SMDrawAvatar(_note[@"avatar"],initial,_expanded?NSMakeRect(30,30,32,32):NSMakeRect(6,6,32,32),YES);
 if(_expanded){
  NSAttributedString *body=[[NSAttributedString alloc]initWithString:_note[@"text"]?:@"" attributes:SMCommentBodyAttributes()];[body drawWithRect:NSMakeRect(70,SMCommentBodyHeight(_note[@"text"],MAX(1,self.bounds.size.width-100))<=22?35:30,MAX(1,self.bounds.size.width-100),44) options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingTruncatesLastVisibleLine];
  [SMRelativeTime(_note[@"createdAt"]) drawInRect:NSMakeRect(70,86,MAX(1,self.bounds.size.width-100),16) withAttributes:@{NSFontAttributeName:SMDialogFont(12,NO),NSForegroundColorAttributeName:SMCommentTone(@"muted")}];
 }
}
@end
static NSCursor *SMCommentPinCursor(NSString *avatar,NSString *initial){
 static NSCache *cache;static dispatch_once_t once;dispatch_once(&once,^{cache=[NSCache new];cache.countLimit=32;});
 NSString *key=[NSString stringWithFormat:@"%@|%@",avatar?:@"",initial?:@""];NSCursor *cursor=[cache objectForKey:key];if(cursor)return cursor;
 NSImage *image=[NSImage imageWithSize:NSMakeSize(72,72) flipped:YES drawingHandler:^BOOL(NSRect rect){
  NSRect pin=NSMakeRect(18,16,36,36),shapeRect=NSInsetRect(pin,2,2);NSBezierPath *shape=SMCommentBubblePath(shapeRect,16);
  [NSGraphicsContext saveGraphicsState];NSShadow *shadow=[NSShadow new];shadow.shadowColor=[NSColor colorWithWhite:0 alpha:.24];shadow.shadowBlurRadius=5;shadow.shadowOffset=NSMakeSize(0,-2);[shadow set];[NSColor.whiteColor setFill];[shape fill];[NSGraphicsContext restoreGraphicsState];
  SMDrawAvatar(avatar,initial.length?initial:@"注",NSMakeRect(23,21,26,26),YES);return YES;
 }];cursor=[[NSCursor alloc]initWithImage:image hotSpot:NSMakePoint(36,52)];[cache setObject:cursor forKey:key];return cursor;
}
static NSArray<NSValue *> *SMCursorRectsBySubtractingRect(NSRect source,NSRect blocker){
 NSRect cut=NSIntersectionRect(source,blocker);if(NSIsEmptyRect(cut))return @[[NSValue valueWithRect:source]];
 NSRect parts[]={NSMakeRect(NSMinX(source),NSMinY(source),source.size.width,NSMinY(cut)-NSMinY(source)),NSMakeRect(NSMinX(source),NSMaxY(cut),source.size.width,NSMaxY(source)-NSMaxY(cut)),NSMakeRect(NSMinX(source),NSMinY(cut),NSMinX(cut)-NSMinX(source),cut.size.height),NSMakeRect(NSMaxX(cut),NSMinY(cut),NSMaxX(source)-NSMaxX(cut),cut.size.height)};
 NSMutableArray<NSValue *> *result=[NSMutableArray array];for(NSUInteger i=0;i<4;i++)if(!NSIsEmptyRect(parts[i]))[result addObject:[NSValue valueWithRect:parts[i]]];return result;
}
@implementation SMDeveloperShieldV62
- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return NO; }
- (BOOL)acceptsFirstResponder { return self.owner.developer||self.owner.commentTool||self.owner.hand||self.owner.selectedPinID.length; }
- (NSView *)hitTest:(NSPoint)p {
 NSView *hit=[super hitTest:p];SMNativeDeveloperControllerV62 *c=self.owner;
 if(c.developer){if(hit==self&&[c nativeExportHitAtPoint:p])return nil;return hit;}
 if([hit isKindOfClass:SMPinViewV62.class]||hit==c.bar||[hit isDescendantOf:c.bar]||(c.card&&(hit==c.card||[hit isDescendantOf:c.card])))return hit;
 // Design tools intercept the canvas only. Sidebar clicks and drags stay native.
 NSPoint local=[self convertPoint:p fromView:self.superview];
 BOOL inCanvas=NSPointInRect([c.canvas convertPoint:local fromView:self],c.canvas.bounds);
 return inCanvas&&(c.commentTool||c.hand)?hit:nil;
}
- (void)resetCursorRects {
 SMNativeDeveloperControllerV62 *c=self.owner;NSRect rect=NSIntersectionRect([self convertRect:c.canvas.bounds fromView:c.canvas],self.bounds);if(NSIsEmptyRect(rect))return;
 NSCursor *cursor=c.commentTool&&!c.developer?SMCommentPinCursor(c.commentCursorAvatar,c.commentCursorInitial):((c.hand||c.spaceDown)?NSCursor.openHandCursor:(c.developer?NSCursor.arrowCursor:nil));if(!cursor)return;
 NSMutableArray<NSValue *> *regions=[NSMutableArray arrayWithObject:[NSValue valueWithRect:rect]];NSMutableArray<NSView *> *blockers=[NSMutableArray array];
 if(c.bar&&!c.bar.hidden)[blockers addObject:c.bar];if(c.card&&!c.card.hidden)[blockers addObject:c.card];for(SMPinViewV62 *pin in c.pinViews.allValues)if(!pin.hidden)[blockers addObject:pin];
 for(NSView *blocker in blockers){NSRect cut=[self convertRect:blocker.bounds fromView:blocker];NSMutableArray<NSValue *> *next=[NSMutableArray array];for(NSValue *region in regions)[next addObjectsFromArray:SMCursorRectsBySubtractingRect(region.rectValue,cut)];regions=next;}
 for(NSValue *region in regions)[self addCursorRect:region.rectValue cursor:cursor];
}
- (void)mouseDown:(NSEvent *)e {
 SMNativeDeveloperControllerV62 *c=self.owner; 
 [c.window makeFirstResponder:self];
 if(c.card){if([c canDiscardComment])[c closeComment];else return;}
 if(!c.developer&&!c.commentTool&&!c.hand)return;
 NSPoint canvasPoint=[c.canvas convertPoint:e.locationInWindow fromView:nil];
 if(NSPointInRect(canvasPoint,c.canvas.bounds)){
  c.lastDrag=e.locationInWindow;c.panning=c.hand||c.spaceDown;
  if(c.panning){[[NSCursor closedHandCursor] set];return;}
  NSPoint pagePoint=SMPagePoint(c.canvas,canvasPoint);
  if(c.commentTool&&!c.developer){[c emit:@{@"kind":@"addComment",@"x":@(pagePoint.x),@"y":@(pagePoint.y)}];return;}
  [c emit:@{@"kind":@"select",@"x":@(pagePoint.x),@"y":@(pagePoint.y),@"shift":@((e.modifierFlags & NSEventModifierFlagShift)!=0),@"deep":@((e.modifierFlags & NSEventModifierFlagCommand)!=0||e.clickCount>1)}];
  return;
 }
 // Select/expand sidebar rows directly; never deliver a native mouseDown that
 // could toggle locks/visibility, rename, reorder, or change properties.
 NSView *hit=[c underlyingHitAtWindowPoint:e.locationInWindow];
 NSView *v=hit;while(v && ![v isKindOfClass:NSOutlineView.class])v=v.superview;
 if(v){NSOutlineView *outline=(id)v;NSString *identifier=outline.identifier;
  if([identifier isEqualToString:@"LayerList"]||[identifier isEqualToString:@"PageList"]){
   NSPoint q=[outline convertPoint:e.locationInWindow fromView:nil];NSInteger row=[outline rowAtPoint:q];if(row<0)return;id item=[outline itemAtRow:row];
   if([identifier isEqualToString:@"PageList"]&&[NSStringFromClass([outline.delegate class])isEqualToString:@"BCDocumentListViewController"]){[outline selectRowIndexes:[NSIndexSet indexSetWithIndex:row] byExtendingSelection:NO];return;}
   NSRect rowRect=[outline rectOfRow:row];CGFloat disclosure=NSMinX(rowRect)+[outline levelForRow:row]*outline.indentationPerLevel+24;
   if(q.x<disclosure && [outline isExpandable:item]){if([outline isItemExpanded:item])[outline collapseItem:item];else [outline expandItem:item];return;}
   id layer=[item respondsToSelector:@selector(layer)]?[item layer]:nil;
   if(layer)[c emit:@{@"kind":[identifier isEqualToString:@"PageList"]?@"page":@"layer",@"layer":layer,@"shift":@((e.modifierFlags & NSEventModifierFlagShift)!=0)}];
  }
 }
}
- (void)mouseDragged:(NSEvent *)e {SMNativeDeveloperControllerV62 *c=self.owner;
 if(c.pinPressID){if(!c.pinMoveActive||c.developer)return;NSPoint point=[c.canvas convertPoint:e.locationInWindow fromView:nil];if(!NSPointInRect(point,c.canvas.bounds))return;point=SMPagePoint(c.canvas,point);[c dragPinToPagePoint:NSMakePoint(point.x+c.pinDragOffset.x,point.y+c.pinDragOffset.y)];return;}
 if(!c.panning)return;NSPoint p=e.locationInWindow;[c.canvas scrollBy:NSMakePoint(p.x-c.lastDrag.x,c.lastDrag.y-p.y)];c.lastDrag=p;[self setNeedsDisplay:YES];}
- (void)mouseUp:(NSEvent *)e {if(self.owner.pinPressID){[self.owner finishPinPress];return;}self.owner.panning=NO;[(self.owner.hand||self.owner.spaceDown?NSCursor.openHandCursor:NSCursor.arrowCursor) set];}
- (void)rightMouseDown:(NSEvent *)e {if(!self.owner.developer)return;[self.owner selectContextLayerForEvent:e];NSMenu *menu=[self.owner nativeCopyMenuForEvent:e];if(menu.numberOfItems)[NSMenu popUpContextMenu:menu withEvent:e forView:self];}
- (void)otherMouseDown:(NSEvent *)e {self.owner.panning=YES;self.owner.lastDrag=e.locationInWindow;}
- (void)otherMouseDragged:(NSEvent *)e {[self mouseDragged:e];}
- (void)otherMouseUp:(NSEvent *)e {[self mouseUp:e];}
- (void)scrollWheel:(NSEvent *)e {
 SMNativeDeveloperControllerV62 *c=self.owner;NSPoint p=[c.canvas convertPoint:e.locationInWindow fromView:nil];
 if(NSPointInRect(p,c.canvas.bounds)){[c.canvas scrollWheel:e];[self setNeedsDisplay:YES];return;}
 // Scrolling is navigation. Resolve the underlying scroll view without forwarding clicks.
 NSView *v=[c underlyingHitAtWindowPoint:e.locationInWindow];
 while(v && ![v isKindOfClass:NSScrollView.class])v=v.superview;if(v)[v scrollWheel:e];
}
- (void)magnifyWithEvent:(NSEvent *)e {[self.owner.canvas magnifyWithEvent:e];}
- (void)keyDown:(NSEvent *)e {}
- (NSDragOperation)draggingEntered:(id<NSDraggingInfo>)sender {return NSDragOperationNone;}
- (BOOL)performDragOperation:(id<NSDraggingInfo>)sender {return NO;}
- (void)drawRect:(NSRect)dirty {
 SMNativeDeveloperControllerV62 *c=self.owner;
 if(!c.developer)return;
 // Measurement graphics are supplied in page coordinates; they never become layers.
 NSArray *rects=c.measureRects;if(rects.count<1)return;
 NSMutableArray *viewRects=[NSMutableArray array];for(NSDictionary *r in rects){NSPoint a=[c.canvas convertPointFromPage:NSMakePoint([r[@"x"] doubleValue],[r[@"y"] doubleValue])];NSPoint b=[c.canvas convertPointFromPage:NSMakePoint([r[@"x"] doubleValue]+[r[@"w"] doubleValue],[r[@"y"] doubleValue]+[r[@"h"] doubleValue])];a=[self convertPoint:a fromView:c.canvas];b=[self convertPoint:b fromView:c.canvas];NSRect v=NSMakeRect(MIN(a.x,b.x),MIN(a.y,b.y),fabs(b.x-a.x),fabs(b.y-a.y));[viewRects addObject:[NSValue valueWithRect:v]];[NSColor.systemBlueColor setStroke];NSBezierPath *box=[NSBezierPath bezierPathWithRect:v];box.lineWidth=1;[box stroke];}
 NSDictionary *label=@{NSFontAttributeName:[NSFont monospacedSystemFontOfSize:14 weight:NSFontWeightMedium],NSForegroundColorAttributeName:NSColor.whiteColor,NSBackgroundColorAttributeName:NSColor.systemBlueColor};
 if(rects.count==1){NSDictionary *r=rects[0];NSRect v=[viewRects[0] rectValue];NSString *s=[NSString stringWithFormat:@" %.2f × %.2f ",[r[@"w"] doubleValue],[r[@"h"] doubleValue]];[s drawAtPoint:NSMakePoint(NSMidX(v)-[s sizeWithAttributes:label].width/2,NSMaxY(v)+5) withAttributes:label];}
 if(rects.count==2){NSRect a=[viewRects[0] rectValue],b=[viewRects[1] rectValue];NSDictionary *ra=rects[0],*rb=rects[1];double dx=MAX(0,MAX([rb[@"x"] doubleValue]-[ra[@"x"] doubleValue]-[ra[@"w"] doubleValue],[ra[@"x"] doubleValue]-[rb[@"x"] doubleValue]-[rb[@"w"] doubleValue]));double dy=MAX(0,MAX([rb[@"y"] doubleValue]-[ra[@"y"] doubleValue]-[ra[@"h"] doubleValue],[ra[@"y"] doubleValue]-[rb[@"y"] doubleValue]-[rb[@"h"] doubleValue]));NSString *s=[NSString stringWithFormat:@" 间距 X %.2f · Y %.2f ",dx,dy];[s drawAtPoint:NSMakePoint((NSMidX(a)+NSMidX(b))/2-[s sizeWithAttributes:label].width/2,(NSMidY(a)+NSMidY(b))/2) withAttributes:label];}
}
@end
@implementation SMNativeDeveloperControllerV62
- (void)setCommentCursorAvatar:(NSString *)avatar author:(NSString *)author {
 NSString *safeAvatar=[avatar isKindOfClass:NSString.class]?avatar:@"",*safeAuthor=[author isKindOfClass:NSString.class]?author:@"";
 NSString *initial=safeAuthor.length?[safeAuthor substringWithRange:[safeAuthor rangeOfComposedCharacterSequenceAtIndex:0]]:@"注";
 if([_commentCursorAvatar isEqual:safeAvatar]&&[_commentCursorInitial isEqual:initial])return;
 _commentCursorAvatar=[safeAvatar copy];_commentCursorInitial=[initial copy];[_window invalidateCursorRectsForView:_shield];
}
+ (BOOL)isAvatarDataValid:(NSString *)value {return SMAvatarImage(value)!=nil;}
+ (NSString *)avatarDataForFile:(NSString *)path {
 NSDictionary *attributes=[NSFileManager.defaultManager attributesOfItemAtPath:path error:nil];if([attributes fileSize]>20*1024*1024)return @"";
 NSImage *image=[[NSImage alloc]initWithContentsOfFile:path];if(!image||image.size.width<=0||image.size.height<=0)return @"";
 NSBitmapImageRep *bitmap=[[NSBitmapImageRep alloc]initWithBitmapDataPlanes:NULL pixelsWide:128 pixelsHigh:128 bitsPerSample:8 samplesPerPixel:4 hasAlpha:YES isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:0 bitsPerPixel:0];
 [NSGraphicsContext saveGraphicsState];[NSGraphicsContext setCurrentContext:[NSGraphicsContext graphicsContextWithBitmapImageRep:bitmap]];CGFloat edge=MIN(image.size.width,image.size.height);[image drawInRect:NSMakeRect(0,0,128,128) fromRect:NSMakeRect((image.size.width-edge)/2,(image.size.height-edge)/2,edge,edge) operation:NSCompositingOperationCopy fraction:1 respectFlipped:NO hints:nil];[NSGraphicsContext restoreGraphicsState];
 NSData *data=[bitmap representationUsingType:NSBitmapImageFileTypePNG properties:@{}];return data?[NSString stringWithFormat:@"data:image/png;base64,%@",[data base64EncodedStringWithOptions:0]]:@"";
}
- (void)syncPinViews {
 if(!_pinViews)_pinViews=[NSMutableDictionary new];NSMutableSet *visible=[NSMutableSet new];
 NSRect canvasRect=[_shield convertRect:_canvas.bounds fromView:_canvas];
 for(NSDictionary *pin in _pins){NSString *identifier=pin[@"id"];if(!identifier)continue;[visible addObject:identifier];SMPinViewV62 *view=_pinViews[identifier];
  if(!view){view=[[SMPinViewV62 alloc]initWithFrame:NSMakeRect(0,0,44,44)];view.owner=self;view.wantsLayer=YES;view.layer.shadowColor=NSColor.blackColor.CGColor;view.layer.shadowOpacity=.18;view.layer.shadowRadius=5;view.layer.shadowOffset=CGSizeMake(0,-2);[_shield addSubview:view positioned:NSWindowBelow relativeTo:_bar];_pinViews[identifier]=view;}
  BOOL paint=![view.note isEqual:pin];BOOL wasActive=view.active;view.note=pin;view.active=[_selectedPinID isEqual:identifier]||(_card&&[_pendingComment[@"id"]isEqual:identifier]);if((view.active&&(!_developer||_card))||(_pinPressID&&!_developer))view.expanded=NO;
  NSPoint page=NSMakePoint([pin[@"x"]doubleValue],[pin[@"y"]doubleValue]),point=[_canvas convertPointFromPage:page];point=[_shield convertPoint:point fromView:_canvas];BOOL hidden=!NSPointInRect(point,canvasRect)||(_developer&&_card&&[_pendingComment[@"id"]isEqual:identifier]);if(view.hidden!=hidden)view.hidden=hidden;
  CGFloat width=view.expanded?MIN(460,MAX(44,canvasRect.size.width-24)):44,height=view.expanded?132:44;NSRect frame=NSMakeRect(point.x-2,point.y-height+2,width,height);
  if(view.expanded)frame=SMCommentBubbleFrame(point,NSMakeSize(width,height),canvasRect);
  NSInteger bucket=(NSInteger)(NSDate.date.timeIntervalSince1970/60);BOOL moved=!NSEqualRects(view.frame,frame);paint=paint||wasActive!=view.active||moved||bucket!=view.relativeBucket;view.relativeBucket=bucket;if(moved)view.frame=frame;
  if(view.expanded){if(paint||view.shadow.shadowBlurRadius!=25)SMApplySurfaceShadow(view,30,50);}else if(!view.shadow||view.shadow.shadowBlurRadius!=5){NSShadow *shadow=[NSShadow new];shadow.shadowColor=[NSColor colorWithWhite:0 alpha:.18];shadow.shadowBlurRadius=5;shadow.shadowOffset=NSMakeSize(0,-2);view.shadow=shadow;view.layer.shadowPath=nil;}
  if(paint)[view setNeedsDisplay:YES];if(moved)[_window invalidateCursorRectsForView:_shield];
 }
 for(NSString *identifier in _pinViews.allKeys)if(![visible containsObject:identifier]){[_pinViews[identifier] removeFromSuperview];[_pinViews removeObjectForKey:identifier];}
}
+ (NSString *)compatibilityErrorForDocument:(id)document {
 for(NSString *name in @[@"documentWindow",@"contentDrawView"])
  if(![document respondsToSelector:NSSelectorFromString(name)])return [NSString stringWithFormat:@"当前 Sketch 缺少文档接口 %@，工具栏未启动。",name];
 NSWindow *window=[document documentWindow];NSView *canvas=[document contentDrawView];
 if(![window isKindOfClass:NSWindow.class]||![canvas isKindOfClass:NSView.class]||!window.contentView)return @"请先打开一个可编辑的 Sketch 文档窗口。";
 for(NSString *name in @[@"convertPointFromPage:",@"scrollBy:",@"zoomIn",@"zoomOut",@"eventHandlerManager"])
  if(![canvas respondsToSelector:NSSelectorFromString(name)])return [NSString stringWithFormat:@"当前 Sketch 缺少画布接口 %@，无法安全开启开发模式。",name];
 NSPoint page=SMPagePoint(canvas,NSZeroPoint);if(!isfinite(page.x)||!isfinite(page.y))return @"画布坐标尚未就绪，请等待文档加载完成后重试。";
 id manager=[canvas eventHandlerManager];
 if(![manager respondsToSelector:@selector(normalHandler)]||![[manager normalHandler]respondsToSelector:@selector(resetToIdle)])return @"当前 Sketch 不支持安全结束编辑状态，未开启开发模式。";
 return @"";
}
- (void)beginPinPress:(NSDictionary *)pin {[_pinLongPressTimer invalidate];_pinPressID=pin[@"id"];_pinMoveActive=NO;_pinMoved=NO;_pinMovePoint=NSMakePoint([pin[@"x"]doubleValue],[pin[@"y"]doubleValue]);_pinDragOffset=NSZeroPoint;if(!_developer){_pinLongPressTimer=[NSTimer timerWithTimeInterval:.45 target:self selector:@selector(startPinDrag) userInfo:nil repeats:NO];[NSRunLoop.mainRunLoop addTimer:_pinLongPressTimer forMode:NSRunLoopCommonModes];}}
- (void)dragPinToPagePoint:(NSPoint)point {if(!_pinPressID||!_pinMoveActive||_developer)return;_pinMoved=hypot(point.x-_pinMovePoint.x,point.y-_pinMovePoint.y)>.01||_pinMoved;_pinMovePoint=point;NSMutableArray *pins=[NSMutableArray array];for(NSDictionary *pin in _pins){if([pin[@"id"]isEqual:_pinPressID]){NSMutableDictionary *m=[pin mutableCopy];m[@"x"]=@(point.x);m[@"y"]=@(point.y);[pins addObject:m];}else[pins addObject:pin];}_pins=pins;[_shield setNeedsDisplay:YES];}
- (void)setMeasureRects:(NSArray *)rects {if([_measureRects isEqual:rects])return;_measureRects=[rects copy];[_shield setNeedsDisplay:YES];}
- (void)redrawCanvasOverlay {
 if(_closed||!_window.isVisible)return;
 // A transparent full-window view must not invalidate Sketch's UI at 60 fps.
 // Redraw measurements only when the canvas transform or viewport changes.
 NSPoint origin=[_canvas convertPointFromPage:NSZeroPoint],unit=[_canvas convertPointFromPage:NSMakePoint(1,1)];
 NSRect canvas=[_shield convertRect:_canvas.bounds fromView:_canvas];
 NSArray *state=@[[NSValue valueWithPoint:origin],[NSValue valueWithPoint:unit],[NSValue valueWithRect:canvas],@(_developer)];
 if(![_overlayState isEqual:state]){_overlayState=state;[_shield setNeedsDisplay:YES];}
 [self syncPinViews];if(_card)[self positionCommentCard];
}
- (void)startPinDrag {if(!_developer&&_pinPressID){_pinMoveActive=YES;[NSCursor.closedHandCursor set];}}
- (void)finishPinPress {[_pinLongPressTimer invalidate];_pinLongPressTimer=nil;NSString *identifier=_pinPressID;BOOL move=_pinMoveActive&&_pinMoved&&!_developer;_pinPressID=nil;_pinMoveActive=NO;_pinMoved=NO;[NSCursor.arrowCursor set];if(move)[self emit:@{@"kind":@"moveComment",@"id":identifier,@"x":@(_pinMovePoint.x),@"y":@(_pinMovePoint.y)}];else[self emit:@{@"kind":@"comment",@"id":identifier}];}
- (NSPoint)pagePointForCanvasPoint:(NSPoint)point {return SMPagePoint(_canvas,point);}
- (void)emit:(NSDictionary *)event {if([_eventDelegate respondsToSelector:@selector(developerEvent:)])[_eventDelegate developerEvent:event];}
- (instancetype)initWithDocument:(id)d {if((self=[super init])){_document=d;_window=[d documentWindow];_canvas=[d contentDrawView];_pins=@[];_measureRects=@[];_buttonIcons=[NSMapTable weakToStrongObjectsMapTable];_originalMenu=NSApp.mainMenu;
 _shield=[[SMDeveloperShieldV62 alloc]initWithFrame:_window.contentView.bounds];_shield.wantsLayer=YES;_shield.autoresizingMask=NSViewWidthSizable|NSViewHeightSizable;_shield.owner=self;
 [_window.contentView addSubview:_shield positioned:NSWindowAbove relativeTo:nil];
 _displayTimer=[NSTimer timerWithTimeInterval:1.0/60 target:self selector:@selector(redrawCanvasOverlay) userInfo:nil repeats:YES];[NSRunLoop.mainRunLoop addTimer:_displayTimer forMode:NSRunLoopCommonModes];
 _bar=[[NSView alloc]initWithFrame:NSMakeRect(0,0,772,60)];_bar.wantsLayer=YES;_bar.layer.backgroundColor=NSColor.windowBackgroundColor.CGColor;_bar.layer.cornerRadius=18;_bar.autoresizesSubviews=NO;_bar.layer.borderColor=[NSColor.separatorColor colorWithAlphaComponent:.25].CGColor;_bar.layer.borderWidth=1;_bar.layer.shadowOpacity=.16;_bar.layer.shadowRadius=12;
 [_shield addSubview:_bar];
 _grip=[[SMToolbarGripV62 alloc]initWithFrame:NSMakeRect(4,9,26,42)];_grip.owner=self;_grip.toolTip=@"按住拖动工具栏";[_bar addSubview:_grip];
 _pointerButton=[self button:@"cursorarrow" title:@"选择" x:36 width:48 action:@selector(pointer:)];
 _handButton=[self button:@"hand.draw" title:@"平移" x:88 width:48 action:@selector(hand:)];
 _commentButton=[self button:@"bubble.left" title:@"标注 · 点击画布添加，Esc 退出" x:114 width:48 action:@selector(comments:)];

 NSView *line=[[NSView alloc]initWithFrame:NSMakeRect(174,12,1,36)];line.wantsLayer=YES;line.identifier=@"toolDivider";line.layer.backgroundColor=NSColor.separatorColor.CGColor;[_bar addSubview:line];
 _designButton=[self button:@"pencil" title:@"设计模式" x:186 width:116 action:@selector(design:)];
 _devButton=[self button:@"chevron.left.forwardslash.chevron.right" title:@"开发模式" x:308 width:116 action:@selector(develop:)];
 NSButton *area=[self button:@"area" title:@"标注区域" x:102 width:44 action:@selector(mark:)];area.identifier=@"area";
 NSButton *width=[self button:@"width" title:@"标注宽" x:150 width:44 action:@selector(mark:)];width.identifier=@"width";
 NSButton *height=[self button:@"height" title:@"标注高" x:198 width:44 action:@selector(mark:)];height.identifier=@"height";
 NSButton *spacing=[self button:@"spacing" title:@"标注间距" x:246 width:44 action:@selector(mark:)];spacing.identifier=@"spacing";
 NSButton *marginLeft=[self button:@"marginLeft" title:@"标注左边距" x:294 width:44 action:@selector(mark:)];marginLeft.identifier=@"marginLeft";
 NSButton *marginRight=[self button:@"marginRight" title:@"标注右边距" x:342 width:44 action:@selector(mark:)];marginRight.identifier=@"marginRight";
 NSButton *marginTop=[self button:@"marginTop" title:@"标注上边距" x:390 width:44 action:@selector(mark:)];marginTop.identifier=@"marginTop";
 NSButton *marginBottom=[self button:@"marginBottom" title:@"标注下边距" x:438 width:44 action:@selector(mark:)];marginBottom.identifier=@"marginBottom";
 NSButton *properties=[self button:@"properties" title:@"标注属性" x:486 width:44 action:@selector(mark:)];properties.identifier=@"properties";
 NSButton *export=[self button:@"export" title:@"导出 HTML 交付" x:360 width:44 action:@selector(exportHTML:)];export.identifier=@"export";_exportButton=export;export.toolTip=@"导出 HTML · 悬停选择范围";
 NSButton *settings=[self button:@"settings" title:@"交付设置" x:408 width:44 action:@selector(settings:)];settings.identifier=@"settings";
 _deliveryDivider=[[NSView alloc]initWithFrame:NSMakeRect(348,12,1,36)];_deliveryDivider.wantsLayer=YES;[_bar addSubview:_deliveryDivider];
 _designOnlyButtons=@[_commentButton,area,width,height,spacing,marginLeft,marginRight,marginTop,marginBottom,properties,export,settings];_designTools=@[area,width,height,spacing,marginLeft,marginRight,marginTop,marginBottom,properties];
 _modeDivider=[[NSView alloc]initWithFrame:NSMakeRect(462,12,1,36)];_modeDivider.wantsLayer=YES;[_bar addSubview:_modeDivider];
 NSButton *close=[self button:@"xmark" title:@"关闭工具栏" x:652 width:36 action:@selector(close:)];close.identifier=@"closeBar";
 __weak typeof(self) weakSelf=self;
 _eventMonitor=[NSEvent addLocalMonitorForEventsMatchingMask:NSEventMaskKeyDown|NSEventMaskKeyUp|NSEventMaskFlagsChanged|NSEventMaskLeftMouseDown handler:^NSEvent *(NSEvent *event){SMNativeDeveloperControllerV62 *owner=weakSelf;return owner?[owner filteredEvent:event]:event;}];
 _timer=[NSTimer scheduledTimerWithTimeInterval:.15 target:self selector:@selector(tick) userInfo:nil repeats:YES];
 [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(paletteChanged:) name:NSSystemColorsDidChangeNotification object:nil];
 [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(documentWindowChanged:) name:NSWindowDidBecomeMainNotification object:nil];
 [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(documentWindowChanged:) name:NSWindowDidBecomeKeyNotification object:nil];
 [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(windowClosing:) name:NSWindowWillCloseNotification object:_window];[self tick];[self refreshButtons];
 }return self;}
// NSToolbar can live above contentView, outside the canvas shield. Block its
// editing clicks at input time without changing NSControl.enabled or icon tint.
- (BOOL)blocksNativeToolbarClick:(NSEvent *)event {
 NSView *root=_window.contentView.superview;if(!root)return NO;
 NSPoint point=root.superview?[root.superview convertPoint:event.locationInWindow fromView:nil]:event.locationInWindow;
 NSView *hit=[root hitTest:point];BOOL toolbar=NO;
 for(NSView *view=hit;view;view=view.superview){
  if(view==_shield)return NO;
  if([view.identifier isEqualToString:@"Zoom"])return NO;
  if([NSStringFromClass(view.class) rangeOfString:@"Toolbar" options:NSCaseInsensitiveSearch].location!=NSNotFound)toolbar=YES;
 }
 if(toolbar)return YES;
 // Some host releases use custom hosting views without Toolbar in the class.
 for(NSToolbarItem *item in _window.toolbar.items){NSView *view=item.view;if(!view||view.hidden)continue;
  NSPoint local=[view convertPoint:event.locationInWindow fromView:nil];
  if(NSPointInRect(local,view.bounds))return ![view.identifier isEqualToString:@"Zoom"];
 }
 return NO;
}
- (NSEvent *)filteredEvent:(NSEvent *)e {SMNativeDeveloperControllerV62 *s=self;
 if(e.type==NSEventTypeLeftMouseDown){if(s.developer&&e.window==s.window&&[s blocksNativeToolbarClick:e])return nil;if(!s.developer&&e.window==s.window&&s.selectedPinID.length){NSView *root=s.window.contentView,*hit=[root hitTest:[root convertPoint:e.locationInWindow fromView:nil]],*pin=hit;while(pin&&![pin isKindOfClass:SMPinViewV62.class])pin=pin.superview;if(!pin&&!(s.card&&(hit==s.card||[hit isDescendantOf:s.card]))){if(![s canDiscardComment])return nil;[s closeComment];}}return e;}
 if(s&&!s.developer&&e.window==s.window&&e.type==NSEventTypeKeyDown&&s.selectedPinID.length&&(e.keyCode==51||e.keyCode==117)&&!(e.modifierFlags&(NSEventModifierFlagCommand|NSEventModifierFlagControl|NSEventModifierFlagOption))&&![s.window.firstResponder isKindOfClass:NSTextView.class]){if([s canDiscardComment])[s emit:@{@"kind":@"saveComment",@"op":@"delete",@"id":s.selectedPinID}];return nil;}
 if(s&&!s.developer&&e.window==s.window&&e.type==NSEventTypeKeyDown&&e.keyCode==53){if(s.card){if([s canDiscardComment])[s closeComment];return nil;}if(s.commentTool||s.hand){[s pointer:nil];return nil;}return e;}if(!s||!s.developer||(e.window!=s.window&&!(e.window==nil&&SMCurrent(s.document,s.window))))return e;
  // Export scale, suffix and format fields remain native editable controls.
  // Their field editor belongs to the window; resolve its delegate back to the field.
  id focus=s.window.firstResponder;id field=([focus isKindOfClass:NSTextView.class]&&[(NSTextView *)focus isFieldEditor])?[(NSTextView *)focus delegate]:focus;
  BOOL exportFocus=[field isKindOfClass:NSView.class]&&[s isNativeExportView:field];
  if(exportFocus){BOOL command=(e.modifierFlags&NSEventModifierFlagCommand)!=0;NSString *key=e.charactersIgnoringModifiers.lowercaseString?:@"";if(!command||[@[@"a",@"c",@"v",@"x"]containsObject:key])return e;}
  if(e.type==NSEventTypeFlagsChanged)return nil;
  BOOL down=e.type==NSEventTypeKeyDown;NSString *k=e.charactersIgnoringModifiers.lowercaseString?:@"";BOOL cmd=(e.modifierFlags&NSEventModifierFlagCommand)!=0;
  if(e.keyCode==49){s.spaceDown=down;return nil;}
  if(!down)return nil;
  if(cmd&&[k isEqual:@"c"]){[s copySelection:nil];return nil;}
  if(cmd&&[k isEqual:@"a"]&&[s.window.firstResponder isKindOfClass:NSTextView.class])return e;
  if(cmd&&([k isEqual:@"q"]||[k isEqual:@"h"]||[k isEqual:@"w"]||[k isEqual:@"s"]))return e;
  if(cmd&&([k isEqual:@"+"]||[k isEqual:@"="])){[s.canvas zoomIn];return nil;}
  if(cmd&&[k isEqual:@"-"]){[s.canvas zoomOut];return nil;}
  if([k isEqual:@"v"]&&!cmd)[s pointer:nil];else if([k isEqual:@"h"]&&!cmd)[s hand:nil];else if([k isEqual:@"1"]&&!cmd)[s fit:nil];else if(e.keyCode==53&&s.card){[s closeComment];}
  // All other shortcuts, Return, Delete, arrows and text input are swallowed.
  return nil;}
- (void)paletteChanged:(NSNotification *)notification {[self applyPalette];}
- (NSImage *)lineIcon:(NSString *)name color:(NSColor *)color {NSImage *provided=SMProvidedToolbarIcon(name,color);if(provided){provided.template=NO;return provided;}NSImage *image=[NSImage imageWithSize:NSMakeSize(24,24) flipped:YES drawingHandler:^BOOL(NSRect rect){NSBezierPath *p=[NSBezierPath bezierPath];p.lineWidth=1.875;p.lineCapStyle=NSLineCapStyleRound;p.lineJoinStyle=NSLineJoinStyleRound;
 NSArray *lines;
 if([name isEqual:@"cursorarrow"])lines=@[@[@4,@3,@10,@21,@13,@13,@21,@10,@4,@3]];
 else if([name isEqual:@"hand.draw"])lines=@[@[@7,@12,@7,@6,@10,@6,@10,@12],@[@10,@10,@10,@3,@13,@3,@13,@12],@[@13,@9,@13,@5,@16,@5,@16,@13],@[@16,@10,@16,@8,@19,@8,@19,@16,@17,@21,@10,@21,@4,@14,@4,@12,@6,@12,@9,@15]];
 else if([name isEqual:@"more"])lines=@[@[@5,@12,@5.5,@12],@[@12,@12,@12.5,@12],@[@19,@12,@19.5,@12]];
 else lines=@[@[@5,@5,@19,@19],@[@19,@5,@5,@19]];
 for(NSArray *line in lines){for(NSUInteger i=0;i+1<line.count;i+=2){NSPoint q=NSMakePoint([line[i]doubleValue],[line[i+1]doubleValue]);if(i==0)[p moveToPoint:q];else [p lineToPoint:q];}}NSRect bounds=p.bounds;CGFloat scale=(24.0*20.0/22.0-p.lineWidth)/MAX(bounds.size.width,bounds.size.height);NSAffineTransform *fit=[NSAffineTransform transform];[fit translateXBy:12 yBy:12];[fit scaleBy:scale];[fit translateXBy:-NSMidX(bounds) yBy:-NSMidY(bounds)];[p transformUsingAffineTransform:fit];[color setStroke];[p stroke];return YES;}];image.template=NO;return image;}
- (NSButton *)button:(NSString *)symbol title:(NSString *)title x:(CGFloat)x width:(CGFloat)width action:(SEL)action {NSButton *b;if([symbol isEqual:@"export"]){SMExportTriggerV62 *trigger=[[SMExportTriggerV62 alloc]initWithFrame:NSMakeRect(x,9,width,42)];trigger.hoverDelegate=self;b=trigger;}else b=[[SMToolbarButtonV62 alloc]initWithFrame:NSMakeRect(x,9,width,42)];b.title=width>80?title:@"";b.toolTip=title;b.bordered=NO;b.wantsLayer=YES;b.layer.cornerRadius=10;b.target=self;b.action=action;b.font=[NSFont systemFontOfSize:13 weight:NSFontWeightMedium];if(symbol){[_buttonIcons setObject:symbol forKey:b];b.image=[self lineIcon:symbol color:SMInk(_bar)];b.image.accessibilityDescription=title;b.imagePosition=width>80?NSImageLeft:NSImageOnly;}[_bar addSubview:b];return b;}
- (void)applyPalette {
 _paletteName=SMDark(_bar)?@"dark":@"light";_bar.layer.backgroundColor=SMToolbarBackground(_bar).CGColor;[_grip setNeedsDisplay:YES];
 _bar.layer.borderColor=(SMDark(_bar)?[NSColor colorWithWhite:1 alpha:.15]:[NSColor colorWithWhite:0 alpha:.12]).CGColor;
 if(_card)[_card setNeedsDisplay:YES];
 for(NSButton *b in _buttonIcons.keyEnumerator){BOOL active=[b isKindOfClass:SMToolbarButtonV62.class]&&((SMToolbarButtonV62 *)b).activeStyle;NSColor *ink=active?NSColor.whiteColor:SMInk(_bar);b.image=[self lineIcon:[_buttonIcons objectForKey:b] color:ink];b.contentTintColor=ink;[b setNeedsDisplay:YES];}
 for(NSView *v in _bar.subviews)if(v==_modeDivider||v==_deliveryDivider||[v.identifier isEqualToString:@"toolDivider"])v.layer.backgroundColor=(SMDark(_bar)?[NSColor colorWithWhite:1 alpha:.18]:[NSColor colorWithWhite:0 alpha:.12]).CGColor;
}
- (void)refreshButtons {
 [self dismissExportChoices];
 BOOL compact=!_developer&&_canvas.bounds.size.width<980;BOOL animate=_hasLayout&&(_lastLayoutDeveloper!=_developer||_compactLayout!=compact);_compactLayout=compact;_lastLayoutDeveloper=_developer;_hasLayout=YES;
 for(NSView *v in _bar.subviews)if([v isKindOfClass:SMToolbarButtonV62.class]){SMToolbarButtonV62 *b=(id)v;b.activeStyle=(b==_pointerButton&&!_hand)||(b==_handButton&&_hand)||(b==_commentButton&&_commentTool)||(b==_designButton&&!_developer)||(b==_devButton&&_developer);b.layer.backgroundColor=NSColor.clearColor.CGColor;[b setNeedsDisplay:YES];}
 [self applyPalette];[_window invalidateCursorRectsForView:_shield];
 CGFloat width=_developer?458:(_compactLayout?508:964);NSRect frame=[self toolbarFrameForWidth:width];
 NSUInteger generation=++_layoutGeneration;_layoutInFlight=animate;
 NSMutableArray *show=[NSMutableArray array],*hide=[NSMutableArray array];for(NSButton *b in _designOnlyButtons)[(_developer?hide:show)addObject:b];for(NSButton *b in @[_pointerButton,_handButton])[(_developer?show:hide)addObject:b];
 for(NSButton *b in show){if(b.hidden)b.alphaValue=animate?0:1;b.hidden=NO;}
 _modeDivider.hidden=_developer;_deliveryDivider.hidden=_developer;
 void (^layout)(BOOL)=^(BOOL animated){
  id bar=animated?self.bar.animator:self.bar;[bar setFrame:frame];
  BOOL compact=self.compactLayout;CGFloat designX=self.developer?160:(compact?156:666),devX=self.developer?284:(compact?280:790);
  NSRect f=self.designButton.frame;f.origin=NSMakePoint(designX,9);[(animated?self.designButton.animator:self.designButton)setFrame:f];f=self.devButton.frame;f.origin=NSMakePoint(devX,9);[(animated?self.devButton.animator:self.devButton)setFrame:f];
  f=self.commentButton.frame;f.origin=NSMakePoint(compact?12:36,compact?61:9);f.size.width=compact?44:48;[(animated?self.commentButton.animator:self.commentButton)setFrame:f];
  for(NSUInteger i=0;i<self.designTools.count;i++){NSButton *tool=self.designTools[i];NSRect t=tool.frame;t.origin=NSMakePoint((compact?60:102)+i*48,compact?61:9);[(animated?tool.animator:tool)setFrame:t];}
  self.deliveryDivider.hidden=self.developer||compact;NSRect deliveryLine=self.deliveryDivider.frame;deliveryLine.origin.x=540;self.deliveryDivider.frame=deliveryLine;
  NSRect modeLine=self.modeDivider.frame;modeLine.origin.x=compact?144:654;self.modeDivider.frame=modeLine;
  for(NSView *v in self.bar.subviews){if([v.identifier isEqualToString:@"closeBar"]){NSRect close=v.frame;close.origin=NSMakePoint(self.developer?412:(compact?456:918),9);[(animated?v.animator:v)setFrame:close];}if([v.identifier isEqualToString:@"toolDivider"]){v.hidden=compact;NSRect line=v.frame;line.origin.x=self.developer?148:90;[(animated?v.animator:v)setFrame:line];}if([v.identifier isEqualToString:@"export"]||[v.identifier isEqualToString:@"settings"]){NSRect t=v.frame;t.origin=NSMakePoint(([v.identifier isEqualToString:@"export"]?(compact?36:552):(compact?84:600)),9);[(animated?v.animator:v)setFrame:t];}}
  for(NSButton *b in show)[(animated?b.animator:b)setAlphaValue:1];for(NSButton *b in hide)[(animated?b.animator:b)setAlphaValue:0];
 };
 if(animate){[NSAnimationContext runAnimationGroup:^(NSAnimationContext *context){context.duration=.22;context.timingFunction=[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];context.allowsImplicitAnimation=YES;layout(YES);} completionHandler:^{if(generation!=self.layoutGeneration)return;for(NSButton *b in hide)b.hidden=YES;self.layoutInFlight=NO;}];}
 else{layout(NO);for(NSButton *b in hide)b.hidden=YES;}
 [_shield setNeedsDisplay:YES];
}
- (NSRect)toolbarFrameForWidth:(CGFloat)width {
 NSRect canvas=[_shield convertRect:_canvas.bounds fromView:_canvas];CGFloat height=(!_developer&&_compactLayout)?112:60;if(canvas.size.width<width+16)canvas=_shield.bounds;
 CGFloat x=_toolbarMoved?NSMinX(canvas)+_toolbarAnchor.x*canvas.size.width-width/2:NSMidX(canvas)-width/2;
 CGFloat y=_toolbarMoved?NSMinY(canvas)+_toolbarAnchor.y*canvas.size.height-height/2:NSMaxY(canvas)-height-26;
 // Keep the grip and close button reachable after mode or window size changes.
 x=MAX(NSMinX(canvas)+8,MIN(NSMaxX(canvas)-width-8,x));y=MAX(NSMinY(canvas)+8,MIN(NSMaxY(canvas)-height-8,y));
 return NSMakeRect(x,y,width,height);
}
- (void)moveToolbarToOrigin:(NSPoint)origin {
 [self dismissExportChoices];
 NSRect canvas=[_shield convertRect:_canvas.bounds fromView:_canvas];if(canvas.size.width<_bar.frame.size.width+16)canvas=_shield.bounds;if(canvas.size.width<=0||canvas.size.height<=0)return;
 _toolbarMoved=YES;_toolbarAnchor=NSMakePoint((origin.x+_bar.frame.size.width/2-NSMinX(canvas))/canvas.size.width,(origin.y+_bar.frame.size.height/2-NSMinY(canvas))/canvas.size.height);
 _bar.frame=[self toolbarFrameForWidth:_bar.frame.size.width];
 _toolbarAnchor=NSMakePoint((NSMidX(_bar.frame)-NSMinX(canvas))/canvas.size.width,(NSMidY(_bar.frame)-NSMinY(canvas))/canvas.size.height);
}
- (void)pointer:(id)sender {_hand=NO;_commentTool=NO;_panning=NO;_spaceDown=NO;_selectedPinID=nil;[_window makeFirstResponder:_developer?_shield:_canvas];[self refreshButtons];}
- (void)hand:(id)sender {_hand=YES;_commentTool=NO;[_window makeFirstResponder:_shield];[self refreshButtons];}
- (void)comments:(id)sender {if(_developer||![self canDiscardComment])return;[self closeComment];_commentTool=!_commentTool;_hand=NO;[_window makeFirstResponder:_commentTool?_shield:_canvas];[self refreshButtons];}
- (void)exportHTML:(id)sender {[self showExportChoices:sender];}
- (void)cancelExportDismiss {[NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(dismissExportChoicesIfOutside) object:nil];}
- (void)scheduleExportDismiss {[self cancelExportDismiss];[self performSelector:@selector(dismissExportChoicesIfOutside) withObject:nil afterDelay:.3];}
- (BOOL)mouseInsideExportView:(NSView *)view {if(!view.window||view.hidden)return NO;NSRect rect=[view.window convertRectToScreen:[view convertRect:view.bounds toView:nil]];return NSPointInRect(NSEvent.mouseLocation,NSInsetRect(rect,-4,-4));}
- (void)dismissExportChoicesIfOutside {if([self mouseInsideExportView:_exportButton]||(_exportPopover.shown&&[self mouseInsideExportView:_exportPopover.contentViewController.view]))return;[self dismissExportChoices];}
- (void)dismissExportChoices {[self cancelExportDismiss];[_exportPopover close];_exportPopover=nil;}
- (void)showExportChoices:(id)sender {
 if(_closed||_developer||_layoutInFlight||_toolbarDragging||!_window.isVisible||_exportButton.hidden||NSApp.modalWindow)return;
 [self cancelExportDismiss];if(_exportPopover.shown)return;
 SMExportChoicesViewV62 *view=[[SMExportChoicesViewV62 alloc]initWithFrame:NSMakeRect(0,0,296,136)];view.hoverDelegate=self;view.appearance=_bar.effectiveAppearance;
 NSArray *titles=@[@"导出选中画板到 HTML",@"导出当前页面画板到 HTML",@"导出全部页面画板到 HTML"];NSArray *scopes=@[@"selected-board",@"page",@"all"];
 for(NSUInteger i=0;i<3;i++){SMExportChoiceButtonV62 *choice=[[SMExportChoiceButtonV62 alloc]initWithFrame:NSMakeRect(8,8+i*40,280,40)];choice.title=titles[i];choice.identifier=scopes[i];choice.toolTip=i==0?@"仅导出选中的画板或 Frame":(i==1?@"导出当前页面的全部画板":@"导出文件中全部页面的全部画板");choice.bordered=NO;choice.font=SMDialogFont(14,NO);choice.target=self;choice.action=@selector(exportChoice:);[choice setAccessibilityLabel:choice.toolTip];[view addSubview:choice];}
 NSViewController *content=[NSViewController new];content.view=view;_exportPopover=[NSPopover new];_exportPopover.contentViewController=content;_exportPopover.contentSize=view.frame.size;_exportPopover.behavior=NSPopoverBehaviorSemitransient;_exportPopover.animates=YES;
 [_exportPopover showRelativeToRect:_exportButton.bounds ofView:_exportButton preferredEdge:NSMaxYEdge];
}
- (void)exportChoice:(NSButton *)sender {
 NSString *scope=sender.identifier;[self dismissExportChoices];if(_closed||_developer||![@[@"selected-board",@"page",@"all"]containsObject:scope]||![self canDiscardComment])return;[self closeComment];[self emit:@{@"kind":@"export",@"id":scope}];
}
- (void)settings:(id)sender {if(_developer||![self canDiscardComment])return;[self closeComment];[self emit:@{@"kind":@"settings"}];}
- (void)mark:(NSButton *)sender {if(_developer||![self canDiscardComment])return;[self closeComment];[self emit:@{@"kind":@"mark",@"id":sender.identifier}];}
- (void)design:(id)sender {[self setDesign];}
- (void)develop:(id)sender {[self activate];}
- (void)close:(id)sender {if(_eventDelegate)[self emit:@{@"kind":@"requestClose"}];else if([self canDiscardComment])[self shutdown];}
- (void)suspendForDocumentSwitch {[self dismissExportChoices];_spaceDown=NO;_panning=NO;_toolbarDragging=NO;[_pinLongPressTimer invalidate];_pinLongPressTimer=nil;_pinPressID=nil;_pinMoveActive=NO;if(NSApp.mainMenu==_restrictedMenu)NSApp.mainMenu=_originalMenu;}
- (void)documentWindowChanged:(NSNotification *)note {if(!_closed)[self emit:@{@"kind":@"focus"}];}
- (void)windowClosing:(NSNotification *)note {[self shutdown];}
- (void)activate {if(_closed||_developer||![self canDiscardComment])return;[_window makeFirstResponder:_canvas];id normal=[[_canvas eventHandlerManager]normalHandler];[normal resetToIdle];_developer=YES;[_shield registerForDraggedTypes:@[NSPasteboardTypeFileURL,NSPasteboardTypeTIFF,NSPasteboardTypePNG,NSPasteboardTypeString]];_hand=NO;_commentTool=NO;[_card removeFromSuperview];_card=nil;[_window makeFirstResponder:_shield];[self refreshButtons];[self tick];[self emit:@{@"kind":@"mode",@"developer":@YES}];}
- (void)setDesign {[_shield unregisterDraggedTypes];if(!_developer){[self pointer:nil];return;}_developer=NO;_hand=NO;_commentTool=NO;_spaceDown=NO;_panning=NO;[_card removeFromSuperview];_card=nil;if(NSApp.mainMenu==_restrictedMenu)NSApp.mainMenu=_originalMenu;[_window makeFirstResponder:_canvas];[self refreshButtons];[self emit:@{@"kind":@"mode",@"developer":@NO}];}
- (BOOL)isNativeExportView:(NSView *)view {
 // Match the host's export section, never a localized title or screen rectangle.
 NSResponder *node=view;for(NSUInteger depth=0;node&&depth<64;depth++,node=node.nextResponder){NSString *name=NSStringFromClass(node.class);if([@[@"Sketch.ExportSection",@"MSExportInspector",@"MSExportInspectorView",@"MSExportInspectorViewController"]containsObject:name])return YES;}return NO;
}
- (NSView *)underlyingHitAtWindowPoint:(NSPoint)point {
 // Resolve host navigation without removing our transparent protection layer.
 NSView *root=_window.contentView;NSPoint local=[root convertPoint:point fromView:nil];
 for(NSView *view in root.subviews.reverseObjectEnumerator){if(view==_shield||view.hidden)continue;NSView *hit=[view hitTest:local];if(hit)return hit;}
 return nil;
}
- (NSView *)nativeExportHitAtPoint:(NSPoint)point {
 NSPoint windowPoint=[_shield.superview convertPoint:point toView:nil];
 NSView *hit=[self underlyingHitAtWindowPoint:windowPoint];return [self isNativeExportView:hit]?hit:nil;
}
// The shield owns mouse/drag/drop input and filteredEvent owns keyboard input.
// Leave Sketch's control validation alone: forcing enabled=NO each tick races
// its native validation and makes toolbar icons alternate between visual states.
- (void)makeMenu {if(_restrictedMenu)return;_restrictedMenu=[[NSMenu alloc]initWithTitle:@"开发者模式"];NSArray *groups=@[@[@"Sketch",@[@"隐藏 Sketch",@"hide:",@"h"],@[@"退出 Sketch",@"terminate:",@"q"]],@[@"开发者模式",@[@"返回设计模式",@"design:",@""],@[@"保存文档",@"saveDocument:",@"s"],@[@"关闭文档",@"performClose:",@"w"]],@[@"编辑",@[@"复制",@"copySelection:",@"c"]],@[@"查看",@[@"放大",@"zoomInMenu:",@"="],@[@"缩小",@"zoomOutMenu:",@"-"],@[@"适合画布",@"fit:",@"1"]]];
 for(NSArray *g in groups){NSMenuItem *top=[[NSMenuItem alloc]initWithTitle:g[0] action:nil keyEquivalent:@""];NSMenu *sub=[[NSMenu alloc]initWithTitle:g[0]];sub.autoenablesItems=NO;top.submenu=sub;[_restrictedMenu addItem:top];for(NSUInteger i=1;i<g.count;i++){NSArray *spec=g[i];NSMenuItem *item=[[NSMenuItem alloc]initWithTitle:spec[0] action:NSSelectorFromString(spec[1]) keyEquivalent:spec[2]];NSString *action=spec[1];item.target=([action isEqual:@"hide:"]||[action isEqual:@"terminate:"])?NSApp:([action isEqual:@"saveDocument:"]?_document:([action isEqual:@"performClose:"]?_window:self));[sub addItem:item];}}
}
// Reuse Sketch's menu items, localization, icons, shortcuts and action targets.
// Only these native copy selectors may enter the developer context menu.
- (id)nativeActionForSelector:(SEL)selector {
 SEL controllerSelector=NSSelectorFromString(@"actionsController"),lookup=NSSelectorFromString(@"actionForSelector:");
 if(![_document respondsToSelector:controllerSelector])return nil;
 id controller=((id(*)(id,SEL))[_document methodForSelector:controllerSelector])(_document,controllerSelector);
 return [controller respondsToSelector:lookup]?((id(*)(id,SEL,SEL))[controller methodForSelector:lookup])(controller,lookup,selector):nil;
}
- (NSMenuItem *)findNativeItem:(SEL)selector menu:(NSMenu *)menu {
 for(NSMenuItem *item in menu.itemArray){if(item.action==selector)return item;NSMenuItem *nested=[self findNativeItem:selector menu:item.submenu];if(nested)return nested;}return nil;
}
- (NSMenuItem *)nativeItemForSelector:(SEL)selector {
 id action=[self nativeActionForSelector:selector];if(!action||![action respondsToSelector:selector])return nil;
 NSMenuItem *source=nil;SEL itemsSelector=NSSelectorFromString(@"menuItems");
 if([action respondsToSelector:itemsSelector]){id items=((id(*)(id,SEL))[action methodForSelector:itemsSelector])(action,itemsSelector);if([items isKindOfClass:NSArray.class])for(NSMenuItem *item in items)if([item isKindOfClass:NSMenuItem.class]&&item.action==selector){source=item;break;}}
 if(!source)source=[self findNativeItem:selector menu:_originalMenu];if(!source)return nil;
 NSMenuItem *item=[source copy];item.submenu=nil;item.target=action;
 item.enabled=[action respondsToSelector:@selector(validateMenuItem:)]?[(id<NSMenuItemValidation>)action validateMenuItem:item]:YES;return item;
}
- (NSMenu *)nativeCopyMenuForEvent:(NSEvent *)event {
 NSMenu *menu=[NSMenu new];
 NSMenuItem *properties=[self nativeItemForSelector:NSSelectorFromString(@"copyProperties:")];
 if(!properties)properties=[self nativeItemForSelector:NSSelectorFromString(@"copyStyle:")];
 if(properties)[menu addItem:properties];
 for(NSString *selector in @[@"copyCSSAttributes:",@"copySVG:",@"copyLayerID:"]){NSMenuItem *item=[self nativeItemForSelector:NSSelectorFromString(selector)];if(item){if([selector isEqualToString:@"copyLayerID:"]&&menu.numberOfItems)[menu addItem:NSMenuItem.separatorItem];[menu addItem:item];}}
 return menu;
}
- (void)selectContextLayerForEvent:(NSEvent *)event {
 NSPoint point=[_canvas convertPoint:event.locationInWindow fromView:nil];
 if(NSPointInRect(point,_canvas.bounds)){point=SMPagePoint(_canvas,point);[self emit:@{@"kind":@"contextLayer",@"x":@(point.x),@"y":@(point.y),@"deep":@((event.modifierFlags&NSEventModifierFlagCommand)!=0)}];return;}
 NSView *hit=[self underlyingHitAtWindowPoint:event.locationInWindow];
 while(hit&&![hit isKindOfClass:NSOutlineView.class])hit=hit.superview;
 if([hit.identifier isEqualToString:@"LayerList"]){NSOutlineView *list=(id)hit;NSInteger row=[list rowAtPoint:[list convertPoint:event.locationInWindow fromView:nil]];if(row>=0){id item=[list itemAtRow:row],layer=[item respondsToSelector:@selector(layer)]?[item layer]:nil;if(layer)[self emit:@{@"kind":@"contextLayer",@"layer":layer}];}}
}
- (void)copySelection:(id)sender {
 id responder=_window.firstResponder;if([responder isKindOfClass:NSTextView.class]&&[(NSTextView *)responder selectedRange].length){[(NSTextView *)responder copy:sender];return;}
 id action=[self nativeActionForSelector:@selector(copy:)];
 if(action&&[action respondsToSelector:@selector(copy:)]){NSMenuItem *item=[self nativeItemForSelector:@selector(copy:)];if(item.enabled)[NSApp sendAction:@selector(copy:) to:action from:sender];}
}
- (void)zoomInMenu:(id)sender {[_canvas zoomIn];}
- (void)zoomOutMenu:(id)sender {[_canvas zoomOut];}
- (void)fit:(id)sender {if([_canvas respondsToSelector:@selector(centerLayersInCanvas)])[_canvas centerLayersInCanvas];}
- (void)tick {if(_closed)return;
 // Keep following the selected document even while this document is a hidden tab.
 [self emit:@{@"kind":@"focus"}];if(_closed||!_window.isVisible)return;
 if(![_paletteName isEqualToString:(SMDark(_bar)?@"dark":@"light")])[self applyPalette];if(_card){[self positionCommentCard];}
 if(!_layoutInFlight&&!_toolbarDragging&&((!_developer&&_canvas.bounds.size.width<980)!=_compactLayout))[self refreshButtons];
 if(!_layoutInFlight&&!_toolbarDragging){NSRect frame=[self toolbarFrameForWidth:_bar.frame.size.width];if(!NSEqualRects(_bar.frame,frame))_bar.frame=frame;}
 if(_developer){if(SMCurrent(_document,_window)||_window.isKeyWindow||_window.isMainWindow){[self makeMenu];if(NSApp.mainMenu!=_restrictedMenu)NSApp.mainMenu=_restrictedMenu;}else if(NSApp.mainMenu==_restrictedMenu)NSApp.mainMenu=_originalMenu;}
 [self emit:@{@"kind":@"tick"}];[self redrawCanvasOverlay];
}
- (void)positionCommentCard {
 if(!_card||!_pendingComment)return;NSPoint page=NSMakePoint([_pendingComment[@"pageX"]doubleValue],[_pendingComment[@"pageY"]doubleValue]);BOOL anchored=_pendingComment[@"pageX"]!=nil;
 for(NSDictionary *pin in _pins)if([pin[@"id"]isEqual:_pendingComment[@"id"]]){page=NSMakePoint([pin[@"x"]doubleValue],[pin[@"y"]doubleValue]);anchored=YES;break;}
 if(!anchored)return;NSPoint point=[_canvas convertPointFromPage:page];point=[_shield convertPoint:point fromView:_canvas];NSRect f=_card.frame;if(_developer){NSRect viewport=[_shield convertRect:_canvas.bounds fromView:_canvas];f=SMCommentBubbleFrame(point,f.size,viewport);}else{f.origin.x=MAX(16,MIN(_shield.bounds.size.width-f.size.width-16,point.x+60));f.origin.y=MAX(16,MIN(_shield.bounds.size.height-f.size.height-16,point.y-64));}if(!NSEqualRects(_card.frame,f)){_card.frame=f;[_window invalidateCursorRectsForView:_shield];}
}
- (NSButton *)cardButton:(NSString *)title frame:(NSRect)frame action:(SEL)action parent:(NSView *)parent {
 SMCommentButtonV62 *button=[[SMCommentButtonV62 alloc]initWithFrame:frame];button.title=title;button.target=self;button.action=action;button.font=[NSFont systemFontOfSize:13 weight:NSFontWeightMedium];button.bordered=NO;button.visualStyle=@"ghost";[button setAccessibilityLabel:title];[parent addSubview:button];return button;
}
- (void)updateCommentSubmit {
 NSCharacterSet *space=NSCharacterSet.whitespaceAndNewlineCharacterSet;
 _submitCommentButton.enabled=[_editorText.string stringByTrimmingCharactersInSet:space].length>0&&[_editorAuthor.stringValue stringByTrimmingCharactersInSet:space].length>0;[_submitCommentButton setNeedsDisplay:YES];
}
- (void)textDidChange:(NSNotification *)notification {[self updateCommentSubmit];}
- (void)controlTextDidChange:(NSNotification *)notification {[self updateCommentSubmit];}
- (void)showThreadJSON:(NSString *)json {
 NSDictionary *note=[NSJSONSerialization JSONObjectWithData:[json dataUsingEncoding:NSUTF8StringEncoding] options:0 error:nil];if(![note isKindOfClass:NSDictionary.class])return;
 [_card removeFromSuperview];_pendingComment=note;_editingReplyID=nil;_editorText=nil;_editorAuthor=nil;_composerTitle=nil;_submitCommentButton=nil;_cancelEditButton=nil;
 BOOL existing=note[@"id"]!=nil;NSRect commentViewport=[_shield convertRect:_canvas.bounds fromView:_canvas];CGFloat width=MIN(460,MAX(180,_developer?commentViewport.size.width-24:_shield.bounds.size.width-32)),pad=MIN(30,MAX(12,(width-100)/4)),bodyWidth=width-pad*2-40;
 NSMutableArray *entries=[NSMutableArray array],*heights=[NSMutableArray array];if(existing){[entries addObject:note];[entries addObjectsFromArray:note[@"replies"]?:@[]];}
 CGFloat natural=pad;for(NSDictionary *entry in entries){CGFloat h=SMCommentBodyHeight(entry[@"text"],bodyWidth);if(_developer)h=MAX(44,h);[heights addObject:@(h)];natural+=h+(_developer?58:56);}if(!existing)natural=0;
 CGFloat composerHeight=_developer?0:(existing?159:158),height=MIN(_developer?MAX(44,commentViewport.size.height-16):MAX(existing?203:158,_shield.bounds.size.height-32),natural+composerHeight),historyHeight=existing?MAX(44,height-composerHeight):0;
 SMCommentSurfaceV62 *card=[[SMCommentSurfaceV62 alloc]initWithFrame:NSMakeRect(16,16,width,height)];card.surfaceRole=_developer?@"bubble":@"card";card.wantsLayer=YES;card.layer.cornerRadius=_developer?0:30;card.layer.borderWidth=0;card.identifier=@"commentCard";[card setAccessibilityLabel:existing?@"标注详情":@"添加标注"];
 if(existing){
  NSScrollView *scroll=[[NSScrollView alloc]initWithFrame:NSMakeRect(0,0,width,historyHeight)];scroll.identifier=@"commentHistory";scroll.drawsBackground=NO;scroll.borderType=NSNoBorder;scroll.hasVerticalScroller=natural>historyHeight;scroll.scrollerStyle=NSScrollerStyleOverlay;scroll.autohidesScrollers=YES;
  SMCommentContentV62 *content=[[SMCommentContentV62 alloc]initWithFrame:NSMakeRect(0,0,width,natural)];CGFloat y=pad;
  for(NSUInteger i=0;i<entries.count;i++){
   NSDictionary *entry=entries[i];CGFloat h=[heights[i]doubleValue];NSString *author=entry[@"author"]?:@"设计";SMCommentRowV62 *row=[[SMCommentRowV62 alloc]initWithFrame:NSMakeRect(pad,y,width-pad*2,h+28)];row.identifier=@"annotationRow";[content addSubview:row];
   SMCommentAvatarV62 *avatar=[[SMCommentAvatarV62 alloc]initWithFrame:NSMakeRect(0,0,32,32)];avatar.avatarData=entry[@"avatar"];avatar.initial=author.length?[author substringWithRange:[author rangeOfComposedCharacterSequenceAtIndex:0]]:@"注";[avatar setAccessibilityLabel:author];[row addSubview:avatar];
   SMCommentLabelV62 *body=[SMCommentLabelV62 wrappingLabelWithString:@""];body.font=SMDialogFont(14,NO);body.textColor=SMCommentTone(@"ink");body.attributedStringValue=[[NSAttributedString alloc]initWithString:entry[@"text"]?:@"" attributes:SMCommentBodyAttributes()];body.selectable=YES;BOOL shortBody=_developer&&SMCommentBodyHeight(entry[@"text"],bodyWidth)<=22;body.frame=NSMakeRect(40,shortBody?5:0,bodyWidth,shortBody?22:h);body.identifier=@"annotationBody";[row addSubview:body];
   SMCommentLabelV62 *time=[SMCommentLabelV62 labelWithString:SMRelativeTime(entry[@"createdAt"])];time.toneRole=@"muted";time.font=SMDialogFont(12,NO);time.textColor=SMCommentTone(@"muted");time.frame=NSMakeRect(40,h+12,MAX(40,bodyWidth-64),16);time.toolTip=entry[@"createdAt"];time.identifier=@"annotationTime";[row addSubview:time];
   if(!_developer){NSString *identifier=i==0?@"root":entry[@"id"];SMCommentButtonV62 *edit=(id)[self cardButton:@"" frame:NSMakeRect(row.bounds.size.width-48,h+10,16,16) action:@selector(editEntry:) parent:row];edit.identifier=identifier;edit.lineSymbol=@"edit";edit.toolTip=@"编辑标注";[edit setAccessibilityLabel:@"编辑标注"];
    SMCommentButtonV62 *remove=(id)[self cardButton:@"" frame:NSMakeRect(row.bounds.size.width-18,h+10,16,16) action:@selector(deleteEntry:) parent:row];remove.identifier=identifier;remove.lineSymbol=@"delete";remove.toolTip=@"删除标注";[remove setAccessibilityLabel:@"删除标注"];edit.hidden=YES;remove.hidden=YES;row.actionButtons=@[edit,remove];}
   y+=h+(_developer?58:56);
  }
  scroll.documentView=content;[card addSubview:scroll];[content scrollPoint:NSZeroPoint];
 }
 if(!_developer){
  CGFloat top=existing?historyHeight+31:30;
  if(existing){SMCommentDividerV62 *line=[[SMCommentDividerV62 alloc]initWithFrame:NSMakeRect(pad,historyHeight,width-pad*2,1)];line.identifier=@"annotationDivider";[card addSubview:line];}
  _editorAuthor=[NSTextField new];_editorAuthor.stringValue=note[@"composerAuthor"]?:note[@"author"]?:@"设计师";
  NSScrollView *composer=[[NSScrollView alloc]initWithFrame:NSMakeRect(pad,top,width-pad*2,44)];composer.identifier=@"annotationComposer";composer.drawsBackground=NO;composer.borderType=NSNoBorder;composer.hasVerticalScroller=YES;composer.scrollerStyle=NSScrollerStyleOverlay;composer.autohidesScrollers=YES;
  SMCommentEditorV62 *editor=[[SMCommentEditorV62 alloc]initWithFrame:NSMakeRect(0,0,width-pad*2,44)];editor.placeholder=@"请输入文字评论…";editor.richText=NO;editor.drawsBackground=NO;editor.font=SMDialogFont(14,NO);editor.textColor=SMCommentTone(@"ink");editor.insertionPointColor=SMDialogColor(@"primary");editor.defaultParagraphStyle=SMCommentParagraph(22);editor.textContainerInset=NSZeroSize;editor.textContainer.lineFragmentPadding=0;editor.textContainer.widthTracksTextView=YES;editor.horizontallyResizable=NO;editor.verticallyResizable=YES;editor.autoresizingMask=NSViewWidthSizable;editor.delegate=self;editor.string=existing?@"":note[@"text"]?:@"";[editor setAccessibilityLabel:@"标注内容"];composer.documentView=editor;_editorText=editor;[card addSubview:composer];
  _editorBaseline=[editor.string copy];_authorBaseline=[_editorAuthor.stringValue copy];
  SMCommentButtonV62 *submit=(id)[self cardButton:@"" frame:NSMakeRect(width-pad-32,height-62,32,32) action:@selector(submitThread:) parent:card];submit.visualStyle=@"primary";submit.lineSymbol=@"send";submit.toolTip=existing?@"发送标注":@"添加标注";[submit setAccessibilityLabel:submit.toolTip];_submitCommentButton=submit;
  SMCommentButtonV62 *cancel=(id)[self cardButton:@"" frame:NSMakeRect(width-pad-64,height-56,20,20) action:@selector(cancelEdit:) parent:card];cancel.lineSymbol=@"close";cancel.hidden=YES;cancel.toolTip=@"取消编辑";[cancel setAccessibilityLabel:@"取消编辑"];_cancelEditButton=cancel;[self updateCommentSubmit];
 }
 SMApplySurfaceShadow(card,30,50);_card=card;if(existing)_selectedPinID=note[@"id"];[_shield addSubview:card];[self positionCommentCard];[_window invalidateCursorRectsForView:_shield];[self syncPinViews];if(!_developer)[_window makeFirstResponder:existing?_shield:_editorText];
}
- (void)closeThread:(id)sender{if([self canDiscardComment])[self closeComment];}
- (void)submitThread:(id)sender{if(_developer||!_submitCommentButton.enabled)return;NSMutableDictionary *event=[_pendingComment mutableCopy];event[@"kind"]=@"saveComment";event[@"op"]=_pendingComment[@"id"]?(_editingReplyID?([_editingReplyID isEqual:@"root"]?@"update":@"updateReply"):@"reply"):@"add";if(_editingReplyID)event[@"replyId"]=_editingReplyID;event[@"author"]=_editorAuthor.stringValue;event[@"text"]=_editorText.string;[self emit:event];}
- (void)editEntry:(NSButton *)button{if(_developer||![self canDiscardComment])return;NSDictionary *entry=_pendingComment;if(![button.identifier isEqual:@"root"])for(NSDictionary *reply in _pendingComment[@"replies"])if([reply[@"id"]isEqual:button.identifier]){entry=reply;break;}
 _editingReplyID=button.identifier;_editorText.string=entry[@"text"]?:@"";_editorAuthor.stringValue=entry[@"author"]?:@"";_editorBaseline=[_editorText.string copy];_authorBaseline=[_editorAuthor.stringValue copy];_submitCommentButton.toolTip=@"保存修改";[_submitCommentButton setAccessibilityLabel:@"保存修改"];_cancelEditButton.hidden=NO;[self updateCommentSubmit];[_window makeFirstResponder:_editorText];}
- (void)deleteEntry:(NSButton *)button{if(_developer||![self canDiscardComment])return;NSMutableDictionary *event=[_pendingComment mutableCopy];event[@"kind"]=@"saveComment";event[@"op"]=[button.identifier isEqual:@"root"]?@"delete":@"deleteReply";event[@"replyId"]=button.identifier;[self emit:event];}
- (void)cancelEdit:(id)sender{if(_developer||![self canDiscardComment])return;_editingReplyID=nil;_editorText.string=@"";_editorBaseline=@"";_editorAuthor.stringValue=_pendingComment[@"composerAuthor"]?:_pendingComment[@"author"]?:@"设计师";_authorBaseline=[_editorAuthor.stringValue copy];_submitCommentButton.toolTip=@"发送标注";[_submitCommentButton setAccessibilityLabel:@"发送标注"];_cancelEditButton.hidden=YES;[self updateCommentSubmit];}

- (BOOL)canDiscardComment {if(!_pendingComment||!_card||!_editorText)return YES;if([_editorText.string isEqualToString:_editorBaseline?:@""]&&[_editorAuthor.stringValue isEqualToString:_authorBaseline?:@""])return YES;NSString *json=@"{\"title\":\"操作确认\",\"message\":\"这条标注还有未保存的修改。放弃后，刚才输入的内容不会保存；选择“继续编辑”可以返回并保留当前输入。\",\"buttons\":[\"继续编辑\",\"放弃修改\"],\"primary\":0}";return [SMDeliveryAlertControllerV62 showJSON:json forWindow:_window]==NSAlertSecondButtonReturn;}
- (void)closeComment {_selectedPinID=nil;[_window makeFirstResponder:(_developer||_commentTool||_hand)?_shield:_canvas];[_card removeFromSuperview];_card=nil;_pendingComment=nil;_editorText=nil;_editorAuthor=nil;_editorBaseline=nil;_authorBaseline=nil;[_window invalidateCursorRectsForView:_shield];[self syncPinViews];}
- (void)shutdown {if(_closed)return;[self dismissExportChoices];[_pinLongPressTimer invalidate];_pinLongPressTimer=nil;[self setDesign];_closed=YES;[_displayTimer invalidate];_displayTimer=nil;[_timer invalidate];_timer=nil;if(_eventMonitor){[NSEvent removeMonitor:_eventMonitor];_eventMonitor=nil;}[[NSNotificationCenter defaultCenter]removeObserver:self];[_shield removeFromSuperview];[self emit:@{@"kind":@"closed"}];_eventDelegate=nil;}
@end

#import "DeliverySettings.h"
