// Geometry and typography follow the supplied 600 × 704 settings artboard.
#import "SettingsCameraIcon.h"
@interface SMSettingsRootV62 : SMDialogRootV62
@end
@implementation SMSettingsRootV62
- (void)drawRect:(NSRect)dirty{[super drawRect:dirty];[SMDialogColor(@"divider")setFill];NSRectFillUsingOperation(NSMakeRect(60,262,480,1),NSCompositingOperationSourceOver);NSRectFillUsingOperation(NSMakeRect(60,483,480,1),NSCompositingOperationSourceOver);}
@end
@interface SMSettingsSurfaceV62 : NSView
@property(nonatomic) BOOL focused;
@end
@implementation SMSettingsSurfaceV62
- (BOOL)isFlipped{return YES;}
- (void)drawRect:(NSRect)dirty{[SMDialogColor(@"field")setFill];NSBezierPath *p=[NSBezierPath bezierPathWithRoundedRect:self.bounds xRadius:12 yRadius:12];[p fill];if(_focused){[SMDialogColor(@"primary")setStroke];p=[NSBezierPath bezierPathWithRoundedRect:NSInsetRect(self.bounds,1,1) xRadius:11 yRadius:11];p.lineWidth=1.5;[p stroke];}}
- (void)setFocused:(BOOL)v{_focused=v;[self setNeedsDisplay:YES];}
@end
@interface SMSettingsAvatarButtonV62 : NSButton
@property(nonatomic,copy) NSString *avatarData;
@property(nonatomic) BOOL hovering;
@property NSTrackingArea *hoverArea;
@end
@implementation SMSettingsAvatarButtonV62
- (BOOL)isFlipped{return YES;}
- (void)updateTrackingAreas{[super updateTrackingAreas];if(_hoverArea)[self removeTrackingArea:_hoverArea];_hoverArea=[[NSTrackingArea alloc]initWithRect:NSZeroRect options:NSTrackingMouseEnteredAndExited|NSTrackingActiveInKeyWindow|NSTrackingInVisibleRect owner:self userInfo:nil];[self addTrackingArea:_hoverArea];}
- (void)mouseEntered:(NSEvent *)e{self.hovering=YES;}
- (void)mouseExited:(NSEvent *)e{self.hovering=NO;}
- (void)setHovering:(BOOL)value{_hovering=value;[self setNeedsDisplay:YES];}
- (void)setAvatarData:(NSString *)value{_avatarData=[value copy];[self setNeedsDisplay:YES];}
- (void)drawRect:(NSRect)dirty{SMDrawAvatar(_avatarData,@"注",self.bounds,YES);if(_hovering||self.highlighted){[NSGraphicsContext saveGraphicsState];[[NSBezierPath bezierPathWithOvalInRect:self.bounds]addClip];[[NSColor colorWithWhite:0 alpha:.4]setFill];NSRectFillUsingOperation(self.bounds,NSCompositingOperationSourceOver);[SMSettingsCameraIcon()drawInRect:NSMakeRect(40,40,40,40) fromRect:NSZeroRect operation:NSCompositingOperationSourceOver fraction:1 respectFlipped:YES hints:nil];[NSGraphicsContext restoreGraphicsState];}}
@end
static void SMSettingsChevron(NSRect bounds){NSBezierPath *p=[NSBezierPath bezierPath];CGFloat x=NSMidX(bounds),y=NSMidY(bounds);[p moveToPoint:NSMakePoint(x-3.2,y-1.6)];[p lineToPoint:NSMakePoint(x,y+1.6)];[p lineToPoint:NSMakePoint(x+3.2,y-1.6)];p.lineWidth=.8;p.lineCapStyle=NSLineCapStyleRound;p.lineJoinStyle=NSLineJoinStyleRound;[SMDialogColor(@"ink")setStroke];[p stroke];}
@interface SMSettingsArrowV62 : NSButton
@end
@implementation SMSettingsArrowV62
- (BOOL)isFlipped{return YES;}
- (void)drawRect:(NSRect)dirty{SMSettingsChevron(NSMakeRect(self.bounds.size.width-20,(self.bounds.size.height-20)/2,16,20));}
@end
@interface SMSettingsPopupV62 : NSPopUpButton
@end
@implementation SMSettingsPopupV62
- (BOOL)isFlipped{return YES;}
- (void)drawRect:(NSRect)dirty{[SMDialogColor(@"field")setFill];[[NSBezierPath bezierPathWithRoundedRect:self.bounds xRadius:12 yRadius:12]fill];SMDialogText(self.title,NSMakeRect(16,0,self.bounds.size.width-32,self.bounds.size.height),SMDialogFont(14,NO),SMDialogColor(@"ink"),NSTextAlignmentCenter);SMSettingsChevron(NSMakeRect(self.bounds.size.width-18,10,12,20));}
@end
@interface SMSettingsUnitsV62 : NSView
@property(nonatomic) NSInteger selectedSegment,segmentCount;
@property(nonatomic) NSSegmentSwitchTracking trackingMode;
@property(nonatomic,strong) NSFont *font;
@property(nonatomic,strong) NSMutableArray<NSString *> *segmentLabels;
- (void)setLabel:(NSString *)label forSegment:(NSInteger)segment;
- (void)setWidth:(CGFloat)width forSegment:(NSInteger)segment;
- (NSString *)labelForSegment:(NSInteger)segment;
@end
@implementation SMSettingsUnitsV62
- (void)drawFocusRingMask {}
- (BOOL)isFlipped{return YES;}
- (instancetype)initWithFrame:(NSRect)frame{if((self=[super initWithFrame:frame])){_selectedSegment=-1;_segmentLabels=[NSMutableArray new];}return self;}
- (void)setSelectedSegment:(NSInteger)value{_selectedSegment=value;[self setNeedsDisplay:YES];}
- (void)setSegmentCount:(NSInteger)value{_segmentCount=value;while(_segmentLabels.count<(NSUInteger)value)[_segmentLabels addObject:@""];if(_segmentLabels.count>(NSUInteger)value)[_segmentLabels removeObjectsInRange:NSMakeRange(value,_segmentLabels.count-value)];[self setNeedsDisplay:YES];}
- (void)setLabel:(NSString *)label forSegment:(NSInteger)segment{if(segment>=0&&segment<_segmentLabels.count)_segmentLabels[segment]=label?:@"";[self setNeedsDisplay:YES];}
- (void)setWidth:(CGFloat)width forSegment:(NSInteger)segment{}
- (NSString *)labelForSegment:(NSInteger)segment{return segment>=0&&segment<_segmentLabels.count?_segmentLabels[segment]:@"";}
- (void)mouseDown:(NSEvent *)event{[self.window makeFirstResponder:self];NSPoint p=[self convertPoint:event.locationInWindow fromView:nil];CGFloat itemWidth=MAX(1,(self.bounds.size.width-8)/MAX(1,self.segmentCount));self.selectedSegment=MAX(0,MIN(self.segmentCount-1,(NSInteger)floor((p.x-4)/itemWidth)));}
- (void)keyDown:(NSEvent *)event{if(event.keyCode==123||event.keyCode==124){self.selectedSegment=MAX(0,MIN(self.segmentCount-1,self.selectedSegment+(event.keyCode==124?1:-1)));return;}[super keyDown:event];}
- (void)drawRect:(NSRect)dirty{[SMDialogColor(@"field")setFill];[[NSBezierPath bezierPathWithRoundedRect:self.bounds xRadius:12 yRadius:12]fill];CGFloat itemWidth=MAX(1,(self.bounds.size.width-8)/MAX(1,self.segmentCount));if(self.selectedSegment>=0&&self.selectedSegment<self.segmentCount){NSColor *accent=SMAccent();[[accent colorWithAlphaComponent:.2]setFill];[[NSBezierPath bezierPathWithRoundedRect:NSMakeRect(4+self.selectedSegment*itemWidth,4,itemWidth-4,self.bounds.size.height-8) xRadius:10 yRadius:10]fill];}for(NSInteger i=0;i<self.segmentCount;i++){BOOL active=i==self.selectedSegment;NSColor *ink=active?[SMAccent() colorWithAlphaComponent:1]:SMDialogColor(@"ink");SMDialogText([self labelForSegment:i],NSMakeRect(4+i*itemWidth,4,itemWidth-4,self.bounds.size.height-8),self.font?:SMDialogFont(14,NO),ink,NSTextAlignmentCenter);}}
@end
@interface SMSettingsCheckV62 : NSButton
@end
@implementation SMSettingsCheckV62
- (BOOL)isFlipped{return YES;}
- (void)setState:(NSControlStateValue)value{[super setState:value];[self setNeedsDisplay:YES];}
- (void)drawRect:(NSRect)dirty{BOOL on=self.state==NSControlStateValueOn;[(on?SMDialogColor(@"primary"):SMDialogColor(@"divider"))setFill];[[NSBezierPath bezierPathWithOvalInRect:NSMakeRect(2.5,2.5,15,15)]fill];if(on){[NSColor.whiteColor setStroke];NSBezierPath *p=[NSBezierPath bezierPath];p.lineWidth=1.5;p.lineCapStyle=NSLineCapStyleRound;p.lineJoinStyle=NSLineJoinStyleRound;[p moveToPoint:NSMakePoint(6.5,10)];[p lineToPoint:NSMakePoint(9,12.5)];[p lineToPoint:NSMakePoint(13.5,7.5)];[p stroke];}SMDialogText(self.title,NSMakeRect(30,0,self.bounds.size.width-30,20),SMDialogFont(16,NO),SMDialogColor(@"ink"),NSTextAlignmentLeft);}
@end
@interface SMDeliverySettingsControllerV62 : NSObject<NSTextFieldDelegate,NSWindowDelegate>
@property NSPanel *panel;
@property NSAlert *nativeShell;
@property SMSettingsRootV62 *root;
@property SMSettingsAvatarButtonV62 *avatar;
@property NSTextField *name,*scale;
@property SMSettingsUnitsV62 *units;
@property SMSettingsPopupV62 *formats;
@property NSButton *webSlices,*zip,*saveButton,*cancelButton;
@property(copy) NSDictionary *draft;
@property(copy) NSString *resultJSON,*errorMessage;
+ (NSString *)showSettingsJSON:(NSString *)json forWindow:(NSWindow *)parent;
- (instancetype)initWithJSON:(NSString *)json forWindow:(NSWindow *)parent;
- (void)presentError:(NSString *)message;
@end
@implementation SMDeliverySettingsControllerV62
- (SMSettingsSurfaceV62 *)surface:(NSRect)rect{SMSettingsSurfaceV62 *v=[[SMSettingsSurfaceV62 alloc]initWithFrame:rect];[_root addSubview:v];return v;}
- (NSTextField *)label:(NSString *)value y:(CGFloat)y{NSTextField *v=[NSTextField labelWithString:value];v.frame=NSMakeRect(60,y+8,160,24);v.font=SMDialogFont(16,NO);v.textColor=SMDialogColor(@"ink");[_root addSubview:v];return v;}
- (NSTextField *)field:(NSString *)value frame:(NSRect)frame font:(CGFloat)size label:(NSString *)label parent:(NSView *)parent{NSTextField *v=[[NSTextField alloc]initWithFrame:frame];v.stringValue=value;v.font=SMDialogFont(size,NO);v.textColor=SMDialogColor(@"ink");v.drawsBackground=NO;v.bezeled=NO;v.focusRingType=NSFocusRingTypeNone;v.alignment=NSTextAlignmentCenter;v.delegate=self;[v setAccessibilityLabel:label];[parent addSubview:v];return v;}
- (SMDialogButtonV62 *)button:(NSString *)title rect:(NSRect)rect primary:(BOOL)primary action:(SEL)action{SMDialogButtonV62 *b=[[SMDialogButtonV62 alloc]initWithFrame:rect];b.title=title;b.font=SMDialogFont(14,NO);b.primary=primary;b.bordered=NO;b.target=self;b.action=action;[_root addSubview:b];return b;}
- (instancetype)initWithJSON:(NSString *)json forWindow:(NSWindow *)parent{if((self=[super init])){NSDictionary *data=[NSJSONSerialization JSONObjectWithData:[json dataUsingEncoding:NSUTF8StringEncoding] options:0 error:nil];if(![data isKindOfClass:NSDictionary.class])return nil;_draft=data;_panel=SMDialogPanel(NSMakeSize(600,704),@"交付设置",parent,&_nativeShell);_panel.delegate=self;_root=[[SMSettingsRootV62 alloc]initWithFrame:NSMakeRect(0,0,600,704)];_root.radius=60;_root.cancelTarget=self;_root.cancelAction=@selector(cancel:);SMDialogInstallRoot(_panel,_root);
 _avatar=[[SMSettingsAvatarButtonV62 alloc]initWithFrame:NSMakeRect(240,40,120,120)];_avatar.avatarData=data[@"avatar"];_avatar.bordered=NO;_avatar.target=self;_avatar.action=@selector(chooseAvatar:);_avatar.toolTip=@"点击上传头像";[_avatar setAccessibilityLabel:@"上传标注头像"];[_root addSubview:_avatar];
 SMSettingsSurfaceV62 *nameSurface=[self surface:NSMakeRect(60,180,480,52)],*scaleSurface=[self surface:NSMakeRect(229,293,310,40)];_name=[self field:[data[@"name"]isKindOfClass:NSString.class]?data[@"name"]:@"" frame:NSMakeRect(14,12,452,28) font:16 label:@"标注名字" parent:nameSurface];_name.placeholderString=@"输入你的名字";
 [self label:@"设计倍率" y:293];[self label:@"标注单位" y:353];[self label:@"默认颜色格式" y:413];_scale=[self field:[NSString stringWithFormat:@"%@",data[@"scale"]?:@1] frame:NSMakeRect(16,8,246,24) font:14 label:@"设计倍率" parent:scaleSurface];SMSettingsArrowV62 *arrow=[[SMSettingsArrowV62 alloc]initWithFrame:NSMakeRect(262,0,48,40)];arrow.bordered=NO;arrow.target=self;arrow.action=@selector(scaleOptions:);[arrow setAccessibilityLabel:@"选择常用设计倍率"];arrow.toolTip=@"选择常用设计倍率";[scaleSurface addSubview:arrow];
 _units=[[SMSettingsUnitsV62 alloc]initWithFrame:NSMakeRect(230,353,310,40)];_units.focusRingType=NSFocusRingTypeNone;_units.segmentCount=3;_units.trackingMode=NSSegmentSwitchTrackingSelectOne;_units.font=SMDialogFont(14,NO);for(NSInteger i=0;i<3;i++){[_units setLabel:@[@"像素 (px)",@"点 (pt)",@"dp / sp"][i] forSegment:i];[_units setWidth:102 forSegment:i];}NSUInteger unit=[@[@"px",@"pt",@"dp/sp"]indexOfObject:data[@"unit"]];_units.selectedSegment=unit==NSNotFound?0:unit;[_units setAccessibilityLabel:@"标注单位"];[_root addSubview:_units];
 _formats=[[SMSettingsPopupV62 alloc]initWithFrame:NSMakeRect(229,413,310,40) pullsDown:NO];[_formats addItemsWithTitles:@[@"十六进制色值",@"CSS RGBA",@"Android ARGB"]];NSUInteger format=[@[@"color-hex",@"css-rgba",@"argb-hex"]indexOfObject:data[@"colorFormat"]];[_formats selectItemAtIndex:format==NSNotFound?0:format];_formats.bordered=NO;_formats.font=SMDialogFont(14,NO);[_formats setAccessibilityLabel:@"默认颜色格式"];[_root addSubview:_formats];
 SMSettingsCheckV62 *web=[[SMSettingsCheckV62 alloc]initWithFrame:NSMakeRect(60,514,480,20)];web.title=@"导出HTML文件时补切名称含 icon／图标 的编组（1x/2x/3x）";web.buttonType=NSButtonTypeSwitch;web.bordered=NO;web.state=[data[@"webSlices"]boolValue]?NSControlStateValueOn:NSControlStateValueOff;[_root addSubview:web];_webSlices=web;
 SMSettingsCheckV62 *zip=[[SMSettingsCheckV62 alloc]initWithFrame:NSMakeRect(60,564,480,20)];zip.title=@"导出HTML文件后同时生成完整交付压缩包";zip.buttonType=NSButtonTypeSwitch;zip.bordered=NO;zip.state=[data[@"zip"]boolValue]?NSControlStateValueOn:NSControlStateValueOff;[_root addSubview:zip];_zip=zip;
 _cancelButton=[self button:@"取消" rect:NSMakeRect(150,624,140,40) primary:NO action:@selector(cancel:)];_cancelButton.keyEquivalent=@"\e";_cancelButton.keyEquivalentModifierMask=0;_saveButton=[self button:@"保存" rect:NSMakeRect(310,624,140,40) primary:YES action:@selector(save:)];_saveButton.keyEquivalent=@"\r";_saveButton.keyEquivalentModifierMask=0;_panel.defaultButtonCell=(NSButtonCell *)_saveButton.cell;
 NSArray<NSView *> *order=@[_name,_avatar,_scale,arrow,_units,_formats,_webSlices,_zip,_cancelButton,_saveButton];for(NSUInteger i=0;i<order.count;i++)order[i].nextKeyView=order[(i+1)%order.count];_panel.initialFirstResponder=_root;SMDialogPlace(_panel,_root,parent,NSMakeSize(600,704));
 }return self;}
- (void)scaleOptions:(NSButton *)sender{NSMenu *menu=[[NSMenu alloc]initWithTitle:@"设计倍率"];menu.autoenablesItems=NO;for(NSString *value in @[@"0.5",@"1",@"2",@"3",@"4"]){NSMenuItem *item=[[NSMenuItem alloc]initWithTitle:[value stringByAppendingString:@"x"] action:@selector(selectScale:) keyEquivalent:@""];item.target=self;item.enabled=YES;item.representedObject=value;item.state=[value isEqual:_scale.stringValue]?NSControlStateValueOn:NSControlStateValueOff;[menu addItem:item];}[menu popUpMenuPositioningItem:nil atLocation:NSMakePoint(0,sender.bounds.size.height) inView:sender];}
- (void)selectScale:(NSMenuItem *)item{_scale.stringValue=item.representedObject;_errorMessage=nil;}
- (void)controlTextDidBeginEditing:(NSNotification *)note{if([((NSView *)note.object).superview isKindOfClass:SMSettingsSurfaceV62.class])((SMSettingsSurfaceV62 *)((NSView *)note.object).superview).focused=YES;}
- (void)controlTextDidEndEditing:(NSNotification *)note{if([((NSView *)note.object).superview isKindOfClass:SMSettingsSurfaceV62.class])((SMSettingsSurfaceV62 *)((NSView *)note.object).superview).focused=NO;}
- (void)controlTextDidChange:(NSNotification *)note{_errorMessage=nil;}
- (void)presentError:(NSString *)message{_errorMessage=message;NSDictionary *payload=@{@"title":@"请检查设置内容",@"message":message,@"buttons":@[@"知道了"]};NSString *json=[[NSString alloc]initWithData:[NSJSONSerialization dataWithJSONObject:payload options:0 error:nil] encoding:NSUTF8StringEncoding];[SMDeliveryAlertControllerV62 showJSON:json forWindow:_panel];}
- (BOOL)applyAvatarFile:(NSString *)path{NSString *encoded=[SMNativeDeveloperControllerV62 avatarDataForFile:path];if(!SMAvatarImage(encoded)){[self presentError:@"这张图片暂时无法用作头像。请换一张能正常打开、且不超过 20 MB 的 PNG、JPG、HEIC、TIFF 或 WebP 图片。原来的头像会保留。"];return NO;}_avatar.avatarData=encoded;_errorMessage=nil;return YES;}
- (void)chooseAvatar:(id)sender{NSOpenPanel *picker=[NSOpenPanel openPanel];picker.title=@"选择标注头像";picker.prompt=@"使用头像";picker.canChooseFiles=YES;picker.canChooseDirectories=NO;picker.allowsMultipleSelection=NO;picker.allowedFileTypes=@[@"png",@"jpg",@"jpeg",@"heic",@"tiff",@"webp"];if([picker runModal]==NSModalResponseOK)[self applyAvatarFile:picker.URL.path];}
- (void)save:(id)sender{[_panel makeFirstResponder:nil];NSString *name=[_name.stringValue stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];NSScanner *scanner=[NSScanner scannerWithString:_scale.stringValue];double scale;BOOL valid=[scanner scanDouble:&scale]&&scanner.isAtEnd&&isfinite(scale)&&scale>0&&scale<=100;_errorMessage=nil;
 if(!name.length||name.length>80){[self presentError:!name.length?@"请填写标注名字，方便同事识别你的标注。名字最多 80 个字。":@"标注名字超过了 80 个字，请缩短后再保存。"];[_panel makeFirstResponder:_name];return;}
 if(!valid){[self presentError:@"请输入大于 0、且不超过 100 的设计倍率，例如 1 或 2。修改后再点击保存。"];[_panel makeFirstResponder:_scale];return;}
 NSDictionary *result=@{@"name":name,@"avatar":_avatar.avatarData?:@"",@"scale":@(scale),@"unit":@[@"px",@"pt",@"dp/sp"][MAX(0,MIN(2,_units.selectedSegment))],@"colorFormat":@[@"color-hex",@"css-rgba",@"argb-hex"][MAX(0,MIN(2,_formats.indexOfSelectedItem))],@"webSlices":@(_webSlices.state==NSControlStateValueOn),@"zip":@(_zip.state==NSControlStateValueOn)};_resultJSON=[[NSString alloc]initWithData:[NSJSONSerialization dataWithJSONObject:result options:0 error:nil] encoding:NSUTF8StringEncoding];if(NSApp.modalWindow==_panel)[NSApp stopModalWithCode:NSModalResponseOK];[_panel orderOut:nil];}
- (void)cancel:(id)sender{_resultJSON=nil;if(NSApp.modalWindow==_panel)[NSApp stopModalWithCode:NSModalResponseCancel];[_panel orderOut:nil];}
- (BOOL)windowShouldClose:(NSWindow *)sender{[self cancel:nil];return YES;}
+ (NSString *)showSettingsJSON:(NSString *)json forWindow:(NSWindow *)parent{SMDeliverySettingsControllerV62 *c=[[self alloc]initWithJSON:json forWindow:parent];if(!c)return nil;if(parent)[parent addChildWindow:c.panel ordered:NSWindowAbove];[c.panel makeKeyAndOrderFront:nil];[NSApp runModalForWindow:c.panel];NSString *result=c.resultJSON;if(parent)[parent removeChildWindow:c.panel];[c.panel close];return result;}
@end
