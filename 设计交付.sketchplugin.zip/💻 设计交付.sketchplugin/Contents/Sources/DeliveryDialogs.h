@interface SMDialogPanelV62 : NSPanel
@property(nonatomic,weak) id cancelTarget;
@property(nonatomic) SEL cancelAction;
@end
@implementation SMDialogPanelV62
- (BOOL)canBecomeKeyWindow{return YES;}
- (void)cancelOperation:(id)sender{if(_cancelAction)[NSApp sendAction:_cancelAction to:_cancelTarget from:self];}
@end
// Use macOS's built-in Chinese system face; no font files are bundled or
// registered, so the plugin renders consistently after moving to another Mac.
static NSFont *SMDialogFont(CGFloat size,BOOL medium){
 NSFont *font=[NSFont fontWithName:medium?@"PingFangSC-Medium":@"PingFangSC-Regular" size:size];
 return font?:[NSFont systemFontOfSize:size weight:medium?NSFontWeightMedium:NSFontWeightRegular];
}
static NSColor *SMDialogColor(NSString *role){return [NSColor colorWithName:[@"DeliveryDialog." stringByAppendingString:role] dynamicProvider:^NSColor *(NSAppearance *appearance){BOOL dark=[[appearance bestMatchFromAppearancesWithNames:@[NSAppearanceNameAqua,NSAppearanceNameDarkAqua]]isEqual:NSAppearanceNameDarkAqua];
 if([role isEqual:@"ink"])return [NSColor colorWithWhite:dark?1:0 alpha:.902];
 if([role isEqual:@"field"])return [NSColor colorWithWhite:dark?1:0 alpha:dark?.065:.039];
 if([role isEqual:@"divider"])return [NSColor colorWithWhite:dark?1:0 alpha:dark?.12:.059];
 if([role isEqual:@"secondary"])return [NSColor colorWithWhite:dark?1:0 alpha:dark?.10:.059];
 if([role isEqual:@"selection"])return dark?[NSColor colorWithWhite:.28 alpha:1]:NSColor.whiteColor;
 if([role isEqual:@"warning"])return [NSColor colorWithSRGBRed:1 green:125./255 blue:0 alpha:1];
 return SMAccent();}];}
static void SMDialogText(NSString *text,NSRect rect,NSFont *font,NSColor *color,NSTextAlignment align){NSMutableParagraphStyle *p=[NSMutableParagraphStyle new];p.alignment=align;p.lineBreakMode=NSLineBreakByTruncatingTail;NSDictionary *attrs=@{NSFontAttributeName:font,NSForegroundColorAttributeName:color,NSParagraphStyleAttributeName:p};CGFloat height=[text sizeWithAttributes:attrs].height;[text drawInRect:NSMakeRect(rect.origin.x,NSMidY(rect)-height/2,rect.size.width,height) withAttributes:attrs];}
@interface SMDialogRootV62 : NSView
@property(nonatomic) CGFloat radius;
@property(nonatomic,weak) id cancelTarget;
@property(nonatomic) SEL cancelAction;
@end
@implementation SMDialogRootV62
- (void)cancelOperation:(id)sender{if(_cancelAction)[NSApp sendAction:_cancelAction to:_cancelTarget from:self];}
- (BOOL)isFlipped{return YES;}
- (void)drawRect:(NSRect)dirty{}
- (void)viewDidChangeEffectiveAppearance{[super viewDidChangeEffectiveAppearance];[self setNeedsDisplay:YES];[self.superview setNeedsDisplay:YES];for(NSView *v in self.subviews)[v setNeedsDisplay:YES];}
@end
// Draw the heading inside its exact layout bounds, without NSTextFieldCell's
// platform-dependent text insets. Accessibility still exposes a static label.
@interface SMDialogHeadingV62 : NSTextField
@end
@implementation SMDialogHeadingV62
- (BOOL)isFlipped{return YES;}
- (void)drawRect:(NSRect)dirty{NSMutableParagraphStyle *p=[NSMutableParagraphStyle new];p.alignment=NSTextAlignmentCenter;p.minimumLineHeight=24;p.maximumLineHeight=24;p.lineBreakMode=NSLineBreakByWordWrapping;NSDictionary *attrs=@{NSFontAttributeName:self.font,NSForegroundColorAttributeName:self.textColor,NSParagraphStyleAttributeName:p};[self.stringValue drawWithRect:self.bounds options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading attributes:attrs];}
@end
@interface SMDialogButtonV62 : NSButton
@property(nonatomic) BOOL primary;
@end
@implementation SMDialogButtonV62
- (BOOL)isFlipped{return YES;}
- (void)drawRect:(NSRect)dirty{NSColor *background=SMDialogColor(_primary?@"primary":@"secondary");if(self.highlighted)background=[background blendedColorWithFraction:.1 ofColor:NSColor.blackColor];[background setFill];[[NSBezierPath bezierPathWithRoundedRect:self.bounds xRadius:12 yRadius:12]fill];SMDialogText(self.title,self.bounds,self.font?:SMDialogFont(14,NO),_primary?NSColor.whiteColor:SMDialogColor(@"ink"),NSTextAlignmentCenter);if(self.window.firstResponder==self){[SMDialogColor(@"primary")setStroke];NSBezierPath *focus=[NSBezierPath bezierPathWithRoundedRect:NSInsetRect(self.bounds,1,1) xRadius:11 yRadius:11];focus.lineWidth=1.5;[focus stroke];}}
@end
static void SMDialogPlace(NSPanel *panel,SMDialogRootV62 *root,NSWindow *parent,NSSize design){
 NSScreen *screen=parent.screen?:NSScreen.mainScreen;NSRect visible=screen.visibleFrame;NSSize size=NSMakeSize(design.width,design.height);[panel setContentSize:size];NSView *content=panel.contentView;root.autoresizingMask=NSViewWidthSizable|NSViewHeightSizable;root.frame=content.bounds;root.bounds=NSMakeRect(0,0,design.width,design.height);[content addSubview:root];[root setNeedsDisplay:YES];NSRect owner=parent?parent.frame:visible;NSRect f=panel.frame;f.origin=NSMakePoint(NSMidX(owner)-f.size.width/2,NSMidY(owner)-f.size.height/2);f.origin.x=MAX(NSMinX(visible)+12,MIN(NSMaxX(visible)-f.size.width-12,f.origin.x));f.origin.y=MAX(NSMinY(visible)+12,MIN(NSMaxY(visible)-f.size.height-12,f.origin.y));[panel setFrame:f display:NO];
}
// Keep AppKit's NSAlert panel intact so macOS supplies its translucent
// material, rounded edge and shadow. The plugin only replaces the content.
static SMDialogPanelV62 *SMDialogPanel(NSSize size,NSString *title,NSWindow *parent,NSAlert *__strong *shell){NSAlert *alert=[NSAlert new];alert.alertStyle=NSAlertStyleWarning;alert.messageText=@" ";alert.informativeText=@"";[alert addButtonWithTitle:@" "];SMDialogPanelV62 *panel=(id)alert.window;panel.releasedWhenClosed=NO;panel.title=title;panel.movableByWindowBackground=YES;panel.appearance=parent.effectiveAppearance;panel.level=NSModalPanelWindowLevel;if(shell)*shell=alert;return panel;}
static void SMDialogInstallRoot(NSPanel *panel,SMDialogRootV62 *root){NSView *content=panel.contentView;for(NSView *view in content.subviews)view.hidden=YES;root.frame=content.bounds;root.autoresizingMask=NSViewWidthSizable|NSViewHeightSizable;[content addSubview:root];}
@interface SMDeliveryAlertControllerV62 : NSObject<NSWindowDelegate>
@property SMDialogPanelV62 *panel;
@property SMDialogRootV62 *root;
@property NSAlert *nativeShell;
@property NSTextView *messageView;
@property NSArray<NSButton *> *buttons;
@property NSInteger result,cancelResult;
- (instancetype)initWithJSON:(NSString *)json forWindow:(NSWindow *)parent;
+ (NSInteger)showJSON:(NSString *)json forWindow:(NSWindow *)parent;
@end
static NSInteger SMDialogCancelIndex(NSArray *labels){
 for(NSUInteger i=0;i<labels.count;i++){NSString *label=[labels[i]isKindOfClass:NSString.class]?labels[i]:@"";if([label hasPrefix:@"取消"]||[label isEqual:@"关闭"]||[label.lowercaseString isEqual:@"cancel"]||[label.lowercaseString isEqual:@"close"])return (NSInteger)i;}return NSNotFound;
}
static NSString *SMDialogPromptTitle(NSArray *labels){for(id value in labels){if(![value isKindOfClass:NSString.class])continue;NSString *label=[value lowercaseString];if([label hasPrefix:@"删除"]||[label hasPrefix:@"放弃"]||[label hasPrefix:@"delete"]||[label hasPrefix:@"discard"])return @"操作确认";}return @"提示";}
static NSString *SMDialogPromptMessage(NSString *message){NSRegularExpression *pattern=[NSRegularExpression regularExpressionWithPattern:@"[。．.]+(?=[ \\t]*(?:\\r?\\n|$))" options:0 error:nil];return [pattern stringByReplacingMatchesInString:message options:0 range:NSMakeRange(0,message.length) withTemplate:@""];}
static NSUInteger SMDialogLineCount(NSTextView *textView){if(!textView.string.length)return 0;NSLayoutManager *layout=textView.layoutManager;NSTextContainer *container=textView.textContainer;[layout ensureLayoutForTextContainer:container];NSRange glyphs=[layout glyphRangeForTextContainer:container];__block NSUInteger count=0;[layout enumerateLineFragmentsForGlyphRange:glyphs usingBlock:^(NSRect rect,NSRect usedRect,NSTextContainer *textContainer,NSRange glyphRange,BOOL *stop){count++;}];return count;}
@implementation SMDeliveryAlertControllerV62
- (instancetype)initWithJSON:(NSString *)json forWindow:(NSWindow *)parent{if((self=[super init])){NSDictionary *data=[NSJSONSerialization JSONObjectWithData:[json dataUsingEncoding:NSUTF8StringEncoding] options:0 error:nil];if(![data isKindOfClass:NSDictionary.class])return nil;NSString *title=[data[@"title"]isKindOfClass:NSString.class]?data[@"title"]:@"暂时无法完成操作",*body=[data[@"message"]isKindOfClass:NSString.class]?data[@"message"]:@"";NSArray *labels=[data[@"buttons"]isKindOfClass:NSArray.class]&&[data[@"buttons"]count]?data[@"buttons"]:@[@"知道了"];NSInteger primary=MAX(0,MIN((NSInteger)labels.count-1,[data[@"primary"]integerValue]));NSInteger cancel=SMDialogCancelIndex(labels);if(primary==cancel&&labels.count>1){for(NSInteger i=labels.count-1;i>=0;i--)if(i!=cancel){primary=i;break;}}_cancelResult=NSAlertFirstButtonReturn+(cancel==NSNotFound?primary:cancel);_result=_cancelResult;
 title=SMDialogPromptTitle(labels);body=SMDialogPromptMessage(body);
 CGFloat width=460,inset=30,contentWidth=width-inset*2,top=30,titleGap=30,actionGap=30,bottom=30,buttonHeight=40;
 NSMutableParagraphStyle *headingParagraph=[NSMutableParagraphStyle new];headingParagraph.minimumLineHeight=24;headingParagraph.maximumLineHeight=24;headingParagraph.alignment=NSTextAlignmentCenter;headingParagraph.lineBreakMode=NSLineBreakByWordWrapping;
 CGFloat titleHeight=MAX(24,ceil([title boundingRectWithSize:NSMakeSize(contentWidth,CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading attributes:@{NSFontAttributeName:SMDialogFont(16,YES),NSParagraphStyleAttributeName:headingParagraph}].size.height));
 NSMutableParagraphStyle *paragraph=[NSMutableParagraphStyle new];paragraph.minimumLineHeight=22;paragraph.maximumLineHeight=22;paragraph.lineBreakMode=NSLineBreakByWordWrapping;NSDictionary *attrs=@{NSFontAttributeName:SMDialogFont(14,NO),NSParagraphStyleAttributeName:paragraph,NSForegroundColorAttributeName:SMDialogColor(@"ink")};
 _messageView=[[NSTextView alloc]initWithFrame:NSMakeRect(0,0,contentWidth,1)];_messageView.editable=NO;_messageView.selectable=YES;_messageView.drawsBackground=NO;_messageView.textContainerInset=NSZeroSize;_messageView.textContainer.lineFragmentPadding=0;_messageView.textContainer.widthTracksTextView=YES;_messageView.textContainer.containerSize=NSMakeSize(contentWidth,CGFLOAT_MAX);[_messageView.textStorage setAttributedString:[[NSAttributedString alloc]initWithString:body attributes:attrs]];[_messageView.layoutManager ensureLayoutForTextContainer:_messageView.textContainer];CGFloat natural=body.length?ceil(NSMaxY([_messageView.layoutManager usedRectForTextContainer:_messageView.textContainer])):0;NSUInteger lineCount=SMDialogLineCount(_messageView);
 paragraph.alignment=lineCount<=1?NSTextAlignmentCenter:NSTextAlignmentLeft;[_messageView.textStorage setAttributedString:[[NSAttributedString alloc]initWithString:body attributes:attrs]];
 CGFloat bodyY=top+titleHeight+(body.length?titleGap:0);NSScreen *screen=parent.screen?:NSScreen.mainScreen;CGFloat maxBody=MAX(22,screen.visibleFrame.size.height-24-160-bodyY-actionGap-buttonHeight-bottom);CGFloat bodyHeight=MIN(natural,maxBody),buttonY=bodyY+bodyHeight+actionGap,height=buttonY+buttonHeight+bottom;
 _panel=SMDialogPanel(NSMakeSize(460,height),title,parent,&_nativeShell);_panel.delegate=self;_root=[[SMDialogRootV62 alloc]initWithFrame:NSMakeRect(0,0,460,height)];_root.radius=30;_root.cancelTarget=self;_root.cancelAction=@selector(cancel:);SMDialogInstallRoot(_panel,_root);
 SMDialogHeadingV62 *heading=[[SMDialogHeadingV62 alloc]initWithFrame:NSMakeRect(inset,top,contentWidth,titleHeight)];heading.stringValue=title;heading.editable=NO;heading.selectable=NO;heading.bezeled=NO;heading.drawsBackground=NO;heading.font=SMDialogFont(16,YES);heading.textColor=SMDialogColor(@"ink");heading.alignment=NSTextAlignmentCenter;[_root addSubview:heading];
 NSScrollView *scroll=[[NSScrollView alloc]initWithFrame:NSMakeRect(inset,bodyY,contentWidth,bodyHeight)];scroll.drawsBackground=NO;scroll.borderType=NSNoBorder;scroll.hasVerticalScroller=natural>bodyHeight;scroll.autohidesScrollers=YES;scroll.scrollerStyle=NSScrollerStyleOverlay;_messageView.frame=NSMakeRect(0,0,contentWidth,MAX(bodyHeight,natural));[_messageView setAccessibilityLabel:@"提示内容"];scroll.documentView=_messageView;[_root addSubview:scroll];
 NSMutableArray *order=[NSMutableArray new];if(cancel!=NSNotFound)[order addObject:@(cancel)];for(NSInteger i=0;i<labels.count;i++)if(i!=primary&&i!=cancel)[order addObject:@(i)];if(primary!=cancel)[order addObject:@(primary)];NSMutableArray *buttons=[NSMutableArray new];CGFloat gap=20,buttonWidth=MIN(140,(contentWidth-gap*(labels.count-1))/labels.count),x=(width-buttonWidth*labels.count-gap*(labels.count-1))/2;for(NSNumber *n in order){NSInteger i=n.integerValue;NSString *label=[labels[i]isKindOfClass:NSString.class]?labels[i]:@"确定";SMDialogButtonV62 *button=[[SMDialogButtonV62 alloc]initWithFrame:NSMakeRect(x,buttonY,buttonWidth,buttonHeight)];button.title=label;button.primary=i==primary;button.font=SMDialogFont(14,NO);button.bordered=NO;button.target=self;button.action=@selector(choose:);button.tag=i;if(button.primary){button.keyEquivalent=@"\r";button.keyEquivalentModifierMask=0;_panel.defaultButtonCell=(NSButtonCell *)button.cell;}[_root addSubview:button];[buttons addObject:button];x+=buttonWidth+gap;}_buttons=buttons;SMDialogPlace(_panel,_root,parent,NSMakeSize(width,height));
 }return self;}
- (void)choose:(NSButton *)sender{_result=NSAlertFirstButtonReturn+sender.tag;if(NSApp.modalWindow==_panel)[NSApp stopModalWithCode:_result];[_panel orderOut:nil];}
- (void)cancel:(id)sender{_result=_cancelResult;if(NSApp.modalWindow==_panel)[NSApp stopModalWithCode:_result];[_panel orderOut:nil];}
- (BOOL)windowShouldClose:(NSWindow *)sender{[self cancel:nil];return YES;}
+ (NSInteger)showJSON:(NSString *)json forWindow:(NSWindow *)parent{SMDeliveryAlertControllerV62 *c=[[self alloc]initWithJSON:json forWindow:parent];if(!c)return NSAlertFirstButtonReturn;if(parent)[parent addChildWindow:c.panel ordered:NSWindowAbove];[c.panel makeKeyAndOrderFront:nil];[NSApp runModalForWindow:c.panel];NSInteger result=c.result;if(parent)[parent removeChildWindow:c.panel];[c.panel close];return result;}
@end
