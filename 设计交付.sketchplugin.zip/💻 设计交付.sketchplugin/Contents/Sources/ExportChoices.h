// Native hover popover, confined to the export trigger and its three choices.
@protocol SMExportChoicesDelegateV62 <NSObject>
- (void)showExportChoices:(id)sender;
- (void)scheduleExportDismiss;
- (void)cancelExportDismiss;
@end
@interface SMExportTriggerV62 : SMToolbarButtonV62
@property(nonatomic,weak) id<SMExportChoicesDelegateV62> hoverDelegate;
@property(nonatomic,strong) NSTrackingArea *hoverArea;
@end
@implementation SMExportTriggerV62
- (void)updateTrackingAreas {[super updateTrackingAreas];if(_hoverArea)[self removeTrackingArea:_hoverArea];_hoverArea=[[NSTrackingArea alloc]initWithRect:NSZeroRect options:NSTrackingMouseEnteredAndExited|NSTrackingActiveInKeyWindow|NSTrackingInVisibleRect owner:self userInfo:nil];[self addTrackingArea:_hoverArea];}
- (void)openAfterHover {if(self.window&&!self.hidden)[_hoverDelegate showExportChoices:self];}
- (void)mouseEntered:(NSEvent *)event {[_hoverDelegate cancelExportDismiss];[NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(openAfterHover) object:nil];[self performSelector:@selector(openAfterHover) withObject:nil afterDelay:.18];}
- (void)mouseExited:(NSEvent *)event {[NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(openAfterHover) object:nil];[_hoverDelegate scheduleExportDismiss];}
@end
@interface SMExportChoicesViewV62 : NSView
@property(nonatomic,weak) id<SMExportChoicesDelegateV62> hoverDelegate;
@property(nonatomic,strong) NSTrackingArea *hoverArea;
@end
@implementation SMExportChoicesViewV62
- (BOOL)isFlipped {return YES;}
- (void)updateTrackingAreas {[super updateTrackingAreas];if(_hoverArea)[self removeTrackingArea:_hoverArea];_hoverArea=[[NSTrackingArea alloc]initWithRect:NSZeroRect options:NSTrackingMouseEnteredAndExited|NSTrackingActiveAlways|NSTrackingInVisibleRect owner:self userInfo:nil];[self addTrackingArea:_hoverArea];}
- (void)mouseEntered:(NSEvent *)event {[_hoverDelegate cancelExportDismiss];}
- (void)mouseExited:(NSEvent *)event {[_hoverDelegate scheduleExportDismiss];}
@end
@interface SMExportChoiceButtonV62 : NSButton
@property(nonatomic) BOOL hovered;
@property(nonatomic,strong) NSTrackingArea *hoverArea;
@end
@implementation SMExportChoiceButtonV62
- (BOOL)isFlipped {return YES;}
- (void)updateTrackingAreas {[super updateTrackingAreas];if(_hoverArea)[self removeTrackingArea:_hoverArea];_hoverArea=[[NSTrackingArea alloc]initWithRect:NSZeroRect options:NSTrackingMouseEnteredAndExited|NSTrackingActiveAlways|NSTrackingInVisibleRect owner:self userInfo:nil];[self addTrackingArea:_hoverArea];}
- (void)mouseEntered:(NSEvent *)event {_hovered=YES;[self setNeedsDisplay:YES];}
- (void)mouseExited:(NSEvent *)event {_hovered=NO;[self setNeedsDisplay:YES];}
- (void)drawRect:(NSRect)dirty {BOOL selected=_hovered||self.highlighted;NSColor *ink=selected?NSColor.whiteColor:SMInk(self);if(selected){[SMAccent()setFill];[[NSBezierPath bezierPathWithRoundedRect:self.bounds xRadius:6 yRadius:6]fill];}NSDictionary *attrs=@{NSFontAttributeName:self.font?:SMDialogFont(14,NO),NSForegroundColorAttributeName:ink};NSSize size=[self.title sizeWithAttributes:attrs];[self.title drawAtPoint:NSMakePoint(12,(self.bounds.size.height-size.height)/2) withAttributes:attrs];}
@end
