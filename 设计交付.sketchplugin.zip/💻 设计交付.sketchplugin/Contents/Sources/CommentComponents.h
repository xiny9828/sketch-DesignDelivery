// Annotation surfaces follow the supplied 460-point designs.
#import "CommentIcons.h"
static NSColor *SMCommentTone(NSString *role){return [NSColor colorWithName:[@"DeliveryComment." stringByAppendingString:role] dynamicProvider:^NSColor *(NSAppearance *a){BOOL dark=[[a bestMatchFromAppearancesWithNames:@[NSAppearanceNameAqua,NSAppearanceNameDarkAqua]]isEqual:NSAppearanceNameDarkAqua];if([role isEqual:@"surface"])return dark?[NSColor colorWithWhite:.12 alpha:1]:NSColor.whiteColor;CGFloat alpha=[role isEqual:@"muted"]?.4:([role isEqual:@"icon"]?.6:([role isEqual:@"line"]?.059:.902));return [NSColor colorWithWhite:dark?1:0 alpha:alpha];}];}
static NSMutableParagraphStyle *SMCommentParagraph(CGFloat height){NSMutableParagraphStyle *p=[NSMutableParagraphStyle new];p.minimumLineHeight=height;p.maximumLineHeight=height;p.lineBreakMode=NSLineBreakByWordWrapping;return p;}
static NSDictionary *SMCommentBodyAttributes(void){return @{NSFontAttributeName:SMDialogFont(14,NO),NSForegroundColorAttributeName:SMCommentTone(@"ink"),NSParagraphStyleAttributeName:SMCommentParagraph(22)};}
static CGFloat SMCommentBodyHeight(NSString *text,CGFloat width){NSRect r=[(text?:@"") boundingRectWithSize:NSMakeSize(MAX(1,width),CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading attributes:SMCommentBodyAttributes()];return MAX(22,ceil(r.size.height/22)*22);}
// Hover and selected read-only comments share the same anchored silhouette.
static NSBezierPath *SMCommentBubblePath(NSRect r,CGFloat radius){
 radius=MIN(radius,MIN(r.size.width,r.size.height)/2);NSBezierPath *p=[NSBezierPath bezierPath];
 [p moveToPoint:NSMakePoint(NSMinX(r),NSMaxY(r))];[p lineToPoint:NSMakePoint(NSMinX(r),NSMinY(r)+radius)];
 [p curveToPoint:NSMakePoint(NSMinX(r)+radius,NSMinY(r)) controlPoint1:NSMakePoint(NSMinX(r),NSMinY(r)+radius*.448) controlPoint2:NSMakePoint(NSMinX(r)+radius*.448,NSMinY(r))];
 [p lineToPoint:NSMakePoint(NSMaxX(r)-radius,NSMinY(r))];[p curveToPoint:NSMakePoint(NSMaxX(r),NSMinY(r)+radius) controlPoint1:NSMakePoint(NSMaxX(r)-radius*.448,NSMinY(r)) controlPoint2:NSMakePoint(NSMaxX(r),NSMinY(r)+radius*.448)];
 [p lineToPoint:NSMakePoint(NSMaxX(r),NSMaxY(r)-radius)];[p curveToPoint:NSMakePoint(NSMaxX(r)-radius,NSMaxY(r)) controlPoint1:NSMakePoint(NSMaxX(r),NSMaxY(r)-radius*.448) controlPoint2:NSMakePoint(NSMaxX(r)-radius*.448,NSMaxY(r))];[p closePath];return p;
}
static NSRect SMCommentBubbleFrame(NSPoint anchor,NSSize size,NSRect viewport){
 NSRect f=NSMakeRect(anchor.x-2,anchor.y-size.height+2,size.width,size.height);
 f.origin.x=MAX(NSMinX(viewport)+8,MIN(NSMaxX(viewport)-size.width-8,f.origin.x));
 f.origin.y=MAX(NSMinY(viewport)+8,MIN(NSMaxY(viewport)-size.height-8,f.origin.y));return f;
}
@interface SMCommentLabelV62 : NSTextField
@property(copy) NSString *toneRole;
@end
@implementation SMCommentLabelV62
- (BOOL)allowsVibrancy{return NO;}
- (void)drawRect:(NSRect)dirty{
 if([_toneRole isEqual:@"muted"]){[self.stringValue drawInRect:self.bounds withAttributes:@{NSFontAttributeName:SMDialogFont(12,NO),NSForegroundColorAttributeName:SMCommentTone(@"muted")}];}
 else{NSAttributedString *text=[[NSAttributedString alloc]initWithString:self.stringValue attributes:SMCommentBodyAttributes()];[text drawWithRect:self.bounds options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingTruncatesLastVisibleLine];}
}
@end
@interface SMCommentSurfaceV62 : NSView
@property(copy) NSString *surfaceRole;
@property BOOL editorFocused;
@end
@implementation SMCommentSurfaceV62
- (BOOL)isFlipped{return YES;}
- (void)drawRect:(NSRect)dirty{if([_surfaceRole isEqual:@"card"]||[_surfaceRole isEqual:@"bubble"]){[SMCommentTone(@"surface")setFill];NSBezierPath *path=[_surfaceRole isEqual:@"bubble"]?SMCommentBubblePath(self.bounds,30):[NSBezierPath bezierPathWithRoundedRect:self.bounds xRadius:30 yRadius:30];[path fill];}}
- (void)viewDidChangeEffectiveAppearance{[super viewDidChangeEffectiveAppearance];[self setNeedsDisplay:YES];for(NSView *v in self.subviews)[v setNeedsDisplay:YES];}
@end
@interface SMCommentContentV62 : NSView
@end
@implementation SMCommentContentV62
- (BOOL)isFlipped{return YES;}
@end
@interface SMCommentRowV62 : SMCommentContentV62
@property NSArray<NSButton *> *actionButtons;
@property NSTrackingArea *hoverTracking;
@end
@implementation SMCommentRowV62
- (void)updateTrackingAreas{[super updateTrackingAreas];if(_hoverTracking)[self removeTrackingArea:_hoverTracking];_hoverTracking=[[NSTrackingArea alloc]initWithRect:NSZeroRect options:NSTrackingMouseEnteredAndExited|NSTrackingActiveInKeyWindow|NSTrackingInVisibleRect owner:self userInfo:nil];[self addTrackingArea:_hoverTracking];}
- (void)mouseEntered:(NSEvent *)event{for(NSButton *button in _actionButtons)button.hidden=NO;}
- (void)mouseExited:(NSEvent *)event{for(NSButton *button in _actionButtons)button.hidden=YES;}
@end
@interface SMCommentDividerV62 : NSView
@end
@implementation SMCommentDividerV62
- (void)drawRect:(NSRect)dirty{[SMCommentTone(@"line")setFill];NSRectFillUsingOperation(self.bounds,NSCompositingOperationSourceOver);}
@end
@interface SMCommentButtonV62 : NSButton
@property(copy) NSString *visualStyle,*lineSymbol;
@property BOOL hovered;
@property NSTrackingArea *hoverTracking;
@end
@implementation SMCommentButtonV62
- (BOOL)isFlipped{return YES;}
- (void)updateTrackingAreas{[super updateTrackingAreas];if(_hoverTracking)[self removeTrackingArea:_hoverTracking];_hoverTracking=[[NSTrackingArea alloc]initWithRect:NSZeroRect options:NSTrackingMouseEnteredAndExited|NSTrackingActiveInKeyWindow|NSTrackingInVisibleRect owner:self userInfo:nil];[self addTrackingArea:_hoverTracking];}
- (void)mouseEntered:(NSEvent *)event{_hovered=YES;[self setNeedsDisplay:YES];}
- (void)mouseExited:(NSEvent *)event{_hovered=NO;[self setNeedsDisplay:YES];}
- (void)viewDidChangeEffectiveAppearance{[super viewDidChangeEffectiveAppearance];[self setNeedsDisplay:YES];}
- (void)drawRect:(NSRect)dirty{
 BOOL primary=[_visualStyle isEqual:@"primary"];NSColor *ink=SMCommentTone(@"icon");
 if(primary){NSColor *blue=[SMDialogColor(@"primary")colorWithAlphaComponent:self.enabled?1:.3];if(self.highlighted&&self.enabled)blue=[blue blendedColorWithFraction:.1 ofColor:NSColor.blackColor];[blue setFill];[[NSBezierPath bezierPathWithOvalInRect:self.bounds]fill];NSImage *arrow=SMCommentIcon(@"send",NSColor.whiteColor);[arrow drawInRect:NSMakeRect((self.bounds.size.width-20)/2,(self.bounds.size.height-20)/2,20,20) fromRect:NSZeroRect operation:NSCompositingOperationSourceOver fraction:1 respectFlipped:YES hints:nil];}
 else{NSImage *icon=SMCommentIcon(_lineSymbol,ink);if(icon)[icon drawInRect:NSMakeRect((self.bounds.size.width-16)/2,(self.bounds.size.height-16)/2,16,16) fromRect:NSZeroRect operation:NSCompositingOperationSourceOver fraction:1 respectFlipped:YES hints:nil];else if([_lineSymbol isEqual:@"close"]){NSBezierPath *p=[NSBezierPath bezierPath];p.lineWidth=1.2;p.lineCapStyle=NSLineCapStyleRound;[p moveToPoint:NSMakePoint(6,6)];[p lineToPoint:NSMakePoint(14,14)];[p moveToPoint:NSMakePoint(14,6)];[p lineToPoint:NSMakePoint(6,14)];[ink setStroke];[p stroke];}}
}
@end
@interface SMCommentEditorV62 : NSTextView
@property(copy) NSString *placeholder;
@end
@implementation SMCommentEditorV62
- (void)refreshEditorBorder{}
- (BOOL)becomeFirstResponder{BOOL r=[super becomeFirstResponder];[self setNeedsDisplay:YES];return r;}
- (BOOL)resignFirstResponder{BOOL r=[super resignFirstResponder];[self setNeedsDisplay:YES];return r;}
- (void)didChangeText{[super didChangeText];[self setNeedsDisplay:YES];}
- (void)setString:(NSString *)s{[super setString:s];[self setNeedsDisplay:YES];}
- (void)drawRect:(NSRect)dirty{[super drawRect:dirty];if(!self.string.length&&_placeholder.length){NSMutableDictionary *a=[SMCommentBodyAttributes()mutableCopy];a[NSForegroundColorAttributeName]=SMCommentTone(@"muted");[_placeholder drawInRect:NSMakeRect(0,0,self.bounds.size.width,22) withAttributes:a];}}
@end
@interface SMCommentAvatarV62 : NSView
@property(copy) NSString *initial,*avatarData;
@end
@implementation SMCommentAvatarV62
- (BOOL)isFlipped{return YES;}
- (void)drawRect:(NSRect)dirty{SMDrawAvatar(_avatarData,_initial?:@"注",self.bounds,YES);}
@end
