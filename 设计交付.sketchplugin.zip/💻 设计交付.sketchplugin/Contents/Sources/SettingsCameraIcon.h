// Exact supplied 40 × 40 upload camera.
static NSImage *SMSettingsCameraIcon(void){return [NSImage imageWithSize:NSMakeSize(40,40) flipped:YES drawingHandler:^BOOL(NSRect rect){
CGContextRef cg=NSGraphicsContext.currentContext.CGContext;
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
{ [NSGraphicsContext saveGraphicsState];
NSBezierPath *p=[NSBezierPath bezierPath];
[p moveToPoint:NSMakePoint(24.0566667,5)];
[p curveToPoint:NSMakePoint(26.9133333,6.61666667) controlPoint1:NSMakePoint(25.2266181,5) controlPoint2:NSMakePoint(26.3108084,5.6137958)];
[p lineToPoint:NSMakePoint(28.2016667,8.76166667)];
[p curveToPoint:NSMakePoint(28.9166667,9.16666667) controlPoint1:NSMakePoint(28.3522446,9.01295896) controlPoint2:NSMakePoint(28.6237136,9.16672813)];
[p lineToPoint:NSMakePoint(31.6666667,9.16666667)];
[p curveToPoint:NSMakePoint(36.6666667,14.1666667) controlPoint1:NSMakePoint(34.4280904,9.16666667) controlPoint2:NSMakePoint(36.6666667,11.4052429)];
[p lineToPoint:NSMakePoint(36.6666667,30)];
[p curveToPoint:NSMakePoint(31.6666667,35) controlPoint1:NSMakePoint(36.6666667,32.7614237) controlPoint2:NSMakePoint(34.4280904,35)];
[p lineToPoint:NSMakePoint(8.33333333,35)];
[p curveToPoint:NSMakePoint(3.33333333,30) controlPoint1:NSMakePoint(5.57190958,35) controlPoint2:NSMakePoint(3.33333333,32.7614237)];
[p lineToPoint:NSMakePoint(3.33333333,14.1666667)];
[p curveToPoint:NSMakePoint(8.33333333,9.16666667) controlPoint1:NSMakePoint(3.33333333,11.4052429) controlPoint2:NSMakePoint(5.57190958,9.16666667)];
[p lineToPoint:NSMakePoint(11.0833333,9.16666667)];
[p curveToPoint:NSMakePoint(11.8,8.76166667) controlPoint1:NSMakePoint(11.3768804,9.16731492) controlPoint2:NSMakePoint(11.6491172,9.01346948)];
[p lineToPoint:NSMakePoint(13.0866667,6.61833333)];
[p curveToPoint:NSMakePoint(15.9433333,5) controlPoint1:NSMakePoint(13.6887796,5.6148228) controlPoint2:NSMakePoint(14.7730458,5.00057397)];
[p lineToPoint:NSMakePoint(24.0566667,5)];
[p closePath];
[p moveToPoint:NSMakePoint(14.6566667,10.4766667)];
[p curveToPoint:NSMakePoint(11.0833333,12.5) controlPoint1:NSMakePoint(13.9036701,11.7319787) controlPoint2:NSMakePoint(12.5471681,12.5000726)];
[p lineToPoint:NSMakePoint(8.33333333,12.5)];
[p curveToPoint:NSMakePoint(6.66666667,14.1666667) controlPoint1:NSMakePoint(7.41285875,12.5) controlPoint2:NSMakePoint(6.66666667,13.2461921)];
[p lineToPoint:NSMakePoint(6.66666667,30)];
[p curveToPoint:NSMakePoint(8.33333333,31.6666667) controlPoint1:NSMakePoint(6.66666667,30.9204746) controlPoint2:NSMakePoint(7.41285875,31.6666667)];
[p lineToPoint:NSMakePoint(31.6666667,31.6666667)];
[p curveToPoint:NSMakePoint(33.3333333,30) controlPoint1:NSMakePoint(32.5871412,31.6666667) controlPoint2:NSMakePoint(33.3333333,30.9204746)];
[p lineToPoint:NSMakePoint(33.3333333,14.1666667)];
[p curveToPoint:NSMakePoint(31.6666667,12.5) controlPoint1:NSMakePoint(33.3333333,13.2461921) controlPoint2:NSMakePoint(32.5871412,12.5)];
[p lineToPoint:NSMakePoint(28.9166667,12.5)];
[p curveToPoint:NSMakePoint(25.3416667,10.4766667) controlPoint1:NSMakePoint(27.4522378,12.5006584) controlPoint2:NSMakePoint(26.0949688,11.7324884)];
[p lineToPoint:NSMakePoint(24.0566667,8.33333333)];
[p lineToPoint:NSMakePoint(15.9433333,8.33333333)];
[p lineToPoint:NSMakePoint(14.6566667,10.4766667)];
[p closePath];
[p moveToPoint:NSMakePoint(20,14.1666667)];
[p curveToPoint:NSMakePoint(27.5,21.6666667) controlPoint1:NSMakePoint(24.1421356,14.1666667) controlPoint2:NSMakePoint(27.5,17.524531)];
[p curveToPoint:NSMakePoint(20,29.1666667) controlPoint1:NSMakePoint(27.5,25.8088023) controlPoint2:NSMakePoint(24.1421356,29.1666667)];
[p curveToPoint:NSMakePoint(12.5,21.6666667) controlPoint1:NSMakePoint(15.8578644,29.1666667) controlPoint2:NSMakePoint(12.5,25.8088023)];
[p curveToPoint:NSMakePoint(20,14.1666667) controlPoint1:NSMakePoint(12.5,17.524531) controlPoint2:NSMakePoint(15.8578644,14.1666667)];
[p moveToPoint:NSMakePoint(20,17.5)];
[p curveToPoint:NSMakePoint(15.8333333,21.6666667) controlPoint1:NSMakePoint(17.6988135,17.5) controlPoint2:NSMakePoint(15.8333333,19.3654802)];
[p curveToPoint:NSMakePoint(20,25.8333333) controlPoint1:NSMakePoint(15.8333333,23.9678531) controlPoint2:NSMakePoint(17.6988135,25.8333333)];
[p curveToPoint:NSMakePoint(24.1666667,21.6666667) controlPoint1:NSMakePoint(22.3011865,25.8333333) controlPoint2:NSMakePoint(24.1666667,23.9678531)];
[p curveToPoint:NSMakePoint(20,17.5) controlPoint1:NSMakePoint(24.1666667,19.3654802) controlPoint2:NSMakePoint(22.3011865,17.5)];
p.windingRule=NSWindingRuleNonZero;
[NSColor.whiteColor setFill];
[p fill];
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
[NSGraphicsContext restoreGraphicsState]; }
return YES;}];}
